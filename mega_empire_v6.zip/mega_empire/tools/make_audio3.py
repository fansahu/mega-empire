#!/usr/bin/env python3
"""Tailor shop sounds (synthesized). Run after make_audio2.py: writes audio/sew.wav (loop), snip, shopbell, cloth, ready."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from make_audio2 import *


def sew():
    n = SR  # exactly 1 s, loops cleanly
    t = np.arange(n) / SR
    hum = np.zeros(n)
    for h, a in [(1, 1.0), (2, 0.55), (3, 0.35), (5, 0.18), (8, 0.1)]:
        hum += a * np.sin(2 * np.pi * 96 * h * t)
    hum *= 0.5 * (1 + 0.25 * np.sin(2 * np.pi * 8 * t))
    clicks = np.zeros(n)
    for k in range(16):
        at = int(k / 16 * n)
        ct = T(0.035)
        c = bp(rng.standard_normal(len(ct)), 1800, 6500) * np.exp(-120 * ct) + np.sin(2 * np.pi * 300 * ct) * np.exp(-90 * ct) * 0.6
        m = min(len(c), n - at)
        clicks[at:at + m] += c[:m] * (0.9 if k % 2 == 0 else 0.6)
    whirr = lp(rng.standard_normal(n), 1400) * 0.12
    y = lp(hum, 900) * 0.6 + clicks * 0.8 + whirr
    return y


def snip():
    out = np.zeros(int(SR * 0.5))
    for at in (0.02, 0.17):
        t = T(0.12)
        y = bp(rng.standard_normal(len(t)), 2500, 9000) * np.exp(-38 * t)
        y += (np.sin(2 * np.pi * 3100 * t) + 0.5 * np.sin(2 * np.pi * 4700 * t)) * np.exp(-60 * t) * 0.5
        place(out, y, at)
    return reverb(out, 0.15, 0.4, 7)


def shopbell():
    out = np.zeros(int(SR * 1.8))
    place(out, bell(2093, 1.6, 1.0, ratios=(1, 2.4, 4.1), amps=(1, .45, .2), decay=3.2), 0.0)
    place(out, bell(2637, 1.4, 0.8, ratios=(1, 2.4, 4.1), amps=(1, .45, .2), decay=3.5), 0.11)
    return reverb(out, 0.25, 1.0, 4)


def cloth():
    n = int(SR * 0.45)
    t = np.arange(n) / SR
    x = rng.standard_normal(n)
    y = bp(x, 700, 3200) * np.sin(np.pi * t / 0.45) ** 1.5
    y += hp(x, 4000) * 0.15 * np.exp(-8 * t)
    return reverb(y, 0.1, 0.3, 8)


def ready():
    out = np.zeros(int(SR * 1.6))
    place(out, bell(1319, 1.2, 1.0, decay=4.5), 0.0)
    place(out, bell(1760, 1.3, 0.9, decay=4.0), 0.16)
    place(out, bell(2349, 1.3, 0.7, decay=4.0), 0.32)
    return reverb(out, 0.3, 1.2, 3.5)


if __name__ == "__main__":
    save("sew", sew(), 0.7)
    save("snip", snip(), 0.8)
    save("shopbell", shopbell(), 0.75)
    save("cloth", cloth(), 0.7)
    save("ready", ready(), 0.8)
    print("done")
