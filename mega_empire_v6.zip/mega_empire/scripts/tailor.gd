class_name TailorShop
extends Node3D
## Tailor shop building (east expansion plot). Customers order garments, tailors stitch them at machines,
## customers collect and pay. Built from primitives; everything is in local coordinates (origin = plot centre).

const HALF_W := 6.8
const BACK_Z := -8.0
const FRONT_Z := 8.0
const WALL_H := 3.6
const STATION_X := [-4.6, -2.76, -0.92, 0.92, 2.76, 4.6]
const STATION_Z := -2.6
const COUNTER_C := Vector3(4.7, 0.0, 2.9)
const COUNTER_FRONT := Vector3(4.7, 0.0, 4.6)
const SEATS := [Vector3(-5.5, 0, 3.0), Vector3(-5.5, 0, 4.4), Vector3(-5.5, 0, 5.8)]
const DOOR_IN := Vector3(0.0, 0.0, 6.3)
const DOOR_OUT := Vector3(0.0, 0.0, 10.2)
const RACK_SLOTS := 6

var store: Node3D
var built: bool = false
var _stations: Array = []          # {root, machine_top, needle, wheel, ticket, bar, lamp}
var _tailors: Dictionary = {}      # emp id -> {node, rig, station, tag}
var _agents: Array = []
var _orders: Array = []
var _station_order: Array = [null, null, null, null, null, null]
var _spawn_t: float = 6.0
var _seat_taken: Array = [null, null, null]
var _counter_user = null
var _rack: Array = [null, null, null, null, null, null]
var _lamp_light: OmniLight3D
var _t: float = 0.0
var _rng := RandomNumberGenerator.new()
var _agent_seed: int = 500
var _sew_on: bool = false
var _mats: Dictionary = {}
var _warn_t: float = 0.0


func setup(st: Node3D) -> void:
	store = st
	_rng.randomize()
	Game.tailor_changed.connect(refresh)
	Game.changed.connect(_on_changed)
	refresh()


func _on_changed() -> void:
	_sync_tags()


# ================================================================ materials / helpers
func _m(c: Color, rough: float = 0.7, metal: float = 0.0) -> StandardMaterial3D:
	return CharFactory.mat(c, rough, metal)


func _b(parent: Node, size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
	return CharFactory.mi(parent, CharFactory.box(size.x, size.y, size.z), mat, pos)


func _cyl(parent: Node, rt: float, rb: float, h: float, pos: Vector3, mat: Material, seg: int = 14) -> MeshInstance3D:
	return CharFactory.mi(parent, CharFactory.cyl(rt, rb, h, seg), mat, pos)


func _wood_tex() -> ImageTexture:
	var img := Image.create(256, 256, false, Image.FORMAT_RGB8)
	var rng := RandomNumberGenerator.new()
	rng.seed = 77
	var planks := 8
	var ph: int = 256 / planks
	for p in range(planks):
		var base := Color(0.55, 0.36, 0.2).lerp(Color(0.68, 0.46, 0.27), rng.randf())
		var off: int = rng.randi() % 256
		for y in range(ph):
			for x in range(256):
				var g: float = 0.5 + 0.5 * sin(float((x + off) % 256) * 0.09 + sin(float(y) * 0.5) * 0.7)
				var shade: float = 0.9 + 0.1 * g + rng.randf_range(-0.02, 0.02)
				var c := Color(base.r * shade, base.g * shade, base.b * shade)
				if y == 0 or y == ph - 1:
					c = c.darkened(0.35)
				if (x + off) % 256 == 0:
					c = c.darkened(0.3)
				img.set_pixel(x, p * ph + y, c)
	return ImageTexture.create_from_image(img)


func _wood_mat() -> StandardMaterial3D:
	if _mats.has("wood"):
		return _mats["wood"]
	var m := StandardMaterial3D.new()
	m.albedo_texture = _wood_tex()
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	m.uv1_scale = Vector3(0.22, 0.22, 0.22)
	m.roughness = 0.55
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	_mats["wood"] = m
	return m


func _label(text: String, size: int, color: Color, pos: Vector3, px: float = 0.01, billboard: bool = false) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.font_size = size
	l.pixel_size = px
	l.modulate = color
	l.outline_size = 10
	l.outline_modulate = Color(0, 0, 0, 0.85)
	if billboard:
		l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		l.no_depth_test = true
	l.position = pos
	add_child(l)
	return l


# ================================================================ build the building
func _build_shop() -> void:
	built = true
	var wall_m: StandardMaterial3D = store._tex_mat("wall", 0.2, Color("f3e6d3"), 0.9)
	var wall_dark: StandardMaterial3D = store._tex_mat("wall", 0.2, Color("6f2d45"), 0.9)
	var trim := _m(Color("3b2a22"), 0.6)
	var wood := _wood_mat()
	var dark_wood := _m(Color("4a2f1e"), 0.5)
	var brass := _m(Color("d4a017"), 0.3, 0.8)
	# floor
	_b(self, Vector3(HALF_W * 2.0, 0.14, FRONT_Z - BACK_Z), Vector3(0, 0.07, (FRONT_Z + BACK_Z) / 2.0), wood)
	# rug
	var rug := _b(self, Vector3(5.2, 0.03, 3.6), Vector3(-0.2, 0.16, 3.0), _m(Color("7a1f3d"), 0.95))
	_b(rug, Vector3(4.6, 0.01, 3.0), Vector3(0, 0.02, 0), _m(Color("c9a45c"), 0.95))
	_b(rug, Vector3(4.2, 0.012, 2.6), Vector3(0, 0.03, 0), _m(Color("7a1f3d"), 0.95))
	# walls
	_b(self, Vector3(HALF_W * 2.0 + 0.6, WALL_H, 0.3), Vector3(0, WALL_H / 2.0, BACK_Z - 0.15), wall_m)
	_b(self, Vector3(HALF_W * 2.0 + 0.6, 0.35, 0.34), Vector3(0, WALL_H - 0.18, BACK_Z - 0.14), trim)
	for sx in [-1.0, 1.0]:
		_b(self, Vector3(0.3, WALL_H, FRONT_Z - BACK_Z + 0.3), Vector3(sx * (HALF_W + 0.15), WALL_H / 2.0, (FRONT_Z + BACK_Z) / 2.0), wall_m)
		_b(self, Vector3(0.34, 0.35, FRONT_Z - BACK_Z + 0.3), Vector3(sx * (HALF_W + 0.14), WALL_H - 0.18, (FRONT_Z + BACK_Z) / 2.0), trim)
	# accent panel behind the fabric wall
	_b(self, Vector3(HALF_W * 2.0 - 0.4, 3.0, 0.08), Vector3(0, 1.55, BACK_Z + 0.06), wall_dark)
	# front wall: sill + glass + pillars + fascia with door gap
	var glass: StandardMaterial3D = store._glass_mat()
	for sx in [-1.0, 1.0]:
		var cx: float = sx * 4.0
		_b(self, Vector3(5.6, 0.9, 0.3), Vector3(cx, 0.45, FRONT_Z), wall_m)
		_b(self, Vector3(5.6, 2.2, 0.06), Vector3(cx, 2.0, FRONT_Z), glass)
		_b(self, Vector3(5.6, 0.08, 0.14), Vector3(cx, 3.1, FRONT_Z), trim)
		for k in range(1, 4):
			_b(self, Vector3(0.06, 2.2, 0.1), Vector3(cx - 2.8 + float(k) * 1.4, 2.0, FRONT_Z), trim)
		_b(self, Vector3(0.4, WALL_H, 0.4), Vector3(sx * 1.35, WALL_H / 2.0, FRONT_Z), trim)
		_b(self, Vector3(0.4, WALL_H, 0.4), Vector3(sx * (HALF_W + 0.15), WALL_H / 2.0, FRONT_Z), trim)
	_b(self, Vector3(2.7, 0.7, 0.34), Vector3(0, WALL_H - 0.35, FRONT_Z), trim)
	# sign board + scissors emblem
	_b(self, Vector3(8.6, 1.0, 0.3), Vector3(0, WALL_H + 0.55, FRONT_Z + 0.2), _m(Color("3a1626"), 0.5))
	_b(self, Vector3(8.8, 0.08, 0.34), Vector3(0, WALL_H + 1.08, FRONT_Z + 0.2), brass)
	_b(self, Vector3(8.8, 0.08, 0.34), Vector3(0, WALL_H + 0.02, FRONT_Z + 0.2), brass)
	var lb := _label("STITCH & CO.  TAILORS", 72, Color("ffd36b"), Vector3(0.4, WALL_H + 0.55, FRONT_Z + 0.4), 0.0085)
	lb.outline_size = 14
	for ang in [28.0, -28.0]:
		var bl := _b(self, Vector3(0.08, 0.8, 0.05), Vector3(-3.6, WALL_H + 0.55, FRONT_Z + 0.4), brass)
		bl.rotation_degrees = Vector3(0, 0, ang)
	_label("Suits · Kurtas · Wedding wear · Alterations", 36, Color("f3e6d3"), Vector3(0, WALL_H - 0.35, FRONT_Z + 0.25), 0.0085)
	# awning over the door
	for i in range(8):
		var col := Color("b5172c") if i % 2 == 0 else Color("f3e6d3")
		var aw := _b(self, Vector3(0.52, 0.06, 1.6), Vector3(-1.82 + float(i) * 0.52, 3.12, FRONT_Z + 0.9), _m(col, 0.9))
		aw.rotation_degrees = Vector3(18, 0, 0)
	# door bell + brass handles
	_b(self, Vector3(0.12, 0.12, 0.12), Vector3(0.9, 3.0, FRONT_Z + 0.1), brass)
	# ---- fabric wall (back) ----
	var tiers := [0.95, 1.75, 2.55]
	var rolls := MultiMeshInstance3D.new()
	var rm := MultiMesh.new()
	rm.transform_format = MultiMesh.TRANSFORM_3D
	rm.use_colors = true
	var cm := CylinderMesh.new()
	cm.top_radius = 0.2
	cm.bottom_radius = 0.2
	cm.height = 0.8
	cm.radial_segments = 10
	rm.mesh = cm
	var per: int = 11
	rm.instance_count = tiers.size() * per
	var pal := [Color("b5179e"), Color("5b6b85"), Color("e8d9c0"), Color("c9184a"), Color("2b4c9b"), Color("3a7d44"), Color("d4a017"), Color("7a1f3d"), Color("1d3557"), Color("e76f51"), Color("8d99ae")]
	var idx := 0
	for ti in range(tiers.size()):
		_b(self, Vector3(HALF_W * 2.0 - 0.8, 0.07, 0.62), Vector3(0, float(tiers[ti]) - 0.23, BACK_Z + 0.42), dark_wood)
		for k in range(per):
			var x: float = -6.0 + float(k) * 1.2 + (0.0 if ti % 2 == 0 else 0.3)
			var t := Transform3D(Basis(Vector3(0, 0, 1), PI / 2.0), Vector3(x, float(tiers[ti]) - 0.02, BACK_Z + 0.42))
			rm.set_instance_transform(idx, t)
			rm.set_instance_color(idx, pal[(k + ti * 3) % pal.size()])
			idx += 1
	rolls.multimesh = rm
	var rmat := StandardMaterial3D.new()
	rmat.vertex_color_use_as_albedo = true
	rmat.roughness = 0.85
	rolls.material_override = rmat
	add_child(rolls)
	for sx in [-1.0, 1.0]:
		_b(self, Vector3(0.12, 2.9, 0.62), Vector3(sx * 6.6, 1.45, BACK_Z + 0.42), dark_wood)
	# ---- cutting table ----
	var ct := Node3D.new()
	ct.position = Vector3(0.0, 0, -5.9)
	add_child(ct)
	_b(ct, Vector3(4.2, 0.12, 1.6), Vector3(0, 0.94, 0), dark_wood)
	_b(ct, Vector3(4.0, 0.04, 1.4), Vector3(0, 1.0, 0), _m(Color("2f6b4f"), 0.9))  # cutting mat
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			_b(ct, Vector3(0.14, 0.9, 0.14), Vector3(sx * 1.9, 0.45, sz * 0.65), dark_wood)
	_b(ct, Vector3(1.6, 0.035, 1.0), Vector3(-0.7, 1.04, 0.0), _m(Color("e8d9c0"), 0.95))  # fabric laid out
	_b(ct, Vector3(1.0, 0.03, 0.8), Vector3(0.9, 1.04, 0.1), _m(Color("5b6b85"), 0.95))
	_b(ct, Vector3(1.4, 0.02, 0.05), Vector3(0.1, 1.07, 0.5), _m(Color("f2c94c"), 0.5))      # tape measure
	var scissors := Node3D.new()
	scissors.position = Vector3(1.6, 1.07, -0.3)
	ct.add_child(scissors)
	for a in [12.0, -12.0]:
		var bl := _b(scissors, Vector3(0.05, 0.015, 0.3), Vector3(0, 0, 0), _m(Color("c0c4c8"), 0.25, 0.9))
		bl.rotation_degrees = Vector3(0, a, 0)
	_cyl(ct, 0.05, 0.05, 0.05, Vector3(-1.6, 1.05, -0.3), _m(Color("c9184a"), 0.6))
	# ---- sewing stations ----
	for i in range(STATION_X.size()):
		_stations.append(_build_station(i, float(STATION_X[i])))
	# ---- reception counter ----
	var cn := Node3D.new()
	cn.position = COUNTER_C
	add_child(cn)
	_b(cn, Vector3(3.6, 1.05, 1.0), Vector3(0, 0.525, 0), dark_wood)
	_b(cn, Vector3(3.8, 0.1, 1.2), Vector3(0, 1.1, 0), _m(Color("e8e0d4"), 0.3, 0.1))
	_b(cn, Vector3(3.6, 0.08, 0.06), Vector3(0, 0.75, 0.52), brass)
	_b(cn, Vector3(0.5, 0.22, 0.4), Vector3(-1.2, 1.26, 0.0), _m(Color("22252b"), 0.4))      # till
	_b(cn, Vector3(0.4, 0.02, 0.22), Vector3(-1.2, 1.4, 0.04), _m(Color("2ec4b6"), 0.4)).rotation_degrees.x = -20.0
	_cyl(cn, 0.09, 0.11, 0.08, Vector3(0.1, 1.19, 0.15), brass)
	CharFactory.mi(cn, CharFactory.sphere(0.07, 0.1), brass, Vector3(0.1, 1.28, 0.15))
	_b(cn, Vector3(0.5, 0.3, 0.02), Vector3(1.1, 1.3, -0.3), _m(Color("fff3d6"), 0.9))     # order book
	_label("ORDERS & PICKUP", 40, Color("ffd36b"), Vector3(0, 2.1, 0.3), 0.009)
	# ---- pickup rack (ready garments) ----
	var rack := Node3D.new()
	rack.position = Vector3(6.2, 0, -0.5)
	add_child(rack)
	_cyl(rack, 0.03, 0.03, 2.6, Vector3(0, 1.3, 0), brass, 8).rotation_degrees = Vector3(90, 0, 0)
	for sz in [-1.3, 1.3]:
		_b(rack, Vector3(0.08, 1.9, 0.08), Vector3(0, 0.95, sz), dark_wood)
	_label("READY", 36, Color("7bed9f"), Vector3(0, 2.15, 0), 0.009)
	# ---- waiting sofa (left wall) ----
	var sofa := Node3D.new()
	sofa.position = Vector3(-6.2, 0, 4.4)
	add_child(sofa)
	var sofa_m := _m(Color("284b63"), 0.85)
	_b(sofa, Vector3(1.0, 0.45, 3.4), Vector3(0.1, 0.38, 0), sofa_m)
	_b(sofa, Vector3(0.3, 0.9, 3.4), Vector3(-0.35, 0.65, 0), sofa_m)
	for sz in [-1.7, 1.7]:
		_b(sofa, Vector3(0.9, 0.65, 0.3), Vector3(0.1, 0.5, sz), _m(Color("1d3557"), 0.85))
	for k in range(3):
		_b(sofa, Vector3(0.8, 0.14, 0.95), Vector3(0.15, 0.66, -1.1 + float(k) * 1.1), _m(Color("3d6a8c"), 0.9))
	_b(self, Vector3(0.8, 0.4, 0.8), Vector3(-4.3, 0.2, 4.4), dark_wood)       # coffee table
	_b(self, Vector3(0.9, 0.05, 0.9), Vector3(-4.3, 0.42, 4.4), _m(Color("e8e0d4"), 0.3))
	# ---- mannequins in the window ----
	_mannequin(Vector3(-3.0, 0, 6.9), Color("2d3142"), Color("f3e6d3"))
	_mannequin(Vector3(3.0, 0, 6.9), Color("b5172c"), Color("d4a017"))
	_mannequin(Vector3(-5.9, 0, -5.4), Color("d4a017"), Color("7a1f3d"))
	_mannequin(Vector3(5.9, 0, -5.4), Color("1d3557"), Color("f3e6d3"))
	# ---- fitting room (right wall) ----
	var fr := Node3D.new()
	fr.position = Vector3(6.0, 0, -4.0)
	add_child(fr)
	_b(fr, Vector3(1.6, 2.7, 0.1), Vector3(-0.2, 1.35, -1.0), dark_wood)
	_b(fr, Vector3(1.6, 2.7, 0.1), Vector3(-0.2, 1.35, 1.0), dark_wood)
	_b(fr, Vector3(0.06, 2.5, 1.9), Vector3(-1.0, 1.25, 0), _m(Color("7a1f3d"), 0.95))     # curtain (open side)
	_b(fr, Vector3(0.05, 1.6, 0.8), Vector3(0.55, 1.2, 0.0), _m(Color("cfe8f5"), 0.05, 0.6))   # mirror
	_label("FITTING", 30, Color("f3e6d3"), Vector3(-0.2, 3.1, 0), 0.008)
	# standing mirror on left wall
	_b(self, Vector3(0.08, 2.0, 1.0), Vector3(-6.6, 1.2, 0.4), dark_wood)
	_b(self, Vector3(0.04, 1.8, 0.8), Vector3(-6.54, 1.2, 0.4), _m(Color("cfe8f5"), 0.05, 0.6))
	# plants
	for p in [Vector3(-6.2, 0, 7.2), Vector3(6.2, 0, 7.2), Vector3(-6.2, 0, -7.2)]:
		_cyl(self, 0.28, 0.2, 0.5, p + Vector3(0, 0.25, 0), _m(Color("b5654a"), 0.8))
		CharFactory.mi(self, CharFactory.sphere(0.4, 0.8), _m(Color("2d8a4e"), 0.9), p + Vector3(0, 0.85, 0))
	# hanging pendant lamps
	for lp in [Vector3(-3.5, 0, 3.0), Vector3(0, 0, 3.5), Vector3(3.5, 0, 0.0), Vector3(-3.0, 0, -2.0), Vector3(2.0, 0, -2.0), Vector3(0, 0, -6.0)]:
		_cyl(self, 0.01, 0.01, 0.9, lp + Vector3(0, 3.15, 0), _m(Color("22252b"), 0.6), 6)
		_cyl(self, 0.12, 0.34, 0.26, lp + Vector3(0, 2.62, 0), _m(Color("ffe2a8"), 0.4)).material_override = CharFactory.emissive(Color("ffd9a0"), 1.8)
	_lamp_light = OmniLight3D.new()
	_lamp_light.position = Vector3(0, 3.0, 0.5)
	_lamp_light.omni_range = 17.0
	_lamp_light.light_energy = 0.55
	_lamp_light.light_color = Color("ffe0b0")
	_lamp_light.shadow_enabled = false
	add_child(_lamp_light)


func _build_station(i: int, x: float) -> Dictionary:
	var st := Node3D.new()
	st.position = Vector3(x, 0, STATION_Z)
	add_child(st)
	var dark_wood := _m(Color("4a2f1e"), 0.5)
	_b(st, Vector3(1.4, 0.08, 0.85), Vector3(0, 0.78, 0), _wood_mat())
	for sx in [-0.62, 0.62]:
		_b(st, Vector3(0.08, 0.76, 0.7), Vector3(sx, 0.38, 0), _m(Color("22252b"), 0.5, 0.5))
	_b(st, Vector3(1.2, 0.05, 0.6), Vector3(0, 0.3, 0), dark_wood)   # treadle shelf
	# machine
	var mach := Node3D.new()
	mach.position = Vector3(0, 0.82, 0.02)
	st.add_child(mach)
	var body := _m(Color("1d1f24"), 0.35, 0.5)
	_b(mach, Vector3(0.62, 0.1, 0.3), Vector3(0, 0.05, 0), body)
	_b(mach, Vector3(0.14, 0.42, 0.22), Vector3(-0.22, 0.28, 0), body)
	_b(mach, Vector3(0.5, 0.12, 0.2), Vector3(0.0, 0.5, 0), body)
	_b(mach, Vector3(0.1, 0.1, 0.1), Vector3(0.27, 0.45, 0), body)
	var needle := _b(mach, Vector3(0.015, 0.2, 0.015), Vector3(0.27, 0.27, 0), _m(Color("d0d3d6"), 0.2, 0.9))
	var wheel := _cyl(mach, 0.09, 0.09, 0.04, Vector3(-0.3, 0.46, 0), _m(Color("d4a017"), 0.3, 0.8), 14)
	wheel.rotation_degrees = Vector3(0, 0, 90)
	_b(mach, Vector3(0.12, 0.2, 0.12), Vector3(-0.05, 0.69, 0), _m(Color("c9184a"), 0.5))   # thread spool
	_b(mach, Vector3(0.28, 0.02, 0.34), Vector3(0.25, 0.01, 0), _m(Color("b9bcc0"), 0.3, 0.8))   # plate
	# thread cone on desk + cloth under needle
	_b(st, Vector3(0.36, 0.015, 0.3), Vector3(0.45, 0.83, 0.22), _m(Color("e8d9c0"), 0.95))
	# stool
	_cyl(st, 0.2, 0.2, 0.06, Vector3(0, 0.5, -0.85), _m(Color("7a1f3d"), 0.8))
	_cyl(st, 0.03, 0.05, 0.46, Vector3(0, 0.24, -0.85), _m(Color("22252b"), 0.5), 8)
	# lamp
	var lamp := _cyl(st, 0.1, 0.12, 0.06, Vector3(-0.5, 1.36, 0.1), _m(Color("ffe2a8"), 0.4))
	lamp.material_override = CharFactory.emissive(Color("ffe2a8"), 1.2)
	_cyl(st, 0.012, 0.012, 0.5, Vector3(-0.5, 1.08, 0.1), _m(Color("22252b"), 0.5), 6)
	# ticket
	var ticket := _label("", 30, Color("ffd36b"), Vector3(0, 1.85, 0), 0.008, true)
	ticket.position = Vector3(x, 1.9, STATION_Z)
	var bar_bg := _b(self, Vector3(1.1, 0.12, 0.04), Vector3(x, 1.68, STATION_Z + 0.5), _m(Color("22252b"), 0.9))
	var bar := _b(self, Vector3(1.06, 0.08, 0.05), Vector3(x - 0.53, 1.68, STATION_Z + 0.52), CharFactory.emissive(Color("7bed9f"), 1.2))
	bar.scale.x = 0.001
	bar_bg.visible = false
	bar.visible = false
	return {"root": st, "needle": needle, "wheel": wheel, "ticket": ticket, "bar": bar, "bar_bg": bar_bg, "x": x, "parts": [st]}


func _mannequin(pos: Vector3, suit: Color, accent: Color) -> void:
	var mq := Node3D.new()
	mq.position = pos
	add_child(mq)
	var skin := _m(Color("e4d3bd"), 0.7)
	_cyl(mq, 0.28, 0.32, 0.05, Vector3(0, 0.03, 0), _m(Color("22252b"), 0.4, 0.5))
	_cyl(mq, 0.025, 0.025, 1.0, Vector3(0, 0.55, 0), _m(Color("b9bcc0"), 0.3, 0.8), 8)
	CharFactory.mi(mq, CharFactory.capsule(0.2, 0.75), skin, Vector3(0, 1.3, 0))
	CharFactory.mi(mq, CharFactory.sphere(0.1, 0.22), skin, Vector3(0, 1.82, 0))
	# garment: jacket + lapel + trousers panel
	CharFactory.mi(mq, CharFactory.capsule(0.225, 0.62), _m(suit, 0.85), Vector3(0, 1.3, 0.0))
	_b(mq, Vector3(0.1, 0.5, 0.03), Vector3(-0.07, 1.4, 0.2), _m(accent, 0.7)).rotation_degrees.z = 14.0
	_b(mq, Vector3(0.1, 0.5, 0.03), Vector3(0.07, 1.4, 0.2), _m(accent, 0.7)).rotation_degrees.z = -14.0
	_cyl(mq, 0.2, 0.26, 0.5, Vector3(0, 0.85, 0), _m(suit.darkened(0.2), 0.85))


# ================================================================ staff (tailors at their machines)
func refresh() -> void:
	if not Game.tailor_unlocked():
		return
	if not built:
		_build_shop()
		if store.has_method("on_tailor_built"):
			store.on_tailor_built()
	var machines: int = int(Game.tailor["machines"])
	for i in range(_stations.size()):
		(_stations[i]["root"] as Node3D).visible = i < machines
	var live := {}
	var list: Array = Game.emp_of_type("tailor")
	for k in range(mini(list.size(), machines)):
		var e: Dictionary = list[k]
		var id: int = int(e["id"])
		live[id] = true
		if _tailors.has(id) and is_instance_valid(_tailors[id]["node"]):
			_tailors[id]["station"] = k
			continue
		var node: Node3D = CharFactory.build(int(e["seed"]), "tailor")
		add_child(node)
		_tailors[id] = {"node": node, "rig": node.get_meta("rig"), "station": k, "tag": _find_tag(node)}
	for id in _tailors.keys():
		if not live.has(id):
			if is_instance_valid(_tailors[id]["node"]):
				(_tailors[id]["node"] as Node3D).queue_free()
			_tailors.erase(id)
	for id in _tailors:
		var tn: Node3D = _tailors[id]["node"]
		var sx: float = float(STATION_X[int(_tailors[id]["station"])])
		tn.position = Vector3(sx, 0, STATION_Z - 1.15)
		tn.rotation.y = 0.0
	# orders that were being stitched at a vanished station go back to the queue
	for i in range(_station_order.size()):
		if _station_order[i] != null and not _station_has_tailor(i):
			(_station_order[i] as Dictionary)["state"] = 0
			_station_order[i] = null
	_sync_tags()


func _find_tag(n: Node3D) -> Label3D:
	for ch in n.get_children():
		if ch is Label3D:
			return ch as Label3D
	return null


func _sync_tags() -> void:
	for id in _tailors:
		var tg: Label3D = _tailors[id]["tag"]
		if tg == null:
			continue
		var e: Dictionary = {}
		for x in Game.employees:
			if int(x["id"]) == int(id):
				e = x
		if e.is_empty():
			continue
		var want: String = "%s\nTAILOR" % String(e["name"])
		if tg.text != want:
			tg.text = want


func _station_has_tailor(i: int) -> bool:
	for id in _tailors:
		if int(_tailors[id]["station"]) == i:
			return true
	return false


func _tailor_level_at(i: int) -> int:
	for id in _tailors:
		if int(_tailors[id]["station"]) == i:
			for e in Game.employees:
				if int(e["id"]) == int(id):
					return int(e["level"])
	return 1


# ================================================================ simulation
func _process(delta: float) -> void:
	if not Game.tailor_unlocked() or not built:
		return
	_t += delta
	_spawn(delta)
	_update_agents(delta)
	_update_orders(delta)
	_update_stations(delta)
	for id in _tailors:
		var r: Dictionary = _tailors[id]["rig"]
		CharFactory.animate(r, _t * 3.0, 0.0, _t, "")
	_warn_t -= delta


func _spawn(delta: float) -> void:
	if not (Game.running and Game.is_open()):
		return
	_spawn_t -= delta
	if _spawn_t > 0.0:
		return
	var lvl: int = int(Game.tailor["level"])
	_spawn_t = (16.0 / (0.75 + 0.25 * float(lvl))) * _rng.randf_range(0.7, 1.3) / clampf(Game.rating / 4.0, 0.6, 1.4)
	var open_orders: int = 0
	for o in _orders:
		if int((o as Dictionary)["state"]) < 2:
			open_orders += 1
	if _agents.size() >= 3 + 2 * lvl or open_orders >= int(Game.tailor["machines"]) * 2 + 1:
		return
	var svc: Dictionary = _pick_service()
	if svc.is_empty():
		return
	_agent_seed += 1
	var node: Node3D = CharFactory.build(_rng.randi(), "customer")
	add_child(node)
	var from := Vector3(24.0, 0, 11.6) if _rng.randf() < 0.7 else Vector3(-18.0, 0, 11.6)
	node.position = from
	var a := {"node": node, "rig": node.get_meta("rig"), "state": "enter", "svc": svc, "t": 0.0, "path": [Vector3(0, 0, 11.6), DOOR_IN, COUNTER_FRONT],
		"seat": -1, "order": null, "moving": true, "patience": float(svc["time"]) * 2.4 + 70.0, "waited": 0.0, "bag": null, "speed": _rng.randf_range(1.6, 2.1)}
	_agents.append(a)


func _pick_service() -> Dictionary:
	var weights := {"alter": 3.0, "shirt": 4.0, "trouser": 3.0, "kurta": 2.2, "uniform": 1.4, "blazer": 1.6, "embroid": 1.0, "wedding": 0.7}
	var pool: Array = []
	var total: float = 0.0
	for s in Data.TAILOR_SERVICES:
		if Game.tailor_service_ok(s):
			pool.append(s)
			total += float(weights[s["id"]])
	if pool.is_empty():
		return {}
	var r: float = _rng.randf() * total
	for s in pool:
		r -= float(weights[s["id"]])
		if r <= 0.0:
			return s
	return pool[0]


func _walk(a: Dictionary, delta: float) -> bool:
	## advances along a["path"]; returns true when the path is finished
	var path: Array = a["path"]
	var node: Node3D = a["node"]
	if path.is_empty():
		a["moving"] = false
		return true
	var tgt: Vector3 = path[0]
	var d: Vector3 = tgt - node.position
	d.y = 0.0
	var dist: float = d.length()
	var step: float = float(a["speed"]) * delta
	if dist <= step:
		node.position = Vector3(tgt.x, 0, tgt.z)
		path.pop_front()
		if path.is_empty():
			a["moving"] = false
			return true
	else:
		var dir: Vector3 = d / dist
		node.position += dir * step
		node.rotation.y = lerp_angle(node.rotation.y, atan2(dir.x, dir.z), clampf(10.0 * delta, 0.0, 1.0))
	a["moving"] = true
	return false


func _face(a: Dictionary, dir: Vector3, delta: float) -> void:
	(a["node"] as Node3D).rotation.y = lerp_angle((a["node"] as Node3D).rotation.y, atan2(dir.x, dir.z), clampf(8.0 * delta, 0.0, 1.0))


func _update_agents(delta: float) -> void:
	for a in _agents.duplicate():
		var ad: Dictionary = a
		var st: String = ad["state"]
		ad["t"] = float(ad["t"]) + delta
		match st:
			"enter":
				if _walk(ad, delta):
					ad["state"] = "queue"
			"queue":
				_face(ad, Vector3(0, 0, -1), delta)
				if _counter_user == null:
					_counter_user = ad
					ad["state"] = "ordering"
					ad["t"] = 0.0
			"ordering":
				_face(ad, Vector3(0, 0, -1), delta)
				if float(ad["t"]) > 1.6:
					_place_order(ad)
			"to_seat":
				if _walk(ad, delta):
					ad["state"] = "wait"
			"wait":
				ad["waited"] = float(ad["waited"]) + delta
				_face(ad, Vector3(1, 0, 0), delta)
				var o = ad["order"]
				if o != null:
					if int((o as Dictionary)["state"]) == 2:
						ad["state"] = "to_counter"
						ad["path"] = [COUNTER_FRONT]
						if int(ad["seat"]) >= 0:
							_seat_taken[int(ad["seat"])] = null
							ad["seat"] = -1
					elif int((o as Dictionary)["state"]) == 0 and float(ad["waited"]) > float(ad["patience"]):
						_cancel_order(ad)
			"to_counter":
				if _walk(ad, delta):
					ad["state"] = "collect_wait"
			"collect_wait":
				_face(ad, Vector3(0, 0, -1), delta)
				if _counter_user == null:
					_counter_user = ad
					ad["state"] = "paying"
					ad["t"] = 0.0
			"paying":
				_face(ad, Vector3(0, 0, -1), delta)
				if float(ad["t"]) > 1.4:
					_pay(ad)
			"leave":
				if _walk(ad, delta):
					(ad["node"] as Node3D).queue_free()
					_agents.erase(ad)
					continue
		var moving: bool = bool(ad["moving"]) and ["enter", "to_seat", "to_counter", "leave"].has(String(ad["state"]))
		CharFactory.animate(ad["rig"], _t * 3.0, 1.0 if moving else 0.0, _t, "")


func _free_seat() -> int:
	for i in range(_seat_taken.size()):
		if _seat_taken[i] == null:
			return i
	return -1


func _place_order(a: Dictionary) -> void:
	var svc: Dictionary = a["svc"]
	_counter_user = null
	Sfx.play("pick", 1.1)
	if not Game.tailor_has_fabric(svc):
		Game.tailor["lost"] = int(Game.tailor["lost"]) + 1
		Game.submit_rating(2.0)
		if _warn_t <= 0.0:
			_warn_t = 6.0
			Game.toast.emit("Out of %s! A customer left. Buy fabric in the Tailor menu." % String(Data.FABRICS[svc["fabric"]]["name"]))
		_leave(a)
		return
	Game.tailor_take_fabric(svc)
	var order := {"agent": a, "svc": svc, "progress": 0.0, "state": 0, "station": -1, "garment": null, "slot": -1}
	_orders.append(order)
	a["order"] = order
	var seat: int = _free_seat()
	if seat >= 0:
		_seat_taken[seat] = a
		a["seat"] = seat
		a["path"] = [Vector3(-2.6, 0, 4.6), SEATS[seat] + Vector3(0.9, 0, 0)]
	else:
		a["path"] = [Vector3(-1.0, 0, 5.2)]
	a["state"] = "to_seat"
	a["waited"] = 0.0
	Game.tailor_changed.emit()


func _cancel_order(a: Dictionary) -> void:
	var o: Dictionary = a["order"]
	_orders.erase(o)
	a["order"] = null
	Game.submit_rating(1.5)
	Game.tailor["lost"] = int(Game.tailor["lost"]) + 1
	if int(a["seat"]) >= 0:
		_seat_taken[int(a["seat"])] = null
		a["seat"] = -1
	Game.toast.emit("A customer got tired of waiting. Hire more tailors!")
	_leave(a)


func _leave(a: Dictionary) -> void:
	a["state"] = "leave"
	var n: Node3D = a["node"]
	a["path"] = [DOOR_IN, DOOR_OUT, Vector3(26.0 if n.position.x >= 0.0 else -20.0, 0, 11.6)]
	if int(a["seat"]) >= 0:
		_seat_taken[int(a["seat"])] = null
		a["seat"] = -1


func _pay(a: Dictionary) -> void:
	_counter_user = null
	var o: Dictionary = a["order"]
	var svc: Dictionary = o["svc"]
	var price: float = float(svc["price"]) * _rng.randf_range(0.95, 1.15)
	Game.tailor_finish(svc, price)
	Game.record_tailor_wait(float(a["waited"]), float(a["patience"]))
	Sfx.play("cash")
	if store.has_method("spawn_text"):
		store.spawn_text(global_position + COUNTER_FRONT + Vector3(0, 2.2, 0), "+$%d" % int(price), Color("7bed9f"))
	# garment leaves the rack
	if o["garment"] != null and is_instance_valid(o["garment"]):
		(o["garment"] as Node3D).queue_free()
	if int(o["slot"]) >= 0:
		_rack[int(o["slot"])] = null
	_orders.erase(o)
	a["order"] = null
	# customer carries the garment bag out
	var bag := MeshInstance3D.new()
	bag.mesh = CharFactory.box(0.2, 0.5, 0.1)
	bag.material_override = _m((svc["color"] as Color), 0.8)
	var hr: Node3D = a["rig"]["hand_r"]
	hr.add_child(bag)
	bag.position = Vector3(0, -0.2, 0.03)
	_leave(a)


func _update_orders(delta: float) -> void:
	# assign queued orders to idle stations that have a tailor
	for i in range(int(Game.tailor["machines"])):
		if _station_order[i] != null or not _station_has_tailor(i):
			continue
		for o in _orders:
			var od: Dictionary = o
			if int(od["state"]) == 0:
				od["state"] = 1
				od["station"] = i
				od["progress"] = 0.0
				_station_order[i] = od
				Sfx.play("cloth", 1.0, -4.0)
				break
	var any_working := false
	for i in range(_station_order.size()):
		var od = _station_order[i]
		if od == null:
			continue
		var d: Dictionary = od
		var svc: Dictionary = d["svc"]
		var speed: float = (1.0 + 0.22 * float(_tailor_level_at(i) - 1)) * Game.supervisor_bonus()
		d["progress"] = float(d["progress"]) + delta * speed
		any_working = true
		if float(d["progress"]) >= float(svc["time"]):
			d["state"] = 2
			_station_order[i] = null
			_hang_garment(d)
			Sfx.play("ready", 1.0, -3.0)
			Sfx.play("snip", 1.0, -6.0)
			Game.tailor_changed.emit()
	if any_working != _sew_on:
		_sew_on = any_working
	Sfx.loop_set("sew", _sew_on, -17.0)


func _hang_garment(o: Dictionary) -> void:
	var slot: int = -1
	for i in range(RACK_SLOTS):
		if _rack[i] == null:
			slot = i
			break
	var svc: Dictionary = o["svc"]
	var g := Node3D.new()
	add_child(g)
	var z: float = -0.5 - 1.0 + float(maxi(slot, 0)) * 0.42
	g.position = Vector3(6.2, 1.9, z)
	_b(g, Vector3(0.04, 0.04, 0.3), Vector3(0, 0.05, 0), _m(Color("b9bcc0"), 0.3, 0.8))
	var cloth := _b(g, Vector3(0.12, 1.0, 0.38), Vector3(0, -0.5, 0), _m((svc["color"] as Color), 0.85))
	cloth.rotation_degrees.x = 0.0
	if String(svc["id"]) in ["blazer", "wedding", "embroid"]:
		_b(g, Vector3(0.14, 0.4, 0.1), Vector3(0, -0.3, 0.1), _m(Color("d4a017"), 0.5))
	o["garment"] = g
	o["slot"] = slot
	if slot >= 0:
		_rack[slot] = o
	else:
		g.position.z = -1.2


func _update_stations(delta: float) -> void:
	for i in range(_stations.size()):
		var s: Dictionary = _stations[i]
		var od = _station_order[i]
		var bar: MeshInstance3D = s["bar"]
		var bar_bg: MeshInstance3D = s["bar_bg"]
		var tk: Label3D = s["ticket"]
		if od != null:
			var d: Dictionary = od
			var svc: Dictionary = d["svc"]
			var frac: float = clampf(float(d["progress"]) / float(svc["time"]), 0.0, 1.0)
			bar.visible = true
			bar_bg.visible = true
			bar.scale.x = maxf(frac, 0.001)
			bar.position.x = float(s["x"]) - 0.53 + 0.53 * frac
			tk.text = "%s\n%d%%" % [String(svc["name"]), int(frac * 100.0)]
			(s["needle"] as Node3D).position.y = 0.27 + 0.06 * sin(_t * 48.0)
			(s["wheel"] as Node3D).rotation.x += delta * 14.0
		else:
			bar.visible = false
			bar_bg.visible = false
			tk.text = "" if _station_has_tailor(i) else ("" if i >= int(Game.tailor["machines"]) else "Hire a tailor")
			(s["needle"] as Node3D).position.y = 0.27


func clear_world() -> void:
	for a in _agents:
		if is_instance_valid(a["node"]):
			(a["node"] as Node3D).queue_free()
	_agents.clear()
	_orders.clear()
	_station_order = [null, null, null, null, null, null]
	_seat_taken = [null, null, null]
	_rack = [null, null, null, null, null, null]
	_counter_user = null
	Sfx.loop_set("sew", false, -17.0)
