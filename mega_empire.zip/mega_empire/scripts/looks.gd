class_name Looks
extends RefCounted
## Character looks: wardrobe catalog (names + prices), preset characters (from the artwork), random looks.
## A look is a Dictionary: {base: "man"|"woman", skin, top, pant, shoe, hair, hat, glass, beard, pid} (indices into CATS).

const CATS := {
	"skin": [
		["Fair", "e9c4ae", 0], ["Light", "dba98a", 0], ["Wheat", "c98f6b", 0], ["Golden", "b87a52", 0],
		["Tan", "9c6440", 0], ["Brown", "7a4a2f", 0], ["Deep", "523020", 0], ["Ebony", "3b2418", 0],
	],
	"top": [
		["Staff Uniform", "ffffff", 0], ["White Tee", "f4f4f4", 0], ["Black Tee", "1e1e22", 0], ["Navy Polo", "1f3a6e", 0],
		["Sky Shirt", "8ec5ff", 120], ["Olive Shirt", "7a8a3b", 120], ["Maroon Shirt", "7a1f2b", 200], ["Denim Grey", "8a9099", 200],
		["Royal Blue", "2f5fd0", 250], ["Crimson", "e63946", 250], ["Hot Pink", "e8508e", 300], ["Emerald", "1f9d6b", 300],
		["Camel Jacket", "b88a5a", 350], ["Black Leather", "141414", 450], ["Gold Satin", "d4a017", 800],
	],
	"pant": [
		["Staff Uniform", "ffffff", 0], ["Black Jeans", "1a1a1e", 0], ["Denim Blue", "3a5a8a", 0], ["Charcoal", "3c4048", 0],
		["Khaki", "c2b280", 120], ["Navy Chino", "1b2a4a", 150], ["Brown", "6b4a32", 150], ["Olive Cargo", "5a6b3a", 200],
		["Cream", "ece8e0", 250], ["Red", "a4202c", 400],
	],
	"shoe": [
		["White Sneakers", "f2f2f2", 0], ["Black Shoes", "1b1b1b", 0], ["Brown Boots", "5a3b28", 100], ["Tan Loafers", "c9a577", 150],
		["Red Kicks", "d62828", 250], ["Blue Kicks", "2f6fd0", 250], ["Gold Kicks", "d4a017", 700],
	],
	"hair": [
		["Black", "1a1410", 0], ["Dark Brown", "3a2418", 0], ["Chestnut", "6b3f26", 0], ["Auburn", "8e3b22", 150],
		["Blonde", "d9b26a", 250], ["Platinum", "eee2c4", 400], ["Burgundy", "5a1630", 300], ["Midnight", "1b2450", 350], ["Pink", "e07aa8", 450],
	],
	"hat": [
		["No Hat", "000000", 0], ["Black Cap", "17171a", 80], ["White Cap", "f2f2f2", 80], ["Red Cap", "c1272d", 100],
		["Navy Beanie", "1f2f55", 90], ["Grey Beanie", "6d727c", 90], ["Black Fedora", "17171a", 300], ["Tan Fedora", "b8925a", 300], ["Gold Crown", "e0b020", 3000],
	],
	"glass": [
		["No Glasses", "000000", 0], ["Black Shades", "0b0b0d", 150], ["Aviator Gold", "d4a017", 300], ["Clear Frames", "2a2a30", 120], ["Neon Visor", "27e8ff", 600],
	],
	"beard": [
		["Clean", "000000", 0], ["Beard", "000000", 100],
	],
}
const CAT_ORDER := ["skin", "top", "pant", "shoe", "hair", "hat", "glass", "beard"]
const CAT_NAMES := {"skin": "Skin", "top": "Tops", "pant": "Pants", "shoe": "Shoes", "hair": "Hair", "hat": "Hats", "glass": "Glasses", "beard": "Beard"}
const ROLE_PRESET := {"guard": "s_guard", "supervisor": "s_manager", "cashier": "s_cashier", "stock": "s_stock", "cleaner": "s_cleaner"}

const PRESETS := [
	{"id": "m1", "name": "Rohan", "base": "man", "shades": false, "skin": "975945", "hair": "2c1d19", "top": "eae1e6", "pant": "1f242f", "shoe": "c9c2c5"},
	{"id": "m2", "name": "Jin", "base": "man", "shades": false, "skin": "daa185", "hair": "291c19", "top": "232123", "pant": "191818", "shoe": "413f41"},
	{"id": "m3", "name": "Arjun", "base": "man", "shades": false, "skin": "a15f48", "hair": "322c2d", "top": "6d1b24", "pant": "1d1b1c", "shoe": "aea8ab"},
	{"id": "m4", "name": "Karan", "base": "man", "shades": false, "skin": "f29d7d", "hair": "54362e", "top": "f0a078", "pant": "363d4e", "shoe": "cac0c3"},
	{"id": "m5", "name": "Sultan", "base": "man", "shades": false, "skin": "ce8c6c", "hair": "2e201c", "top": "202022", "pant": "252931", "shoe": "363233"},
	{"id": "m6", "name": "Raj", "base": "man", "shades": true, "skin": "bb6c5a", "hair": "2e2526", "top": "2e2a2d", "pant": "1c1a1b", "shoe": "3d3738"},
	{"id": "m7", "name": "Aman", "base": "man", "shades": true, "skin": "e8a47e", "hair": "4f4241", "top": "9e9992", "pant": "44464b", "shoe": "827670"},
	{"id": "m8", "name": "Imran", "base": "man", "shades": true, "skin": "d49c7a", "hair": "2d2728", "top": "ccbb7d", "pant": "223142", "shoe": "615e5b"},
	{"id": "m9", "name": "Sahil", "base": "man", "shades": false, "skin": "c88c6f", "hair": "634d45", "top": "692330", "pant": "3a3431", "shoe": "cec3b5"},
	{"id": "m10", "name": "Mahir", "base": "man", "shades": false, "skin": "c4886b", "hair": "2f231e", "top": "363234", "pant": "2a2828", "shoe": "4c4744"},
	{"id": "m11", "name": "Gulam", "base": "man", "shades": false, "skin": "4d3a32", "hair": "262122", "top": "f0eae8", "pant": "344660", "shoe": "dcccc1"},
	{"id": "w1", "name": "Aria", "base": "woman", "shades": false, "skin": "cc8560", "hair": "533b30", "top": "e2dbdb", "pant": "405570", "shoe": "d2cccb"},
	{"id": "w2", "name": "Zoya", "base": "woman", "shades": false, "skin": "f8af8a", "hair": "382821", "top": "8d1d20", "pant": "dc9971", "shoe": "e69d77"},
	{"id": "w3", "name": "Meera", "base": "woman", "shades": false, "skin": "ea9e7a", "hair": "443430", "top": "282632", "pant": "23212c", "shoe": "d8cdca"},
	{"id": "w4", "name": "Riya", "base": "woman", "shades": false, "skin": "eca27b", "hair": "d9a479", "top": "da996f", "pant": "bf7c59", "shoe": "e99e7e"},
	{"id": "w5", "name": "Tara", "base": "woman", "shades": false, "skin": "faad8d", "hair": "7e2e23", "top": "6f6968", "pant": "252324", "shoe": "9f9397"},
	{"id": "w6", "name": "Sana", "base": "woman", "shades": false, "skin": "fbbfa4", "hair": "312825", "top": "dacecd", "pant": "d99e83", "shoe": "d0c6c5"},
	{"id": "w7", "name": "Nisha", "base": "woman", "shades": false, "skin": "fdc7aa", "hair": "43332e", "top": "e27d7e", "pant": "da9c79", "shoe": "f3bfa3"},
	{"id": "s_guard", "name": "Guard", "base": "man", "shades": false, "skin": "b4674c", "hair": "433b27", "top": "a4b2da", "pant": "171821", "shoe": "353231"},
	{"id": "s_manager", "name": "Manager", "base": "man", "shades": false, "skin": "b36b55", "hair": "2b201e", "top": "965f61", "pant": "191a25", "shoe": "3d3838"},
	{"id": "s_cashier", "name": "Cashier", "base": "woman", "shades": false, "skin": "fdc2a6", "hair": "412921", "top": "94161e", "pant": "19161a", "shoe": "d3cbce"},
	{"id": "s_stock", "name": "Stock Lead", "base": "man", "shades": false, "skin": "a25f45", "hair": "2b1d1a", "top": "312f3a", "pant": "92724d", "shoe": "443d3c"},
	{"id": "s_cleaner", "name": "Cleaner", "base": "man", "shades": false, "skin": "aa5b43", "hair": "31211c", "top": "283256", "pant": "171b2a", "shoe": "4d4442"},
]


static func color(cat: String, idx: int) -> Color:
	var arr: Array = CATS[cat]
	return Color(String(arr[clampi(idx, 0, arr.size() - 1)][1]))


static func item_name(cat: String, idx: int) -> String:
	var arr: Array = CATS[cat]
	return String(arr[clampi(idx, 0, arr.size() - 1)][0])


static func price(cat: String, idx: int) -> int:
	var arr: Array = CATS[cat]
	return int(arr[clampi(idx, 0, arr.size() - 1)][2])


static func count(cat: String) -> int:
	return (CATS[cat] as Array).size()


static func nearest(cat: String, c: Color, start: int = 0, free_only: bool = false) -> int:
	var best := start
	var bd := 1e9
	var arr: Array = CATS[cat]
	for i in range(start, arr.size()):
		if free_only and int(arr[i][2]) > 0:
			continue
		var d: Color = Color(String(arr[i][1]))
		var dist: float = (d.r - c.r) * (d.r - c.r) * 0.3 + (d.g - c.g) * (d.g - c.g) * 0.59 + (d.b - c.b) * (d.b - c.b) * 0.11
		if dist < bd:
			bd = dist
			best = i
	return best


static func preset_by_id(pid: String) -> Dictionary:
	for p in PRESETS:
		if p["id"] == pid:
			return p
	return {}


static func from_preset(p: Dictionary, uniform: bool = false) -> Dictionary:
	var look := {"base": p["base"], "pid": p["id"]}
	look["skin"] = nearest("skin", Color(String(p["skin"])))
	look["hair"] = nearest("hair", Color(String(p["hair"])))
	look["top"] = 0 if uniform else nearest("top", Color(String(p["top"])), 1)
	look["pant"] = 0 if uniform else nearest("pant", Color(String(p["pant"])), 1)
	look["shoe"] = nearest("shoe", Color(String(p["shoe"])))
	look["hat"] = 0
	look["glass"] = 1 if bool(p["shades"]) else 0
	look["beard"] = 0
	return look


static func random_look(seed_value: int, role: String) -> Dictionary:
	var rng := RandomNumberGenerator.new()
	rng.seed = (seed_value * 2246822519 + 7) % 4294967296
	rng.randi()
	var staff: bool = ROLE_PRESET.has(role)
	var base: String = "woman" if rng.randf() < 0.42 else "man"
	var pool: Array = []
	for p in PRESETS:
		if p["base"] == base and not String(p["id"]).begins_with("s_"):
			pool.append(p)
	var p: Dictionary = pool[rng.randi() % pool.size()]
	var look: Dictionary = from_preset(p, staff)
	if not staff and rng.randf() < 0.45:
		look["top"] = rng.randi_range(1, count("top") - 1)
		look["pant"] = rng.randi_range(1, count("pant") - 1)
	if not staff and rng.randf() < 0.25:
		look["hat"] = rng.randi_range(1, 5)
	if base == "man" and rng.randf() < 0.35:
		look["beard"] = 1
	if staff:
		look["hat"] = 0
	return look


static func owned_key(cat: String, idx: int) -> String:
	return "%s:%d" % [cat, idx]
