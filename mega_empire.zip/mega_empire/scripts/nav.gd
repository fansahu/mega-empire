class_name NavGrid
extends RefCounted
## Cheap grid pathfinding (AStarGrid2D) shared by customers and staff.

const CELL := 0.5
const ORIGIN := Vector2(-24.0, -14.0)
const W := 96
const H := 76

var astar := AStarGrid2D.new()


func _init() -> void:
	astar.region = Rect2i(0, 0, W, H)
	astar.cell_size = Vector2(CELL, CELL)
	astar.offset = ORIGIN + Vector2(CELL * 0.5, CELL * 0.5)
	astar.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES
	astar.default_compute_heuristic = AStarGrid2D.HEURISTIC_OCTILE
	astar.default_estimate_heuristic = AStarGrid2D.HEURISTIC_OCTILE
	astar.update()


func world_to_cell(p: Vector3) -> Vector2i:
	var cx: int = int(floor((p.x - ORIGIN.x) / CELL))
	var cz: int = int(floor((p.z - ORIGIN.y) / CELL))
	return Vector2i(clampi(cx, 0, W - 1), clampi(cz, 0, H - 1))


func cell_to_world(c: Vector2i) -> Vector3:
	return Vector3(ORIGIN.x + (float(c.x) + 0.5) * CELL, 0.0, ORIGIN.y + (float(c.y) + 0.5) * CELL)


## Block (or unblock) a world rectangle given by x0,z0 -> x1,z1.
func set_rect(x0: float, z0: float, x1: float, z1: float, solid: bool) -> void:
	var a: Vector2i = world_to_cell(Vector3(minf(x0, x1), 0, minf(z0, z1)))
	var b: Vector2i = world_to_cell(Vector3(maxf(x0, x1), 0, maxf(z0, z1)))
	for x in range(a.x, b.x + 1):
		for y in range(a.y, b.y + 1):
			astar.set_point_solid(Vector2i(x, y), solid)


func _nearest_free(c: Vector2i) -> Vector2i:
	if not astar.is_point_solid(c):
		return c
	for r in range(1, 10):
		for dx in range(-r, r + 1):
			for dy in range(-r, r + 1):
				if absi(dx) != r and absi(dy) != r:
					continue
				var n := Vector2i(c.x + dx, c.y + dy)
				if astar.is_in_boundsv(n) and not astar.is_point_solid(n):
					return n
	return c


func _los(a: Vector2, b: Vector2) -> bool:
	var d: float = a.distance_to(b)
	var steps: int = int(ceil(d / (CELL * 0.4)))
	for i in range(steps + 1):
		var p: Vector2 = a.lerp(b, float(i) / float(maxi(steps, 1)))
		var c := Vector2i(int(floor((p.x - ORIGIN.x) / CELL)), int(floor((p.y - ORIGIN.y) / CELL)))
		if not astar.is_in_boundsv(c) or astar.is_point_solid(c):
			return false
	return true


## Returns a smoothed list of Vector3 waypoints from -> to (empty if unreachable).
func find_path(from: Vector3, to: Vector3) -> Array:
	var a: Vector2i = _nearest_free(world_to_cell(from))
	var b: Vector2i = _nearest_free(world_to_cell(to))
	var raw: PackedVector2Array = astar.get_point_path(a, b)
	if raw.size() == 0:
		return []
	var pts: Array = []
	for p in raw:
		pts.append(p)
	var out: Array = []
	var i := 0
	while i < pts.size() - 1:
		var j: int = pts.size() - 1
		while j > i + 1 and not _los(pts[i], pts[j]):
			j -= 1
		out.append(Vector3(pts[j].x, 0.0, pts[j].y))
		i = j
	if out.is_empty():
		out.append(Vector3(pts[pts.size() - 1].x, 0.0, pts[pts.size() - 1].y))
	return out
