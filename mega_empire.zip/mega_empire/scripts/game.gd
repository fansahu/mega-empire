extends Node
## Autoload "Game": economy, inventory, staff, upgrades, missions, save/load, settings.
## Every number shown in the UI comes from this file (no fake stats).

signal money_changed(v: float)
signal toast(msg: String)
signal changed
signal day_ended(report: Dictionary)
signal quality_changed
signal sale_made(amount: float)
signal upgrade_bought(id: String)

const DAY_LENGTH := 240.0
const SAVE_PATH := "user://mega_empire_save_v1.json"
const MAX_SHELVES := 25
const START_SHELVES := 6
const OFFLINE_CAP_SEC := 8.0 * 3600.0

var money: float = 1000.0
var day: int = 1
var day_time: float = 0.0
var total_revenue: float = 0.0
var total_customers: int = 0
var rating: float = 4.0
var ratings_hist: Array = []
var warehouse: Dictionary = {}
var shelf_product: Array = []
var shelf_stock: Array = []
var price_mult: Dictionary = {}
var upgrades: Dictionary = {}
var employees: Array = []
var next_emp_id: int = 1
var today: Dictionary = {}
var history: Array = []
var done_missions: Array = []
var avg_net_per_sec: float = 0.0
var settings: Dictionary = {"quality": 0, "music": 0.5, "sfx": 0.8, "ambient": 0.4, "speed": 1}
var last_unix: int = 0
var cleanliness: float = 1.0
var running: bool = false
var stats: Dictionary = {"theft_loss": 0.0, "lost_sales": 0, "items_sold": 0}
var _mission_timer: float = 0.0
var _day_start_money: float = 0.0
var pending_offline: float = 0.0


func _ready() -> void:
	new_game()


# ------------------------------------------------------------------ setup
func new_game() -> void:
	money = 1000.0
	day = 1
	day_time = 0.0
	total_revenue = 0.0
	total_customers = 0
	rating = 4.0
	ratings_hist = []
	warehouse = {}
	shelf_product = []
	shelf_stock = []
	price_mult = {}
	upgrades = {"shelves": START_SHELVES, "shelf_cap": 1, "lanes": 1, "parking": 1, "warehouse": 1, "store_level": 1, "ads": 0}
	employees = []
	next_emp_id = 1
	history = []
	done_missions = []
	avg_net_per_sec = 0.0
	cleanliness = 1.0
	stats = {"theft_loss": 0.0, "lost_sales": 0, "items_sold": 0}
	_reset_today()
	for p in Data.PRODUCTS:
		price_mult[p["id"]] = 1.0
		warehouse[p["id"]] = 0
	var start_ids: Array = ["milk", "bread", "apple", "cola", "chips", "water"]
	for i in range(MAX_SHELVES):
		shelf_product.append(start_ids[i] if i < start_ids.size() else "")
		shelf_stock.append(0)
	for i in range(start_ids.size()):
		shelf_stock[i] = int(shelf_capacity() * 0.6)
	warehouse["eggs"] = 20
	warehouse["tomato"] = 20
	warehouse["juice"] = 20
	_day_start_money = money
	changed.emit()


func _reset_today() -> void:
	today = {"revenue": 0.0, "cogs": 0.0, "customers": 0, "items": 0, "theft": 0.0, "lost": 0, "rating_sum": 0.0, "rating_n": 0}


# ------------------------------------------------------------------ lookups
func product(id: String) -> Dictionary:
	return Data.product_by_id(id)


func sell_price(id: String) -> float:
	var p: Dictionary = Data.product_by_id(id)
	if p.is_empty():
		return 0.0
	return snappedf(float(p["sell"]) * float(price_mult.get(id, 1.0)), 0.01)


func shelf_capacity() -> int:
	return int(24.0 * (1.0 + 0.5 * float(int(upgrades["shelf_cap"]) - 1)))


func warehouse_capacity() -> int:
	return 100 + 120 * (int(upgrades["warehouse"]) - 1)


func warehouse_used() -> int:
	var n := 0
	for k in warehouse:
		n += int(warehouse[k])
	return n


func shelf_unlocked(i: int) -> bool:
	return i < int(upgrades["shelves"])


func total_shelf_stock() -> int:
	var n := 0
	for i in range(MAX_SHELVES):
		if shelf_unlocked(i):
			n += int(shelf_stock[i])
	return n


func employee_count(type: String) -> int:
	var n := 0
	for e in employees:
		if e["type"] == type:
			n += 1
	return n


func supervisor_bonus() -> float:
	var b := 1.0
	for e in employees:
		if e["type"] == "supervisor":
			b += 0.10 * float(e["level"])
	return b


func emp_salary(e: Dictionary) -> float:
	return float(Data.EMP_TYPES[e["type"]]["salary"]) * (1.0 + 0.4 * float(int(e["level"]) - 1))


func max_hire(type: String) -> int:
	match type:
		"cashier":
			return int(upgrades["lanes"])
		"stock":
			return 3
		"cleaner":
			return 2
		"guard":
			return 2
		"supervisor":
			return 2
	return 0


func rent_per_day() -> float:
	return 45.0 + 35.0 * float(int(upgrades["store_level"]) - 1)


func maintenance_per_day() -> float:
	return 2.0 * float(int(upgrades["shelves"])) + 10.0 * float(int(upgrades["lanes"])) + 6.0 * float(int(upgrades["parking"]))


func salaries_per_day() -> float:
	var s := 0.0
	for e in employees:
		s += emp_salary(e)
	return s


func ads_per_day() -> float:
	return float(Data.ADS_DAILY[int(upgrades["ads"])])


func spawn_rate_mult() -> float:
	var r := 0.55 + 0.9 * clampf(rating / 5.0, 0.0, 1.0)
	r *= 1.0 + 0.12 * float(int(upgrades["parking"]) - 1)
	r *= float(Data.ADS_MULT[int(upgrades["ads"])])
	r *= 1.0 + 0.08 * float(int(upgrades["store_level"]) - 1)
	return r


func max_customers_inside() -> int:
	var by_parking: int = 4 + 3 * int(upgrades["parking"])
	var by_quality: int = [8, 14, 22, 30][clampi(int(settings["quality"]), 0, 3)]
	return mini(by_parking, by_quality)


# ------------------------------------------------------------------ inventory
func order_stock(id: String, qty: int) -> bool:
	var p: Dictionary = Data.product_by_id(id)
	if p.is_empty() or qty <= 0:
		return false
	var room: int = warehouse_capacity() - warehouse_used()
	var n: int = mini(qty, room)
	if n <= 0:
		toast.emit("Warehouse is full! Upgrade warehouse size.")
		return false
	var cost: float = float(p["buy"]) * float(n)
	if money < cost:
		n = int(floor(money / float(p["buy"])))
		if n <= 0:
			toast.emit("Not enough money.")
			return false
		cost = float(p["buy"]) * float(n)
	money -= cost
	warehouse[id] = int(warehouse.get(id, 0)) + n
	today["cogs"] = float(today["cogs"])  # cost of goods is booked on sale
	money_changed.emit(money)
	changed.emit()
	Sfx.play("click")
	return true


func move_to_shelf(slot: int, qty: int) -> int:
	var pid: String = shelf_product[slot]
	if pid == "":
		return 0
	var room: int = shelf_capacity() - int(shelf_stock[slot])
	var have: int = int(warehouse.get(pid, 0))
	var n: int = mini(mini(qty, room), have)
	if n <= 0:
		return 0
	warehouse[pid] = have - n
	shelf_stock[slot] = int(shelf_stock[slot]) + n
	changed.emit()
	return n


func warehouse_take(pid: String, qty: int) -> int:
	var n: int = mini(qty, int(warehouse.get(pid, 0)))
	warehouse[pid] = int(warehouse.get(pid, 0)) - n
	if n > 0:
		changed.emit()
	return n


## Adds goods to a shelf; returns how many did not fit.
func shelf_add(slot: int, qty: int) -> int:
	var room: int = shelf_capacity() - int(shelf_stock[slot])
	var n: int = mini(qty, maxi(room, 0))
	shelf_stock[slot] = int(shelf_stock[slot]) + n
	if n > 0:
		changed.emit()
	return qty - n


func assign_shelf(slot: int, pid: String) -> void:
	var old: String = shelf_product[slot]
	if old == pid:
		return
	if old != "":
		warehouse[old] = int(warehouse.get(old, 0)) + int(shelf_stock[slot])
	shelf_product[slot] = pid
	shelf_stock[slot] = 0
	changed.emit()
	Sfx.play("click")


func shelf_take(slot: int, qty: int) -> int:
	var n: int = mini(qty, int(shelf_stock[slot]))
	shelf_stock[slot] = int(shelf_stock[slot]) - n
	if n > 0:
		changed.emit()
	return n


func shelf_give_back(slot: int, qty: int) -> void:
	shelf_stock[slot] = mini(int(shelf_stock[slot]) + qty, shelf_capacity())
	changed.emit()


func set_price_mult(id: String, m: float) -> void:
	price_mult[id] = clampf(snappedf(m, 0.05), 0.6, 1.8)
	changed.emit()


# ------------------------------------------------------------------ sales / ratings
func record_sale(items: Array, stolen: bool) -> float:
	var revenue := 0.0
	var cogs := 0.0
	var count := 0
	for it in items:
		var p: Dictionary = Data.product_by_id(it["pid"])
		revenue += float(it["price"]) * float(it["qty"])
		cogs += float(p["buy"]) * float(it["qty"])
		count += int(it["qty"])
	if stolen:
		stats["theft_loss"] = float(stats["theft_loss"]) + revenue
		today["theft"] = float(today["theft"]) + revenue
		today["cogs"] = float(today["cogs"]) + cogs
		changed.emit()
		return 0.0
	money += revenue
	total_revenue += revenue
	total_customers += 1
	today["revenue"] = float(today["revenue"]) + revenue
	today["cogs"] = float(today["cogs"]) + cogs
	today["customers"] = int(today["customers"]) + 1
	today["items"] = int(today["items"]) + count
	stats["items_sold"] = int(stats["items_sold"]) + count
	money_changed.emit(money)
	sale_made.emit(revenue)
	changed.emit()
	return revenue


func record_lost_sale() -> void:
	stats["lost_sales"] = int(stats["lost_sales"]) + 1
	today["lost"] = int(today["lost"]) + 1


func submit_rating(stars: float) -> void:
	ratings_hist.append(clampf(stars, 1.0, 5.0))
	if ratings_hist.size() > 40:
		ratings_hist.pop_front()
	var s := 0.0
	for r in ratings_hist:
		s += float(r)
	rating = s / float(ratings_hist.size())
	today["rating_sum"] = float(today["rating_sum"]) + stars
	today["rating_n"] = int(today["rating_n"]) + 1


# ------------------------------------------------------------------ staff
func hire(type: String) -> bool:
	if employee_count(type) >= max_hire(type):
		toast.emit("Maximum reached (build more lanes / upgrade).")
		return false
	var cost: float = float(Data.EMP_TYPES[type]["hire"])
	if money < cost:
		toast.emit("Not enough money to hire.")
		return false
	money -= cost
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var emp := {"id": next_emp_id, "type": type, "name": Data.FIRST_NAMES[rng.randi() % Data.FIRST_NAMES.size()], "level": 1, "tasks": 0, "seed": rng.randi()}
	next_emp_id += 1
	employees.append(emp)
	money_changed.emit(money)
	changed.emit()
	Sfx.play("upgrade")
	return true


func fire(id: int) -> void:
	for i in range(employees.size()):
		if int(employees[i]["id"]) == id:
			employees.remove_at(i)
			break
	changed.emit()


func train_cost(e: Dictionary) -> float:
	return 150.0 * float(e["level"]) * float(e["level"])


func train(id: int) -> bool:
	for e in employees:
		if int(e["id"]) == id:
			if int(e["level"]) >= 5:
				return false
			var c: float = train_cost(e)
			if money < c:
				toast.emit("Not enough money to train.")
				return false
			money -= c
			e["level"] = int(e["level"]) + 1
			money_changed.emit(money)
			changed.emit()
			Sfx.play("upgrade")
			return true
	return false


func emp_of_type(type: String) -> Array:
	var out: Array = []
	for e in employees:
		if e["type"] == type:
			out.append(e)
	return out


# ------------------------------------------------------------------ upgrades
func upgrade_level(id: String) -> int:
	return int(upgrades[id])


func upgrade_max(id: String) -> int:
	for u in Data.UPGRADES:
		if u["id"] == id:
			if id == "shelves":
				return MAX_SHELVES
			return int(u["max"])
	return 1


func upgrade_cost(id: String) -> float:
	var lvl: int = int(upgrades[id])
	match id:
		"shelves":
			return 250.0 * pow(1.28, float(lvl - START_SHELVES))
		"shelf_cap":
			return 400.0 * pow(2.0, float(lvl - 1))
		"lanes":
			return [0.0, 900.0, 3000.0, 0.0][clampi(lvl, 0, 3)]
		"parking":
			return [0.0, 600.0, 1800.0, 5000.0, 0.0][clampi(lvl, 0, 4)]
		"warehouse":
			return 500.0 * pow(2.0, float(lvl - 1))
		"store_level":
			return float(Data.STORE_LEVEL_COST[clampi(lvl, 0, 4)])
		"ads":
			return float(Data.ADS_COST[clampi(lvl + 1, 0, 3)]) if lvl < 3 else 0.0
	return 0.0


func upgrade_maxed(id: String) -> bool:
	return int(upgrades[id]) >= upgrade_max(id) if id != "ads" else int(upgrades[id]) >= 3


func buy_upgrade(id: String) -> bool:
	if upgrade_maxed(id):
		return false
	var c: float = upgrade_cost(id)
	if money < c:
		toast.emit("Not enough money.")
		return false
	money -= c
	upgrades[id] = int(upgrades[id]) + 1
	money_changed.emit(money)
	changed.emit()
	upgrade_bought.emit(id)
	Sfx.play("upgrade")
	return true


# ------------------------------------------------------------------ missions
func missions() -> Array:
	return [
		{"id": "m_customers", "text": "Serve 25 customers", "cur": total_customers, "goal": 25, "reward": 150.0},
		{"id": "m_revenue", "text": "Earn $1,500 total revenue", "cur": int(total_revenue), "goal": 1500, "reward": 250.0},
		{"id": "m_cashier", "text": "Hire your first cashier", "cur": employee_count("cashier"), "goal": 1, "reward": 100.0},
		{"id": "m_shelves", "text": "Own 10 shelf faces", "cur": int(upgrades["shelves"]), "goal": 10, "reward": 300.0},
		{"id": "m_rating", "text": "Reach 4.5 star rating (20+ ratings)", "cur": int(rating * 10.0) if ratings_hist.size() >= 20 else 0, "goal": 45, "reward": 500.0},
		{"id": "m_lane2", "text": "Build a 2nd checkout lane", "cur": int(upgrades["lanes"]), "goal": 2, "reward": 400.0},
		{"id": "m_day5", "text": "Survive until day 5", "cur": day, "goal": 5, "reward": 600.0},
		{"id": "m_level3", "text": "Upgrade store interior to level 3", "cur": int(upgrades["store_level"]), "goal": 3, "reward": 1500.0},
		{"id": "m_revenue2", "text": "Earn $25,000 total revenue", "cur": int(total_revenue), "goal": 25000, "reward": 4000.0},
		{"id": "m_staff", "text": "Employ 6 staff members", "cur": employees.size(), "goal": 6, "reward": 2000.0},
	]


func check_missions() -> void:
	for m in missions():
		if int(m["cur"]) >= int(m["goal"]) and not done_missions.has(m["id"]):
			done_missions.append(m["id"])
			money += float(m["reward"])
			money_changed.emit(money)
			toast.emit("Mission complete: %s  (+$%d)" % [m["text"], int(m["reward"])])
			Sfx.play("upgrade")
			changed.emit()


# ------------------------------------------------------------------ time / day cycle
func _process(delta: float) -> void:
	if not running:
		return
	day_time += delta
	_mission_timer += delta
	if _mission_timer > 2.0:
		_mission_timer = 0.0
		check_missions()
	if day_time >= DAY_LENGTH:
		day_time -= DAY_LENGTH
		_end_day()


func is_open() -> bool:
	return day_time < DAY_LENGTH * 0.85


func _end_day() -> void:
	var rent: float = rent_per_day()
	var sal: float = salaries_per_day()
	var maint: float = maintenance_per_day()
	var ads: float = ads_per_day()
	var expenses: float = rent + sal + maint + ads
	money -= expenses
	var gross: float = float(today["revenue"]) - float(today["cogs"])
	var profit: float = gross - expenses
	var rep := {
		"day": day, "revenue": today["revenue"], "cogs": today["cogs"], "rent": rent, "salaries": sal,
		"maintenance": maint, "ads": ads, "theft": today["theft"], "customers": today["customers"],
		"items": today["items"], "lost": today["lost"], "profit": profit,
		"rating": rating, "money": money,
	}
	history.append(rep)
	if history.size() > 14:
		history.pop_front()
	var net_per_sec: float = profit / DAY_LENGTH
	avg_net_per_sec = net_per_sec if history.size() <= 1 else lerpf(avg_net_per_sec, net_per_sec, 0.4)
	day += 1
	_reset_today()
	money_changed.emit(money)
	day_ended.emit(rep)
	changed.emit()
	save_game()


# ------------------------------------------------------------------ settings
func set_setting(key: String, value: Variant) -> void:
	settings[key] = value
	if key == "quality":
		quality_changed.emit()
	if key in ["music", "sfx", "ambient"]:
		Sfx.apply_volumes()
	save_game()


# ------------------------------------------------------------------ save / load
func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)


func save_game() -> void:
	var d := {
		"money": money, "day": day, "day_time": day_time, "total_revenue": total_revenue,
		"total_customers": total_customers, "rating": rating, "ratings_hist": ratings_hist,
		"warehouse": warehouse, "shelf_product": shelf_product, "shelf_stock": shelf_stock,
		"price_mult": price_mult, "upgrades": upgrades, "employees": employees,
		"next_emp_id": next_emp_id, "history": history, "done_missions": done_missions,
		"avg_net_per_sec": avg_net_per_sec, "settings": settings, "stats": stats,
		"today": today, "unix": int(Time.get_unix_time_from_system()),
	}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(d))
		f.close()


func load_game() -> bool:
	if not has_save():
		return false
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return false
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		return false
	var d: Dictionary = parsed
	new_game()
	money = float(d.get("money", money))
	day = int(d.get("day", day))
	day_time = float(d.get("day_time", 0.0))
	total_revenue = float(d.get("total_revenue", 0.0))
	total_customers = int(d.get("total_customers", 0))
	rating = float(d.get("rating", 4.0))
	ratings_hist = d.get("ratings_hist", [])
	var wh: Dictionary = d.get("warehouse", {})
	for k in wh:
		warehouse[k] = int(wh[k])
	var sp: Array = d.get("shelf_product", [])
	var ss: Array = d.get("shelf_stock", [])
	for i in range(mini(MAX_SHELVES, sp.size())):
		shelf_product[i] = str(sp[i])
		shelf_stock[i] = int(ss[i]) if i < ss.size() else 0
	var pm: Dictionary = d.get("price_mult", {})
	for k in pm:
		price_mult[k] = float(pm[k])
	var up: Dictionary = d.get("upgrades", {})
	for k in up:
		upgrades[k] = int(up[k])
	employees = d.get("employees", [])
	for e in employees:
		e["id"] = int(e["id"])
		e["level"] = int(e["level"])
		e["tasks"] = int(e.get("tasks", 0))
		e["seed"] = int(e.get("seed", 1))
	next_emp_id = int(d.get("next_emp_id", employees.size() + 1))
	history = d.get("history", [])
	done_missions = d.get("done_missions", [])
	avg_net_per_sec = float(d.get("avg_net_per_sec", 0.0))
	var st: Dictionary = d.get("settings", {})
	for k in st:
		settings[k] = st[k]
	stats = d.get("stats", stats)
	var td: Dictionary = d.get("today", {})
	for k in td:
		today[k] = td[k]
	var unix: int = int(d.get("unix", 0))
	pending_offline = 0.0
	if unix > 0:
		var elapsed: float = clampf(float(int(Time.get_unix_time_from_system()) - unix), 0.0, OFFLINE_CAP_SEC)
		if elapsed > 60.0 and avg_net_per_sec > 0.0:
			pending_offline = avg_net_per_sec * elapsed * 0.5
	changed.emit()
	return true


func collect_offline() -> float:
	var v: float = pending_offline
	pending_offline = 0.0
	if v > 0.0:
		money += v
		money_changed.emit(money)
		changed.emit()
	return v


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		if running:
			save_game()
