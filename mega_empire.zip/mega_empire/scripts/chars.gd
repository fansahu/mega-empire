class_name CharFactory
extends RefCounted
## Procedural 3D humanoids: varied faces, hair, clothes, heights. Animated by code (walk, pick, scan, carry).

static var _mats: Dictionary = {}
static var _meshes: Dictionary = {}

const SKINS := ["f1c27d", "e0ac69", "c68642", "8d5524", "ffdbac", "a96a43", "6b4226"]
const HAIRS := ["1b1b1b", "3b2417", "5a3825", "8a5a2b", "c9a15c", "7d7d7d", "a52a2a", "0f0f1e"]
const SHIRTS := ["ef476f", "118ab2", "06d6a0", "ffd166", "8338ec", "fb5607", "3a86ff", "e63946", "2a9d8f", "f4a261", "6d597a", "b5838d"]
const PANTS := ["34406b", "2b2d42", "5c5470", "3d405b", "6b705c", "4a4e69", "1d3557", "7f5539"]


static func mat(c: Color, rough: float = 0.85, metal: float = 0.0) -> StandardMaterial3D:
	var key := "%s_%.2f_%.2f" % [c.to_html(), rough, metal]
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	_mats[key] = m
	return m


static func emissive(c: Color, energy: float = 2.0) -> StandardMaterial3D:
	var key := "em_%s_%.1f" % [c.to_html(), energy]
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.emission_enabled = true
	m.emission = c
	m.emission_energy_multiplier = energy
	_mats[key] = m
	return m


static func capsule(r: float, h: float) -> CapsuleMesh:
	var key := "cap_%.3f_%.3f" % [r, h]
	if not _meshes.has(key):
		var m := CapsuleMesh.new()
		m.radius = r
		m.height = h
		m.radial_segments = 10
		m.rings = 4
		_meshes[key] = m
	return _meshes[key]


static func sphere(r: float, h: float = -1.0) -> SphereMesh:
	var hh: float = h if h > 0.0 else r * 2.0
	var key := "sph_%.3f_%.3f" % [r, hh]
	if not _meshes.has(key):
		var m := SphereMesh.new()
		m.radius = r
		m.height = hh
		m.radial_segments = 12
		m.rings = 6
		_meshes[key] = m
	return _meshes[key]


static func box(x: float, y: float, z: float) -> BoxMesh:
	var key := "box_%.3f_%.3f_%.3f" % [x, y, z]
	if not _meshes.has(key):
		var m := BoxMesh.new()
		m.size = Vector3(x, y, z)
		_meshes[key] = m
	return _meshes[key]


static func cyl(rt: float, rb: float, h: float, seg: int = 12) -> CylinderMesh:
	var key := "cyl_%.3f_%.3f_%.3f_%d" % [rt, rb, h, seg]
	if not _meshes.has(key):
		var m := CylinderMesh.new()
		m.top_radius = rt
		m.bottom_radius = rb
		m.height = h
		m.radial_segments = seg
		m.rings = 1
		_meshes[key] = m
	return _meshes[key]


static func mi(parent: Node, mesh: Mesh, material: Material, pos: Vector3 = Vector3.ZERO, scl: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var n := MeshInstance3D.new()
	n.mesh = mesh
	n.material_override = material
	n.position = pos
	n.scale = scl
	parent.add_child(n)
	return n


static func pivot(parent: Node, pos: Vector3) -> Node3D:
	var n := Node3D.new()
	n.position = pos
	parent.add_child(n)
	return n


## role: customer | cashier | stock | cleaner | guard | supervisor
static func build(seed_value: int, role: String = "customer") -> Node3D:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value
	var root := Node3D.new()
	var skin := Color(SKINS[rng.randi() % SKINS.size()])
	var hair_c := Color(HAIRS[rng.randi() % HAIRS.size()])
	var shirt_c := Color(SHIRTS[rng.randi() % SHIRTS.size()])
	var pants_c := Color(PANTS[rng.randi() % PANTS.size()])
	var shoe_c := Color("1e1e1e")
	var female: bool = rng.randf() < 0.5
	var hair_style: int = rng.randi() % 5
	var uniform_cap := false
	match role:
		"cashier":
			shirt_c = Color("2a9d8f")
			pants_c = Color("264653")
		"stock":
			shirt_c = Color("3d5a80")
			pants_c = Color("293241")
			uniform_cap = true
		"cleaner":
			shirt_c = Color("0077b6")
			pants_c = Color("0077b6")
		"guard":
			shirt_c = Color("14213d")
			pants_c = Color("14213d")
			uniform_cap = true
		"supervisor":
			shirt_c = Color("f8f9fa")
			pants_c = Color("22223b")
	var height_k: float = rng.randf_range(0.92, 1.07) * (0.95 if female else 1.0)
	root.scale = Vector3(height_k, height_k, height_k)
	var skin_m := mat(skin, 0.7)
	var shirt_m := mat(shirt_c, 0.85)
	var pants_m := mat(pants_c, 0.9)
	var rig := {}

	# legs
	for side in [-1, 1]:
		var lp := pivot(root, Vector3(0.1 * side, 0.82, 0))
		mi(lp, capsule(0.075, 0.82), pants_m, Vector3(0, -0.41, 0))
		mi(lp, box(0.13, 0.07, 0.25), mat(shoe_c, 0.6), Vector3(0, -0.785, 0.04))
		rig["leg_l" if side < 0 else "leg_r"] = lp

	# torso
	var torso := pivot(root, Vector3(0, 1.14, 0))
	mi(torso, capsule(0.17, 0.66), shirt_m, Vector3.ZERO, Vector3(1.0, 1.0, 0.62))
	rig["torso"] = torso
	if female:
		mi(torso, sphere(0.055), shirt_m, Vector3(-0.075, 0.12, 0.085))
		mi(torso, sphere(0.055), shirt_m, Vector3(0.075, 0.12, 0.085))
	match role:
		"cashier":
			mi(torso, box(0.3, 0.38, 0.03), mat(Color("f1faee")), Vector3(0, -0.06, 0.1))
		"stock":
			mi(torso, box(0.36, 0.42, 0.26), mat(Color("ff8c00")), Vector3(0, 0.0, 0.0))
			mi(torso, box(0.37, 0.04, 0.27), mat(Color("e9ecef"), 0.4), Vector3(0, 0.05, 0.0))
		"guard":
			mi(torso, box(0.36, 0.05, 0.22), mat(Color("0b0f1a")), Vector3(0, -0.2, 0.0))
			mi(torso, box(0.05, 0.06, 0.02), mat(Color("ffd60a"), 0.3, 0.8), Vector3(0.1, 0.12, 0.11))
		"supervisor":
			mi(torso, box(0.045, 0.34, 0.02), mat(Color("c1121f")), Vector3(0, 0.0, 0.1))
		"cleaner":
			mi(torso, box(0.34, 0.1, 0.24), mat(Color("ffd60a")), Vector3(0, 0.12, 0.0))

	# arms
	for side in [-1, 1]:
		var ap := pivot(root, Vector3(0.235 * side, 1.4, 0))
		mi(ap, capsule(0.052, 0.6), skin_m, Vector3(0, -0.3, 0))
		mi(ap, cyl(0.064, 0.066, 0.22), shirt_m, Vector3(0, -0.1, 0))
		var hand := pivot(ap, Vector3(0, -0.6, 0))
		mi(hand, sphere(0.05), skin_m)
		rig["arm_l" if side < 0 else "arm_r"] = ap
		rig["hand_l" if side < 0 else "hand_r"] = hand

	# head
	var head := pivot(root, Vector3(0, 1.5, 0))
	head.scale = Vector3(1.28, 1.28, 1.28)
	mi(head, cyl(0.045, 0.05, 0.1), skin_m, Vector3(0, 0.03, 0))
	mi(head, sphere(0.125), skin_m, Vector3(0, 0.17, 0), Vector3(1.0, 1.1, 1.0))
	var eye_sep: float = rng.randf_range(0.04, 0.056)
	var eye_r: float = rng.randf_range(0.014, 0.022)
	for side in [-1, 1]:
		mi(head, sphere(eye_r * 1.5), mat(Color("ffffff"), 0.4), Vector3(eye_sep * side, 0.2, 0.105))
		mi(head, sphere(eye_r), mat(Color("1d1d1d"), 0.3), Vector3(eye_sep * side, 0.2, 0.118))
		mi(head, box(0.04, 0.008, 0.01), mat(hair_c), Vector3(eye_sep * side, 0.245, 0.115))
	mi(head, sphere(rng.randf_range(0.016, 0.026)), mat(skin.darkened(0.08)), Vector3(0, 0.165, 0.125))
	mi(head, box(rng.randf_range(0.035, 0.06), 0.009, 0.01), mat(Color("8a3b2b") if rng.randf() < 0.7 else Color("c1121f")), Vector3(0, 0.1, 0.113))
	if uniform_cap:
		var cap_c := Color("ff8c00") if role == "stock" else Color("14213d")
		mi(head, sphere(0.132, 0.16), mat(cap_c), Vector3(0, 0.25, -0.005))
		mi(head, box(0.15, 0.015, 0.09), mat(cap_c), Vector3(0, 0.215, 0.12))
	else:
		match hair_style:
			1:
				mi(head, sphere(0.131, 0.17), mat(hair_c, 0.9), Vector3(0, 0.255, -0.01))
			2:
				mi(head, sphere(0.133, 0.18), mat(hair_c, 0.9), Vector3(0, 0.25, -0.012))
				mi(head, capsule(0.075, 0.34), mat(hair_c, 0.9), Vector3(0, 0.07, -0.085), Vector3(1.3, 1.0, 0.7))
			3:
				mi(head, sphere(0.13, 0.15), mat(hair_c, 0.9), Vector3(0, 0.26, -0.01))
				mi(head, sphere(0.05), mat(hair_c, 0.9), Vector3(0, 0.34, -0.07))
			4:
				mi(head, sphere(0.128, 0.14), mat(hair_c, 0.9), Vector3(0, 0.27, -0.005))
	if rng.randf() < 0.18:
		var gm := mat(Color("111111"), 0.3, 0.6)
		for side in [-1, 1]:
			mi(head, box(0.075, 0.05, 0.02), gm, Vector3(eye_sep * side, 0.2, 0.13))
	if not female and role != "cashier" and rng.randf() < 0.22:
		mi(head, box(0.1, 0.05, 0.05), mat(hair_c.darkened(0.1)), Vector3(0, 0.07, 0.1))

	rig["head"] = head
	root.set_meta("rig", rig)
	root.set_meta("role", role)
	return root


static func animate(rig: Dictionary, phase: float, walk: float, t: float, pose: String = "") -> void:
	var s: float = sin(phase) * walk
	(rig["leg_l"] as Node3D).rotation.x = s * 0.75
	(rig["leg_r"] as Node3D).rotation.x = -s * 0.75
	var idle: float = sin(t * 1.7) * 0.035
	var al: Node3D = rig["arm_l"]
	var ar: Node3D = rig["arm_r"]
	al.rotation.x = -s * 0.6 + idle
	ar.rotation.x = s * 0.6 - idle
	al.rotation.z = 0.05
	ar.rotation.z = -0.05
	var torso: Node3D = rig["torso"]
	var head: Node3D = rig["head"]
	torso.position.y = 1.14 + absf(sin(phase)) * 0.02 * walk
	head.position.y = 1.5 + absf(sin(phase)) * 0.02 * walk
	torso.rotation.x = 0.0
	match pose:
		"carry":
			al.rotation.x = -0.9
			ar.rotation.x = -0.9
		"pick":
			ar.rotation.x = -1.65 + sin(t * 9.0) * 0.08
			torso.rotation.x = 0.12
		"scan":
			ar.rotation.x = -1.0 + sin(t * 11.0) * 0.45
		"clean":
			ar.rotation.x = -0.75 + sin(t * 9.0) * 0.45
			torso.rotation.x = 0.18
		"pay":
			ar.rotation.x = -1.1
		"wave":
			ar.rotation.x = -2.6
			ar.rotation.z = -0.3 + sin(t * 8.0) * 0.3
