class_name Customer
extends Node3D
## Shopper AI: enters, picks products it wants (budget + preferences + price), queues, pays, leaves.

enum S { TO_DOOR, SHOP, PICK, TO_QUEUE, QUEUE, PAYING, LEAVING, DONE }

var store: Node3D
var rig: Dictionary = {}
var state: int = S.TO_DOOR
var path: Array = []
var speed: float = 1.5
var walk_phase: float = 0.0
var t: float = 0.0
var wish: Array = []
var basket: Array = []
var budget: float = 40.0
var misses: int = 0
var price_flags: int = 0
var queue_time: float = 0.0
var lane: Checkout = null
var pick_timer: float = 0.0
var gave_up: bool = false
var carry_node: MeshInstance3D = null
var _rng := RandomNumberGenerator.new()
var _moving: bool = false
var _retry: float = 0.0
var _paying_timer: float = 0.0
var exit_point: Vector3 = Vector3.ZERO
var patience: float = 45.0
var mood: float = 5.0


func setup(st: Node3D, seed_value: int, from_pos: Vector3, exit_pos: Vector3) -> void:
	store = st
	_rng.seed = seed_value
	var model: Node3D = CharFactory.build(seed_value, "customer")
	add_child(model)
	rig = model.get_meta("rig")
	position = from_pos
	exit_point = exit_pos
	speed = _rng.randf_range(1.25, 1.75)
	patience = _rng.randf_range(35.0, 60.0)
	budget = _rng.randf_range(12.0, 70.0) * (1.0 + 0.15 * float(int(Game.upgrades["store_level"]) - 1))
	t = _rng.randf() * 10.0
	_plan_shopping()
	_go(store.door_inside + Vector3(_rng.randf_range(-0.8, 0.8), 0, _rng.randf_range(-0.3, 0.3)))
	state = S.TO_DOOR


func total_items() -> int:
	var n := 0
	for b in basket:
		n += int(b["qty"])
	return maxi(n, 1)


# ---------------------------------------------------------------- planning
func _plan_shopping() -> void:
	var prefs := {}
	for c in Data.CATEGORIES:
		prefs[c] = _rng.randf_range(0.4, 1.5)
	var want_n: int = 2 + _rng.randi() % 4
	var pool: Array = Data.PRODUCTS.duplicate()
	var stocked: Array = []
	for pp in pool:
		if store.find_shelf_for(pp["id"]) >= 0:
			stocked.append(pp)
	if not stocked.is_empty() and _rng.randf() < 0.85:
		pool = stocked
	var planned_cost := 0.0
	var tries := 0
	while wish.size() + misses < want_n and tries < 12:
		tries += 1
		var total_w := 0.0
		var weights: Array = []
		for p in pool:
			var w: float = float(p["demand"]) * float(prefs[p["cat"]])
			weights.append(w)
			total_w += w
		if total_w <= 0.0 or pool.is_empty():
			break
		var r: float = _rng.randf() * total_w
		var pick: int = 0
		for i in range(pool.size()):
			r -= float(weights[i])
			if r <= 0.0:
				pick = i
				break
		var prod: Dictionary = pool[pick]
		pool.remove_at(pick)
		var slot: int = store.find_shelf_for(prod["id"])
		if slot < 0:
			misses += 1
			continue
		var price: float = Game.sell_price(prod["id"])
		var ratio: float = price / float(prod["sell"])
		var chance: float = clampf(float(prod["demand"]) * float(prefs[prod["cat"]]) * (1.2 - (ratio - 1.0) * 1.7), 0.05, 1.0)
		if _rng.randf() > chance:
			if ratio > 1.15:
				price_flags += 1
			continue
		var qty: int = 1 + (1 if _rng.randf() < 0.5 else 0) + (1 if _rng.randf() < 0.2 else 0)
		if planned_cost + price * float(qty) > budget:
			qty = 1
			if planned_cost + price > budget:
				continue
		planned_cost += price * float(qty)
		wish.append({"slot": slot, "pid": prod["id"], "qty": qty})


# ---------------------------------------------------------------- movement
func _go(target: Vector3) -> void:
	path = store.nav.find_path(position, target)


func _move(delta: float, spd: float) -> bool:
	if path.is_empty():
		_moving = false
		return true
	var tgt: Vector3 = path[0]
	var d: Vector3 = tgt - position
	d.y = 0.0
	var dist: float = d.length()
	var step: float = spd * delta
	_moving = true
	if dist <= step:
		position = Vector3(tgt.x, 0.0, tgt.z)
		path.remove_at(0)
		if path.is_empty():
			_moving = false
			return true
		return false
	var dir: Vector3 = d / dist
	position += dir * step
	rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), clampf(10.0 * delta, 0.0, 1.0))
	return false


func _face(p: Vector3, delta: float) -> void:
	var d: Vector3 = p - position
	rotation.y = lerp_angle(rotation.y, atan2(d.x, d.z), clampf(8.0 * delta, 0.0, 1.0))


func _animate(delta: float, pose: String) -> void:
	t += delta
	if _moving:
		walk_phase += delta * speed * 5.2
	CharFactory.animate(rig, walk_phase, 1.0 if _moving else 0.0, t, pose)


# ---------------------------------------------------------------- state machine
func _process(delta: float) -> void:
	var pose := ""
	if not basket.is_empty():
		pose = "carry"
	match state:
		S.TO_DOOR:
			if _move(delta, speed):
				_next_item()
		S.SHOP:
			if _move(delta, speed):
				state = S.PICK
				pick_timer = 0.9
				_face(store.shelves[wish[0]["slot"]].global_position, 1.0)
		S.PICK:
			pose = "pick"
			pick_timer -= delta
			if pick_timer <= 0.0:
				_do_pick()
		S.TO_QUEUE:
			if _move(delta, speed):
				state = S.QUEUE
		S.QUEUE:
			_queue_logic(delta)
		S.PAYING:
			pose = "pay"
			_paying_timer += delta
			queue_time += delta
			if _paying_timer > patience * 1.6 and lane != null and not lane.scanning_active:
				_give_up()
		S.LEAVING:
			if _move(delta, speed * 1.05):
				state = S.DONE
				store.customer_left(self)
				queue_free()
				return
		S.DONE:
			return
	_animate(delta, pose)


func _next_item() -> void:
	if wish.is_empty():
		_head_to_checkout()
		return
	var w: Dictionary = wish[0]
	var sh: Shelf = store.shelves[int(w["slot"])]
	if int(Game.shelf_stock[int(w["slot"])]) <= 0:
		misses += 1
		wish.pop_front()
		_next_item()
		return
	_go(sh.pick_world + Vector3(_rng.randf_range(-0.7, 0.7), 0, 0))
	state = S.SHOP


func _do_pick() -> void:
	var w: Dictionary = wish.pop_front()
	var slot: int = int(w["slot"])
	var got: int = Game.shelf_take(slot, int(w["qty"]))
	if got > 0:
		basket.append({"pid": w["pid"], "qty": got, "price": Game.sell_price(w["pid"]), "slot": slot})
		Sfx.play("pick", randf_range(0.9, 1.15), -6.0)
		_update_carry()
		if _rng.randf() < 0.07:
			store.drop_litter(position)
	else:
		misses += 1
	_next_item()


func _update_carry() -> void:
	if carry_node == null:
		carry_node = MeshInstance3D.new()
		carry_node.mesh = CharFactory.box(0.34, 0.16, 0.24)
		carry_node.material_override = CharFactory.mat(Color("d4a373"), 0.8)
		(rig["hand_r"] as Node3D).add_child(carry_node)
		carry_node.position = Vector3(0, 0.0, 0.12)
	var n: int = total_items()
	carry_node.scale = Vector3(1.0, 0.7 + 0.12 * float(mini(n, 6)), 1.0)


func _head_to_checkout() -> void:
	if basket.is_empty():
		# nothing bought: leave disappointed
		Game.record_lost_sale()
		gave_up = true
		_leave()
		return
	var best: Checkout = null
	var best_score: float = 1e9
	for c in store.checkouts:
		var co: Checkout = c
		if not co.visible:
			continue
		var score: float = float(co.queue.size()) * (co.scan_interval() + 0.4)
		if co.cashier == null:
			score += 3.0
		if score < best_score:
			best_score = score
			best = co
	if best == null or best.is_full():
		# wait and retry shortly
		_retry = 2.5
		state = S.TO_QUEUE
		path = []
		_moving = false
		lane = null
		return
	lane = best
	lane.join(self)
	_go(lane.slot_pos(lane.queue_index(self)))
	state = S.TO_QUEUE


func _queue_logic(delta: float) -> void:
	if lane == null:
		_retry -= delta
		if _retry <= 0.0:
			_head_to_checkout()
		return
	queue_time += delta
	var idx: int = lane.queue_index(self)
	if idx < 0:
		_head_to_checkout()
		return
	var slot: Vector3 = lane.slot_pos(idx)
	var d: Vector3 = slot - position
	d.y = 0.0
	if d.length() > 0.08:
		path = [slot]
		_move(delta, speed * 0.8)
	else:
		_moving = false
		_face(lane.global_position, delta)
		if idx == 0 and state == S.QUEUE:
			state = S.PAYING
			_paying_timer = 0.0
			lane.customer_arrived(self)
	if queue_time > patience:
		_give_up()


func _give_up() -> void:
	gave_up = true
	Game.record_lost_sale()
	for b in basket:
		Game.shelf_give_back(int(b["slot"]), int(b["qty"]))
	basket.clear()
	if lane != null:
		lane.leave(self)
		lane = null
	if carry_node:
		carry_node.queue_free()
		carry_node = null
	_leave()


func finish_payment() -> void:
	var stolen := false
	var guards: int = Game.employee_count("guard")
	var chance: float = 0.035 if guards == 0 else 0.004
	if _rng.randf() < chance:
		stolen = true
	var amount: float = Game.record_sale(basket, stolen)
	if stolen:
		store.spawn_text(position + Vector3(0, 2.0, 0), "SHOPLIFTED!", Color("ff6b6b"))
	else:
		store.spawn_text(position + Vector3(0, 2.0, 0), "+$%.2f" % amount, Color("7CFFB2"))
		Sfx.play("cash", randf_range(0.95, 1.05), -3.0)
	if lane != null:
		lane.leave(self)
		lane = null
	if carry_node:
		carry_node.material_override = CharFactory.mat(Color("b08968"), 0.8)  # paper bag
	_leave()


func _leave() -> void:
	mood = 5.0
	mood -= clampf(queue_time / 30.0, 0.0, 2.0)
	mood -= float(misses) * 0.6
	mood -= float(price_flags) * 0.4
	mood -= (1.0 - Game.cleanliness) * 1.0
	mood += float(int(Game.upgrades["store_level"]) - 1) * 0.1
	if gave_up:
		mood = minf(mood, 1.8)
	Game.submit_rating(clampf(mood, 1.0, 5.0))
	state = S.LEAVING
	_go(exit_point)
