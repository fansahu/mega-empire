class_name CamRig
extends Node3D
## Touch camera: 1 finger pan, 2 fingers pinch-zoom + twist-rotate + tilt, tap to interact, cinematic presets.

signal tapped(pos: Vector2)

const PRESETS := {
	"overview": {"target": Vector3(0, 0, 0), "dist": 26.0, "yaw": 28.0, "pitch": 50.0},
	"checkout": {"target": Vector3(-3.0, 0, 1.5), "dist": 13.0, "yaw": 20.0, "pitch": 58.0},
	"shelves": {"target": Vector3(0, 0, -4.0), "dist": 14.0, "yaw": 15.0, "pitch": 55.0},
	"warehouse": {"target": Vector3(13, 0, -6.5), "dist": 14.0, "yaw": -35.0, "pitch": 45.0},
	"street": {"target": Vector3(0, 0, 9.0), "dist": 17.0, "yaw": 20.0, "pitch": 24.0},
	"topdown": {"target": Vector3(0, 0, -1.0), "dist": 30.0, "yaw": 0.0, "pitch": 80.0},
}
const ORDER := ["overview", "checkout", "shelves", "warehouse", "street", "topdown"]

var cam: Camera3D
var yaw: float = 0.0
var pitch: float = deg_to_rad(52.0)
var dist: float = 25.0
var target: Vector3 = Vector3.ZERO
var yaw_t: float = 0.0
var pitch_t: float = deg_to_rad(52.0)
var dist_t: float = 25.0
var target_t: Vector3 = Vector3.ZERO
var orbit: bool = false
var preset_i: int = 0
var enabled: bool = true
var _touches: Dictionary = {}
var _starts: Dictionary = {}
var _multi: bool = false
var _pinch_d: float = 0.0
var _pinch_a: float = 0.0
var _tween: Tween
var _vel: Vector3 = Vector3.ZERO
var _pinch_mid: Vector2 = Vector2.ZERO


func _ready() -> void:
	cam = Camera3D.new()
	cam.fov = 55.0
	cam.near = 0.2
	cam.far = 200.0
	add_child(cam)
	_apply(true)


func _apply(snap: bool, delta: float = 0.016) -> void:
	var k: float = 1.0 if snap else clampf(delta * 9.0, 0.0, 1.0)
	yaw = lerp_angle(yaw, yaw_t, k)
	pitch = lerpf(pitch, pitch_t, k)
	dist = lerpf(dist, dist_t, k)
	target = target.lerp(target_t, k)
	var off := Vector3(sin(yaw) * cos(pitch), sin(pitch), cos(yaw) * cos(pitch)) * dist
	cam.global_position = target + off
	cam.look_at(target, Vector3.UP)


func _process(delta: float) -> void:
	if orbit:
		yaw_t += delta * 0.08
	if _touches.is_empty() and _vel.length() > 0.05:
		target_t += _vel * delta
		_vel *= pow(0.04, delta)
		clamp_targets()
	_apply(false, delta)


func clamp_targets() -> void:
	target_t.x = clampf(target_t.x, -46.0, 46.0)
	target_t.z = clampf(target_t.z, -30.0, 36.0)
	dist_t = clampf(dist_t, 5.0, 62.0)
	pitch_t = clampf(pitch_t, deg_to_rad(20.0), deg_to_rad(82.0))


func focus(preset: String, duration: float = 0.9) -> void:
	if not PRESETS.has(preset):
		return
	var p: Dictionary = PRESETS[preset]
	if _tween:
		_tween.kill()
	_tween = create_tween()
	_tween.set_parallel(true)
	_tween.set_trans(Tween.TRANS_CUBIC)
	_tween.set_ease(Tween.EASE_IN_OUT)
	_tween.tween_property(self, "target_t", p["target"], duration)
	_tween.tween_property(self, "dist_t", p["dist"], duration)
	_tween.tween_property(self, "pitch_t", deg_to_rad(float(p["pitch"])), duration)
	var cur: float = fposmod(yaw_t + PI, TAU) - PI
	yaw_t = cur
	_tween.tween_property(self, "yaw_t", deg_to_rad(float(p["yaw"])), duration)


func next_preset() -> String:
	preset_i = (preset_i + 1) % ORDER.size()
	focus(ORDER[preset_i])
	return ORDER[preset_i]


func _ground_hit(p: Vector2) -> Variant:
	var o: Vector3 = cam.project_ray_origin(p)
	var d: Vector3 = cam.project_ray_normal(p)
	if absf(d.y) < 0.02:
		return null
	var t: float = -o.y / d.y
	if t < 0.0 or t > 200.0:
		return null
	return o + d * t


func handle(event: InputEvent) -> void:
	if not enabled:
		return
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			dist_t *= 0.9
			clamp_targets()
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			dist_t *= 1.1
			clamp_targets()
	elif event is InputEventScreenTouch:
		var st := event as InputEventScreenTouch
		if st.pressed:
			_touches[st.index] = st.position
			_starts[st.index] = {"pos": st.position, "t": Time.get_ticks_msec()}
			_vel = Vector3.ZERO
			if _touches.size() >= 2:
				_multi = true
				_begin_pinch()
		else:
			var info: Variant = _starts.get(st.index)
			if info != null and not _multi:
				var moved: float = (st.position - info["pos"]).length()
				var dt: int = Time.get_ticks_msec() - int(info["t"])
				if moved < 16.0 and dt < 400:
					tapped.emit(st.position)
			_touches.erase(st.index)
			_starts.erase(st.index)
			if _touches.is_empty():
				_multi = false
			elif _touches.size() == 1 and _multi:
				_pinch_d = 0.0  # one finger left of a 2-finger gesture: ignore it until lifted (no jump)
	elif event is InputEventScreenDrag:
		var sd := event as InputEventScreenDrag
		if not _touches.has(sd.index):
			return
		var prev: Vector2 = _touches[sd.index]
		_touches[sd.index] = sd.position
		if _multi:
			if _touches.size() >= 2:
				_two_finger(sd.index)
		else:
			var h0: Variant = _ground_hit(prev)
			var h1: Variant = _ground_hit(sd.position)
			if h0 != null and h1 != null:
				var delta: Vector3 = (h0 as Vector3) - (h1 as Vector3)
				delta.y = 0.0
				if delta.length() > 6.0:
					delta = delta.normalized() * 6.0
				target_t += delta
				_vel = _vel.lerp(delta / maxf(get_process_delta_time(), 0.008), 0.35)
				clamp_targets()


func _two_finger(idx: int) -> void:
	var keys: Array = _touches.keys()
	keys.sort()
	var a: Vector2 = _touches[keys[0]]
	var b: Vector2 = _touches[keys[1]]
	var d: float = a.distance_to(b)
	var ang: float = (b - a).angle()
	var mid: Vector2 = (a + b) * 0.5
	if _pinch_d > 20.0 and d > 20.0:
		var ratio: float = clampf(_pinch_d / d, 0.9, 1.1)
		dist_t *= ratio
		var da: float = angle_difference(_pinch_a, ang)
		if absf(da) < 0.35:
			yaw_t -= da
		var dy: float = mid.y - _pinch_mid.y
		if absf(dy) < 60.0:
			pitch_t += dy * 0.0035
		clamp_targets()
	_pinch_d = d
	_pinch_a = ang
	_pinch_mid = mid


func _begin_pinch() -> void:
	var keys: Array = _touches.keys()
	keys.sort()
	var a: Vector2 = _touches[keys[0]]
	var b: Vector2 = _touches[keys[1]]
	_pinch_d = a.distance_to(b)
	_pinch_a = (b - a).angle()
	_pinch_mid = (a + b) * 0.5
