extends Node
## Autoload "Sfx": audio buses (Music / SFX / Ambient) + simple player pool.
## Sounds are synthesized WAV files in res://audio (see tools/make_audio.py).

const SOUNDS := {
	"click": "res://audio/click.wav",
	"beep": "res://audio/beep.wav",
	"cash": "res://audio/cash.wav",
	"upgrade": "res://audio/upgrade.wav",
	"door": "res://audio/door.wav",
	"pick": "res://audio/pick.wav",
	"cart": "res://audio/cart.wav",
	"step": "res://audio/step.wav",
}

var _streams: Dictionary = {}
var _pool: Array = []
var _music: AudioStreamPlayer
var _ambient: AudioStreamPlayer
var _bus_ready := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_setup_buses()
	for k in SOUNDS:
		if ResourceLoader.exists(SOUNDS[k]):
			_streams[k] = load(SOUNDS[k])
	for i in range(8):
		var p := AudioStreamPlayer.new()
		p.bus = "SFX"
		add_child(p)
		_pool.append(p)
	_music = AudioStreamPlayer.new()
	_music.bus = "Music"
	add_child(_music)
	_ambient = AudioStreamPlayer.new()
	_ambient.bus = "Ambient"
	add_child(_ambient)
	if ResourceLoader.exists("res://audio/music.wav"):
		var m: AudioStreamWAV = load("res://audio/music.wav")
		m.loop_mode = AudioStreamWAV.LOOP_FORWARD
		m.loop_end = m.data.size() / 2
		_music.stream = m
	if ResourceLoader.exists("res://audio/ambient.wav"):
		var a: AudioStreamWAV = load("res://audio/ambient.wav")
		a.loop_mode = AudioStreamWAV.LOOP_FORWARD
		a.loop_end = a.data.size() / 2
		_ambient.stream = a
	apply_volumes()


func _setup_buses() -> void:
	for n in ["Music", "SFX", "Ambient"]:
		if AudioServer.get_bus_index(n) == -1:
			AudioServer.add_bus()
			var idx: int = AudioServer.bus_count - 1
			AudioServer.set_bus_name(idx, n)
			AudioServer.set_bus_send(idx, "Master")
	_bus_ready = true


func apply_volumes() -> void:
	if not _bus_ready:
		return
	_set_bus("Music", float(Game.settings.get("music", 0.5)))
	_set_bus("SFX", float(Game.settings.get("sfx", 0.8)))
	_set_bus("Ambient", float(Game.settings.get("ambient", 0.4)))


func _set_bus(name: String, v: float) -> void:
	var idx: int = AudioServer.get_bus_index(name)
	if idx == -1:
		return
	AudioServer.set_bus_mute(idx, v <= 0.001)
	AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(v, 0.0001)))


func start_loops() -> void:
	if _music.stream and not _music.playing:
		_music.play()
	if _ambient.stream and not _ambient.playing:
		_ambient.play()


func play(name: String, pitch: float = 1.0, vol_db: float = 0.0) -> void:
	if not _streams.has(name):
		return
	for p in _pool:
		var pl: AudioStreamPlayer = p
		if not pl.playing:
			pl.stream = _streams[name]
			pl.pitch_scale = pitch
			pl.volume_db = vol_db
			pl.play()
			return
