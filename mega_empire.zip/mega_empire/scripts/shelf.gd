class_name Shelf
extends Node3D
## One shelf face: frame, boards, goods (MultiMesh, count follows real stock), name + price labels.

const SLOTS := 42  # 7 columns x 2 rows x 3 levels
const BOARD_Y := [0.32, 0.98, 1.64]

var idx: int = 0
var width: float = 2.7
var depth: float = 0.8
var pick_world: Vector3 = Vector3.ZERO
var tall: bool = false
var goods: MultiMeshInstance3D
var header: MeshInstance3D
var name_label: Label3D
var price_label: Label3D
var sold_label: Label3D
var _shown_pid: String = "-"
var _last_visible: int = -1
var _body: Node3D


func build(i: int, is_tall: bool) -> void:
	idx = i
	tall = is_tall
	var h: float = 2.3 if tall else 2.0
	_body = Node3D.new()
	add_child(_body)
	var metal := CharFactory.mat(Color("cfd4da"), 0.35, 0.6)
	var board := CharFactory.mat(Color("f1f3f5"), 0.5)
	for sx in [-1, 1]:
		CharFactory.mi(_body, CharFactory.box(0.06, h, depth), metal, Vector3(sx * (width / 2.0 - 0.03), h / 2.0, 0))
	CharFactory.mi(_body, CharFactory.box(width, h, 0.04), CharFactory.mat(Color("e9ecef"), 0.7), Vector3(0, h / 2.0, -depth / 2.0 + 0.02))
	CharFactory.mi(_body, CharFactory.box(width, 0.1, depth), metal, Vector3(0, 0.05, 0))
	for y in BOARD_Y:
		CharFactory.mi(_body, CharFactory.box(width - 0.1, 0.04, depth - 0.04), board, Vector3(0, y, 0.0))
	header = CharFactory.mi(_body, CharFactory.box(width, 0.34, 0.12), CharFactory.mat(Color("4ea8de"), 0.5), Vector3(0, h - 0.17, depth / 2.0 - 0.02))
	name_label = Label3D.new()
	name_label.font_size = 64
	name_label.pixel_size = 0.0058
	name_label.modulate = Color.WHITE
	name_label.outline_size = 10
	name_label.outline_modulate = Color(0, 0, 0, 0.8)
	name_label.position = Vector3(0, h - 0.17, depth / 2.0 + 0.045)
	_body.add_child(name_label)
	price_label = Label3D.new()
	price_label.font_size = 48
	price_label.pixel_size = 0.0055
	price_label.modulate = Color("ffe066")
	price_label.outline_size = 10
	price_label.outline_modulate = Color(0, 0, 0, 0.9)
	price_label.position = Vector3(0, 0.18, depth / 2.0 + 0.02)
	_body.add_child(price_label)
	sold_label = Label3D.new()
	sold_label.text = "SOLD OUT"
	sold_label.font_size = 56
	sold_label.pixel_size = 0.006
	sold_label.modulate = Color("ff3b30")
	sold_label.outline_size = 12
	sold_label.outline_modulate = Color(0, 0, 0, 0.9)
	sold_label.position = Vector3(0, 1.1, depth / 2.0 - 0.1)
	sold_label.visible = false
	_body.add_child(sold_label)
	goods = MultiMeshInstance3D.new()
	_body.add_child(goods)


func _item_mesh(shape: String) -> Mesh:
	match shape:
		"bottle":
			return CharFactory.cyl(0.04, 0.05, 0.32, 10)
		"can":
			return CharFactory.cyl(0.05, 0.05, 0.22, 10)
		"box":
			return CharFactory.box(0.22, 0.3, 0.12)
		"bag":
			return CharFactory.box(0.24, 0.34, 0.08)
		"round":
			return CharFactory.sphere(0.08, 0.16)
		"loaf":
			return CharFactory.box(0.3, 0.14, 0.16)
	return CharFactory.box(0.2, 0.2, 0.2)


func _item_height(shape: String) -> float:
	match shape:
		"bottle":
			return 0.32
		"can":
			return 0.22
		"box":
			return 0.3
		"bag":
			return 0.34
		"round":
			return 0.16
		"loaf":
			return 0.14
	return 0.2


func _rebuild_goods(pid: String) -> void:
	_shown_pid = pid
	_last_visible = -1
	if pid == "":
		goods.multimesh = null
		name_label.text = "- EMPTY -"
		price_label.text = ""
		return
	var p: Dictionary = Data.product_by_id(pid)
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = _item_mesh(p["shape"])
	mm.instance_count = SLOTS
	var ih: float = _item_height(p["shape"])
	for i in range(SLOTS):
		var level: int = i / 14
		var j: int = i % 14
		var row: int = j / 7
		var col: int = j % 7
		var x: float = -width / 2.0 + 0.26 + float(col) * (width - 0.52) / 6.0
		var z: float = depth / 2.0 - 0.2 - float(row) * 0.3
		var y: float = float(BOARD_Y[level]) + 0.02 + ih / 2.0
		mm.set_instance_transform(i, Transform3D(Basis(), Vector3(x, y, z)))
	var m := CharFactory.mat(p["color"], 0.55)
	goods.multimesh = mm
	goods.material_override = m
	name_label.text = p["name"]
	var cc: Color = Data.CAT_COLORS.get(p["cat"], Color("4ea8de"))
	(header.material_override as StandardMaterial3D).albedo_color = cc
	header.material_override = CharFactory.mat(cc.darkened(0.15), 0.5)


func refresh() -> void:
	var unlocked: bool = Game.shelf_unlocked(idx)
	visible = unlocked
	if not unlocked:
		return
	var pid: String = Game.shelf_product[idx]
	if pid != _shown_pid:
		_rebuild_goods(pid)
	if pid == "":
		sold_label.visible = false
		return
	var stock: int = int(Game.shelf_stock[idx])
	var cap: int = maxi(Game.shelf_capacity(), 1)
	var vis: int = 0
	if stock > 0:
		vis = clampi(int(ceil(float(stock) / float(cap) * float(SLOTS))), 1, SLOTS)
	if goods.multimesh and vis != _last_visible:
		goods.multimesh.visible_instance_count = vis
		_last_visible = vis
	sold_label.visible = stock <= 0
	price_label.text = "$%.2f" % Game.sell_price(pid)


func tap_pos() -> Vector3:
	return global_position + Vector3(0, 1.2, 0)
