class_name Checkout
extends Node3D
## A checkout lane: counter model, customer queue, scanning (cashier auto-scans, player can tap to scan).

const SLOT_STEP := 0.8
const MAX_QUEUE := 4

var lane: int = 0
var queue: Array = []
var items_left: int = 0
var scanning_active: bool = false
var cashier: Node3D = null
var scan_timer: float = 0.0
var label: Label3D
var screen_mat: StandardMaterial3D
var _wait_label: Label3D


func build(i: int) -> void:
	lane = i
	var white := CharFactory.mat(Color("eef1f4"), 0.35, 0.3)
	var dark := CharFactory.mat(Color("23272e"), 0.5, 0.2)
	CharFactory.mi(self, CharFactory.box(2.6, 0.95, 1.2), white, Vector3(0, 0.475, 0))
	CharFactory.mi(self, CharFactory.box(2.7, 0.06, 1.3), CharFactory.mat(Color("2a9d8f"), 0.3, 0.1), Vector3(0, 0.98, 0))
	CharFactory.mi(self, CharFactory.box(1.35, 0.03, 0.62), dark, Vector3(-0.45, 1.03, 0.1))
	for k in range(7):
		CharFactory.mi(self, CharFactory.cyl(0.035, 0.035, 0.6, 8), CharFactory.mat(Color("8d99ae"), 0.3, 0.8), Vector3(-1.05 + k * 0.2, 1.045, 0.1), Vector3(1, 1, 1)).rotation.x = PI / 2.0
	CharFactory.mi(self, CharFactory.box(0.5, 0.35, 0.4), dark, Vector3(0.85, 1.2, -0.1))
	screen_mat = CharFactory.emissive(Color("6bff9e"), 1.4).duplicate()
	var scr := CharFactory.mi(self, CharFactory.box(0.4, 0.22, 0.02), screen_mat, Vector3(0.85, 1.28, 0.1))
	scr.rotation.x = -0.35
	CharFactory.mi(self, CharFactory.box(0.05, 1.2, 0.05), CharFactory.mat(Color("495057"), 0.4, 0.6), Vector3(1.15, 1.6, -0.5))
	CharFactory.mi(self, CharFactory.box(0.55, 0.3, 0.06), CharFactory.mat(Color("e63946"), 0.4), Vector3(1.15, 2.3, -0.5))
	label = Label3D.new()
	label.text = "LANE %d" % (i + 1)
	label.font_size = 48
	label.pixel_size = 0.0055
	label.outline_size = 8
	label.position = Vector3(1.15, 2.3, -0.46)
	add_child(label)
	_wait_label = Label3D.new()
	_wait_label.font_size = 46
	_wait_label.pixel_size = 0.006
	_wait_label.modulate = Color("ffe066")
	_wait_label.outline_size = 10
	_wait_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_wait_label.position = Vector3(0, 2.0, -0.2)
	_wait_label.visible = false
	add_child(_wait_label)


func slot_pos(i: int) -> Vector3:
	return Vector3(global_position.x, 0.0, global_position.z - 1.2 - 0.0 - float(i) * SLOT_STEP)


func cashier_pos() -> Vector3:
	return Vector3(global_position.x, 0.0, global_position.z + 1.25)


func is_full() -> bool:
	return queue.size() >= MAX_QUEUE


func join(c: Node3D) -> void:
	queue.append(c)


func leave(c: Node3D) -> void:
	var i: int = queue.find(c)
	if i == 0:
		items_left = 0
		scanning_active = false
		scan_timer = 0.0
	if i >= 0:
		queue.remove_at(i)


func queue_index(c: Node3D) -> int:
	return queue.find(c)


func customer_arrived(c: Node3D) -> void:
	if queue.size() > 0 and queue[0] == c:
		items_left = c.total_items()
		scanning_active = true
		scan_timer = 0.0


func scan_interval() -> float:
	var lvl: int = 1
	if cashier != null and cashier.has_method("skill_level"):
		lvl = cashier.skill_level()
	return 1.0 / (1.0 + 0.3 * float(lvl - 1)) / Game.supervisor_bonus()


func _scan_one() -> void:
	if items_left <= 0:
		return
	items_left -= 1
	Sfx.play("beep", randf_range(0.95, 1.1), -4.0)
	if items_left <= 0 and queue.size() > 0:
		scanning_active = false
		queue[0].finish_payment()


func manual_scan() -> bool:
	if scanning_active and items_left > 0:
		_scan_one()
		return true
	return false


func _process(delta: float) -> void:
	if not visible:
		return
	if scanning_active and items_left > 0:
		_wait_label.visible = true
		if cashier != null:
			_wait_label.text = "%d" % items_left
			scan_timer += delta
			if scan_timer >= scan_interval():
				scan_timer = 0.0
				_scan_one()
				if cashier.has_method("note_task"):
					cashier.note_task()
		else:
			_wait_label.text = "TAP TO SCAN (%d)" % items_left
	else:
		_wait_label.visible = false
	screen_mat.emission_energy_multiplier = 1.4 if scanning_active else 0.5
