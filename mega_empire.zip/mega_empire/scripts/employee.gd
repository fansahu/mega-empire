class_name Employee
extends Node3D
## Working staff. Every type performs real tasks that change the economy.

enum S { IDLE, TO_WH, LOADING, TO_SHELF, UNLOADING, TO_LITTER, CLEANING, PATROL, WAIT }

var data: Dictionary = {}
var type: String = "cashier"
var store: Node3D
var rig: Dictionary = {}
var model_node: Node3D = null
var state: int = S.IDLE
var path: Array = []
var walk_phase: float = 0.0
var t: float = 0.0
var timer: float = 0.0
var _moving: bool = false
var target_slot: int = -1
var carried_pid: String = ""
var carried_n: int = 0
var crate: MeshInstance3D
var target_litter: Node3D = null
var patrol_i: int = 0
var lane_idx: int = -1
var _idle_timer: float = 0.0


func setup(st: Node3D, emp: Dictionary) -> void:
	store = st
	data = emp
	type = emp["type"]
	_make_model()
	t = randf() * 10.0
	if type == "cashier":
		_assign_lane()
	else:
		position = store.staff_spawn
		state = S.IDLE


func skill_level() -> int:
	return int(data["level"])


func note_task() -> void:
	data["tasks"] = int(data["tasks"]) + 1


func _assign_lane() -> void:
	var idx := 0
	for e in Game.employees:
		if e["type"] == "cashier":
			if int(e["id"]) == int(data["id"]):
				break
			idx += 1
	lane_idx = idx
	if lane_idx < store.checkouts.size():
		var co: Checkout = store.checkouts[lane_idx]
		co.cashier = self
		position = co.cashier_pos()
		rotation.y = PI


func _make_model() -> void:
	if model_node != null and is_instance_valid(model_node):
		remove_child(model_node)
		model_node.queue_free()
	model_node = CharFactory.build(int(data["seed"]), type, data.get("look", {}))
	add_child(model_node)
	rig = model_node.get_meta("rig")


func refresh_look() -> void:
	_make_model()


func release() -> void:
	if type == "cashier" and lane_idx >= 0 and lane_idx < store.checkouts.size():
		var co: Checkout = store.checkouts[lane_idx]
		if co.cashier == self:
			co.cashier = null
	if target_slot >= 0:
		store.reserved.erase(target_slot)
	if carried_n > 0:
		Game.warehouse[carried_pid] = int(Game.warehouse.get(carried_pid, 0)) + carried_n
		carried_n = 0
	if target_litter != null:
		store.litter_taken.erase(target_litter)


func _speed() -> float:
	return 1.5 * Game.supervisor_bonus() * (1.0 + 0.08 * float(skill_level() - 1))


func _go(target: Vector3) -> void:
	path = store.nav.find_path(position, target)


func _move(delta: float) -> bool:
	if path.is_empty():
		_moving = false
		return true
	var tgt: Vector3 = path[0]
	var d: Vector3 = tgt - position
	d.y = 0.0
	var dist: float = d.length()
	var step: float = _speed() * delta
	_moving = true
	if dist <= step:
		position = Vector3(tgt.x, 0.0, tgt.z)
		path.remove_at(0)
		if path.is_empty():
			_moving = false
			return true
		return false
	var dir: Vector3 = d / dist
	position += dir * step
	rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), clampf(10.0 * delta, 0.0, 1.0))
	return false


func _show_crate(on: bool) -> void:
	if on and crate == null:
		crate = MeshInstance3D.new()
		crate.mesh = CharFactory.box(0.5, 0.3, 0.4)
		crate.material_override = CharFactory.mat(Color("c9a227"), 0.8)
		add_child(crate)
		crate.position = Vector3(0, 1.05, 0.35)
	if crate != null:
		crate.visible = on


func _process(delta: float) -> void:
	t += delta
	var pose := ""
	match type:
		"cashier":
			var co: Checkout = null
			if lane_idx >= 0 and lane_idx < store.checkouts.size():
				co = store.checkouts[lane_idx]
			visible = co != null and co.visible
			if co != null:
				if co.scanning_active:
					pose = "scan"
				var p: Vector3 = co.cashier_pos()
				position = p
				rotation.y = PI
		"stock":
			pose = _stock_logic(delta)
		"cleaner":
			pose = _cleaner_logic(delta)
		"guard", "supervisor":
			pose = _patrol_logic(delta)
	if _moving:
		walk_phase += delta * _speed() * 5.2
	CharFactory.animate(rig, walk_phase, 1.0 if _moving else 0.0, t, pose)


# ---------------------------------------------------------------- stock manager
func _pick_target() -> int:
	var best: int = -1
	var best_ratio: float = 0.6
	var cap: float = float(maxi(Game.shelf_capacity(), 1))
	for i in range(Game.MAX_SHELVES):
		if not Game.shelf_unlocked(i) or store.reserved.has(i):
			continue
		var pid: String = Game.shelf_product[i]
		if pid == "" or int(Game.warehouse.get(pid, 0)) <= 0:
			continue
		var ratio: float = float(Game.shelf_stock[i]) / cap
		if ratio < best_ratio:
			best_ratio = ratio
			best = i
	return best


func _stock_logic(delta: float) -> String:
	match state:
		S.IDLE:
			_idle_timer -= delta
			if _idle_timer <= 0.0:
				_idle_timer = 1.0
				var slot: int = _pick_target()
				if slot >= 0:
					target_slot = slot
					store.reserved[slot] = true
					_go(store.warehouse_spot)
					state = S.TO_WH
		S.TO_WH:
			if _move(delta):
				state = S.LOADING
				timer = 1.1
		S.LOADING:
			timer -= delta
			if timer <= 0.0:
				var pid: String = Game.shelf_product[target_slot]
				var want: int = int((8.0 + 4.0 * float(skill_level())) * Game.supervisor_bonus())
				var room: int = Game.shelf_capacity() - int(Game.shelf_stock[target_slot])
				carried_pid = pid
				carried_n = Game.warehouse_take(pid, mini(want, room))
				_show_crate(carried_n > 0)
				_go((store.shelves[target_slot] as Shelf).pick_world)
				state = S.TO_SHELF
		S.TO_SHELF:
			if _move(delta):
				state = S.UNLOADING
				timer = 1.3
		S.UNLOADING:
			timer -= delta
			if timer <= 0.0:
				if carried_n > 0:
					if carried_pid == Game.shelf_product[target_slot]:
						var left: int = Game.shelf_add(target_slot, carried_n)
						if left > 0:
							Game.warehouse[carried_pid] = int(Game.warehouse.get(carried_pid, 0)) + left
					else:
						Game.warehouse[carried_pid] = int(Game.warehouse.get(carried_pid, 0)) + carried_n
					note_task()
				carried_n = 0
				_show_crate(false)
				store.reserved.erase(target_slot)
				target_slot = -1
				state = S.IDLE
				_idle_timer = 0.2
	if state == S.LOADING or state == S.UNLOADING:
		return "pick"
	if carried_n > 0:
		return "carry"
	return ""


# ---------------------------------------------------------------- cleaner
func _cleaner_logic(delta: float) -> String:
	match state:
		S.IDLE:
			_idle_timer -= delta
			if _idle_timer <= 0.0:
				_idle_timer = 1.0
				var l: Node3D = store.nearest_litter(position)
				if l != null:
					target_litter = l
					store.litter_taken[l] = true
					_go(l.position)
					state = S.TO_LITTER
		S.TO_LITTER:
			if _move(delta):
				state = S.CLEANING
				timer = 1.3
		S.CLEANING:
			timer -= delta
			if timer <= 0.0:
				if is_instance_valid(target_litter):
					store.remove_litter(target_litter)
					note_task()
				target_litter = null
				state = S.IDLE
				_idle_timer = 0.2
	return "clean" if state == S.CLEANING else ""


# ---------------------------------------------------------------- guard / supervisor
func _patrol_logic(delta: float) -> String:
	match state:
		S.IDLE:
			var pts: Array = store.patrol_points
			patrol_i = (patrol_i + 1 + (int(data["id"]) % 2)) % pts.size()
			_go(pts[patrol_i])
			state = S.PATROL
		S.PATROL:
			if _move(delta):
				state = S.WAIT
				timer = randf_range(2.0, 5.0)
		S.WAIT:
			timer -= delta
			if timer <= 0.0:
				state = S.IDLE
	return ""
