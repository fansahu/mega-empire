extends Node3D
## Entry point: loading screen -> main menu (cinematic orbit) -> game. Wires store, camera and HUD.

var store: Store
var cam: CamRig
var hud: Hud
var menu_layer: CanvasLayer
var loading_layer: CanvasLayer
var started: bool = false
var _autosave: float = 0.0
var _quality_btn: Button
var _continue_btn: Button


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	_show_loading()
	await get_tree().process_frame
	await get_tree().process_frame
	_build_world()
	loading_layer.queue_free()
	_build_menu()


func _show_loading() -> void:
	loading_layer = CanvasLayer.new()
	loading_layer.layer = 100
	add_child(loading_layer)
	var bg := ColorRect.new()
	bg.color = Color("0a0e1a")
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	loading_layer.add_child(bg)
	var tex: Texture2D = Art.tex("menu_bg")
	if tex:
		var tr := TextureRect.new()
		tr.texture = tex
		tr.set_anchors_preset(Control.PRESET_FULL_RECT)
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		loading_layer.add_child(tr)
	var logo: Texture2D = Art.tex("logo")
	if logo:
		var lr := TextureRect.new()
		lr.texture = logo
		lr.set_anchors_preset(Control.PRESET_CENTER)
		lr.custom_minimum_size = Vector2(640, 320)
		lr.position = Vector2(-320, -250)
		lr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		lr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		loading_layer.add_child(lr)
	var l := Label.new()
	l.text = "Loading..."
	l.add_theme_font_size_override("font_size", 30)
	l.set_anchors_preset(Control.PRESET_CENTER)
	l.position = Vector2(-70, 120)
	loading_layer.add_child(l)


func _build_world() -> void:
	store = Store.new()
	add_child(store)
	store.build()
	cam = CamRig.new()
	add_child(cam)
	cam.orbit = true
	cam.target_t = Vector3(0, 0, 0)
	cam.dist_t = 30.0
	cam.pitch_t = deg_to_rad(38.0)
	cam.tapped.connect(_on_tap)
	hud = Hud.new()
	add_child(hud)
	hud.camera_cycle.connect(func() -> void: hud.show_toast("Camera: " + cam.next_preset()))
	hud.pause_toggled.connect(_on_pause)
	hud.speed_changed.connect(_apply_speed)
	hud.quit_to_menu.connect(_to_menu)
	hud.buy_manual_scan.connect(func(lane: int) -> void:
		(store.checkouts[lane] as Checkout).manual_scan())
	Game.quality_changed.connect(store.apply_quality)
	get_viewport().size_changed.connect(store.apply_quality)


func _build_menu() -> void:
	if menu_layer:
		menu_layer.queue_free()
	menu_layer = CanvasLayer.new()
	menu_layer.layer = 50
	add_child(menu_layer)
	var shade := ColorRect.new()
	shade.color = Color(0.02, 0.04, 0.09, 0.55)
	shade.set_anchors_preset(Control.PRESET_FULL_RECT)
	menu_layer.add_child(shade)
	var box := VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_CENTER_LEFT)
	box.position = Vector2(60, -220)
	box.custom_minimum_size = Vector2(520, 0)
	box.add_theme_constant_override("separation", 14)
	menu_layer.add_child(box)
	var logo: Texture2D = Art.tex("logo")
	if logo:
		var lr := TextureRect.new()
		lr.texture = logo
		lr.custom_minimum_size = Vector2(520, 260)
		lr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		lr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		box.add_child(lr)
	if Game.has_save():
		_continue_btn = _menu_btn("CONTINUE", func() -> void: _start(false), Color("2ec4b6"))
		box.add_child(_continue_btn)
	box.add_child(_menu_btn("NEW GAME", func() -> void: _start(true), Color("3a86ff")))
	_quality_btn = _menu_btn("", _cycle_quality, Color("5a54d6"))
	_update_quality_text()
	box.add_child(_quality_btn)
	var v := Label.new()
	v.text = "v0.1  Phases 1-6 prototype"
	v.add_theme_color_override("font_color", Color(1, 1, 1, 0.5))
	box.add_child(v)
	cam.orbit = true


func _menu_btn(text: String, cb: Callable, color: Color) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 76)
	b.add_theme_font_size_override("font_size", 30)
	for st in ["normal", "hover", "pressed"]:
		var s := StyleBoxFlat.new()
		s.bg_color = color if st == "normal" else (color.lightened(0.12) if st == "hover" else color.darkened(0.2))
		s.set_corner_radius_all(18)
		b.add_theme_stylebox_override(st, s)
	b.pressed.connect(func() -> void:
		Sfx.play("click")
		cb.call())
	return b


func _cycle_quality() -> void:
	var q: int = (int(Game.settings["quality"]) + 1) % 4
	Game.set_setting("quality", q)
	_update_quality_text()


func _update_quality_text() -> void:
	if _quality_btn:
		_quality_btn.text = "GRAPHICS: " + ["LOW", "MEDIUM", "HIGH", "ULTRA"][int(Game.settings["quality"])]


func _start(new_game: bool) -> void:
	if new_game:
		Game.new_game()
	else:
		if not Game.load_game():
			Game.new_game()
	store.reset_world()
	Game.running = true
	started = true
	store.refresh_all()
	store.apply_upgrades()
	store.apply_quality()
	menu_layer.queue_free()
	menu_layer = null
	hud.visible = true
	cam.orbit = false
	cam.focus("overview", 1.8)
	Sfx.start_loops()
	_apply_speed()
	if Game.pending_offline > 0.0:
		var got: float = Game.collect_offline()
		hud.show_toast("While you were away you earned $%d (50%% of your average profit)" % int(got))
	elif new_game:
		_tips()


func _tips() -> void:
	var tips: Array = [
		"Welcome! Tap a SHELF to restock it from the warehouse.",
		"Open the SHOP (cart icon) to order stock and set prices.",
		"Tap the CHECKOUT counter to scan items - or hire a cashier!",
		"Catch the day cycle: expenses are paid every night.",
	]
	var tw := create_tween()
	for i in range(tips.size()):
		tw.tween_interval(3.0 if i > 0 else 1.5)
		var msg: String = tips[i]
		tw.tween_callback(func() -> void: hud.show_toast(msg))


func _apply_speed() -> void:
	Engine.time_scale = float(Game.settings.get("speed", 1))


func _on_pause(p: bool) -> void:
	get_tree().paused = p
	cam.enabled = not p
	if not p:
		_apply_speed()


func _to_menu() -> void:
	Game.save_game()
	Game.running = false
	started = false
	get_tree().paused = false
	Engine.time_scale = 1.0
	hud.visible = false
	hud.close_panel()
	cam.enabled = true
	cam.focus("overview", 0.8)
	_build_menu()


func _unhandled_input(event: InputEvent) -> void:
	if started and not get_tree().paused:
		cam.handle(event)


func _on_tap(pos: Vector2) -> void:
	if not started or hud.is_panel_open():
		return
	var hit: Dictionary = store.pick_at(cam.cam, pos)
	if hit.is_empty():
		return
	match hit["type"]:
		"shelf":
			Sfx.play("click")
			hud.open_panel("shelf", int(hit["idx"]))
		"checkout":
			var co: Checkout = store.checkouts[int(hit["idx"])]
			if not co.manual_scan():
				hud.open_panel("checkout", int(hit["idx"]))
		"warehouse":
			hud.open_panel("warehouse")


func _process(delta: float) -> void:
	if started:
		hud.customers_inside = store.customers.size()
		_autosave += delta
		if _autosave > 20.0:
			_autosave = 0.0
			Game.save_game()
