class_name Store
extends Node3D
## Builds the whole 3D world procedurally (store, street, parking, warehouse, decor) and runs the
## customer / staff simulation around it.

const COLS := [-6.0, -3.0, 0.0, 3.0, 6.0]
const LANE_X := [-6.8, -2.6, 1.6]
const LANE_Z := 3.6
const WALL_H := 3.6

var nav := NavGrid.new()
var shelves: Array = []
var checkouts: Array = []
var customers: Array = []
var staff_nodes: Dictionary = {}
var litter: Array = []
var litter_taken: Dictionary = {}
var reserved: Dictionary = {}
var door_inside := Vector3(0, 0, 6.2)
var staff_spawn := Vector3(12.5, 0, -8.0)
var warehouse_spot := Vector3(13.5, 0, -8.0)
var patrol_points: Array = [Vector3(0, 0, 6.4), Vector3(-8.7, 0, 0.5), Vector3(0, 0, -7.5), Vector3(8.7, 0, 0.5)]

var sun: DirectionalLight3D
var env: Environment
var sky_mat: ProceduralSkyMaterial
var omni_lights: Array = []
var lamp_mats: Array = []
var door_l: MeshInstance3D
var door_r: MeshInstance3D
var door_open: float = 0.0
var decor: Dictionary = {}
var floor_mi: MeshInstance3D
var crates: MultiMeshInstance3D
var cars_lot: Array = []
var traffic: Array = []
var _spawn_timer: float = 2.0
var _rng := RandomNumberGenerator.new()
var _customer_seed: int = 1
var _last_cleanliness_n: int = -1
var attract_mode: bool = true
var _tex_cache: Dictionary = {}


# ================================================================ build
func build() -> void:
	_rng.randomize()
	_build_environment()
	_build_ground()
	_build_shell()
	_build_shelves()
	_build_checkouts()
	_build_warehouse()
	_build_decor()
	_build_outdoors()
	_build_nav()
	Game.changed.connect(_on_game_changed)
	Game.upgrade_bought.connect(_on_upgrade)
	apply_quality()
	apply_upgrades()
	refresh_all()


func _tex_mat(tex_name: String, scale: float = 0.25, tint: Color = Color.WHITE, rough: float = 0.8) -> StandardMaterial3D:
	var key := "%s_%.2f_%s_%.2f" % [tex_name, scale, tint.to_html(), rough]
	if _tex_cache.has(key):
		return _tex_cache[key]
	var m := StandardMaterial3D.new()
	var tx: Texture2D = Art.tex(tex_name)
	if tx:
		m.albedo_texture = tx
	m.albedo_color = tint
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	m.uv1_scale = Vector3(scale, scale, scale)
	m.roughness = rough
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	_tex_cache[key] = m
	return m


func _box(parent: Node, size: Vector3, pos: Vector3, material: Material) -> MeshInstance3D:
	return CharFactory.mi(parent, CharFactory.box(size.x, size.y, size.z), material, pos)


func _glass_mat() -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.62, 0.8, 0.92, 0.28)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.roughness = 0.05
	m.metallic = 0.3
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	return m


func _build_environment() -> void:
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, -40, 0)
	sun.light_energy = 1.1
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 60.0
	sun.shadow_bias = 0.06
	sun.add_to_group("sun")
	add_child(sun)
	sky_mat = ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.25, 0.5, 0.9)
	sky_mat.sky_horizon_color = Color(0.72, 0.84, 0.95)
	sky_mat.ground_horizon_color = Color(0.55, 0.62, 0.55)
	sky_mat.ground_bottom_color = Color(0.2, 0.25, 0.2)
	var sky := Sky.new()
	sky.sky_material = sky_mat
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.9
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.0
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	for p in [Vector3(-6, 3.4, -6), Vector3(6, 3.4, -6), Vector3(-6, 3.4, -1), Vector3(6, 3.4, -1), Vector3(0, 3.4, 3), Vector3(0, 3.4, -8)]:
		var o := OmniLight3D.new()
		o.position = p
		o.omni_range = 11.0
		o.light_energy = 0.5
		o.light_color = Color(1.0, 0.95, 0.85)
		o.shadow_enabled = false
		add_child(o)
		omni_lights.append(o)


func _build_ground() -> void:
	var g := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(120, 120)
	g.mesh = pm
	g.material_override = _tex_mat("grass", 0.15, Color.WHITE, 0.95)
	g.position = Vector3(0, -0.05, 0)
	add_child(g)
	# sidewalk + road
	_box(self, Vector3(70, 0.12, 3.4), Vector3(0, 0.0, 9.7), _tex_mat("floor_tile", 0.3, Color(0.85, 0.85, 0.85)))
	_box(self, Vector3(70, 0.08, 6.6), Vector3(0, -0.02, 14.7), _tex_mat("road", 0.12, Color.WHITE, 0.9))
	for i in range(-6, 7):
		_box(self, Vector3(2.2, 0.01, 0.18), Vector3(i * 5.0, 0.03, 14.7), CharFactory.mat(Color("f1f1f1"), 0.9))
	# parking lot (west)
	_box(self, Vector3(11.0, 0.08, 17.0), Vector3(-16.5, -0.01, -1.5), _tex_mat("road", 0.12, Color(0.9, 0.9, 0.95), 0.9))
	for r in range(6):
		var z: float = -8.5 + float(r) * 3.0
		_box(self, Vector3(10.0, 0.01, 0.1), Vector3(-16.5, 0.04, z), CharFactory.mat(Color("f1f1f1"), 0.9))
	_box(self, Vector3(0.1, 0.01, 15.0), Vector3(-16.5, 0.04, -1.0), CharFactory.mat(Color("f1f1f1"), 0.9))
	# warehouse yard
	_box(self, Vector3(7.4, 0.1, 7.4), Vector3(13.9, -0.02, -6.7), CharFactory.mat(Color("8d99ae"), 0.9))


func _build_shell() -> void:
	var wall_m := _tex_mat("wall", 0.3, Color.WHITE, 0.85)
	var trim := CharFactory.mat(Color("2b2d42"), 0.4, 0.4)
	# floor
	floor_mi = _box(self, Vector3(20.6, 0.2, 18.6), Vector3(0, -0.1, -1.0), _tex_mat("floor_tile", 0.25, Color.WHITE, 0.45))
	# back + side walls
	_box(self, Vector3(20.8, WALL_H, 0.3), Vector3(0, WALL_H / 2.0, -10.15), wall_m)
	_box(self, Vector3(0.3, WALL_H, 18.6), Vector3(-10.15, WALL_H / 2.0, -1.0), wall_m)
	_box(self, Vector3(0.3, WALL_H, 1.0), Vector3(10.15, WALL_H / 2.0, -9.5), wall_m)
	_box(self, Vector3(0.3, WALL_H, 15.0), Vector3(10.15, WALL_H / 2.0, 0.5), wall_m)
	_box(self, Vector3(0.3, 1.0, 2.0), Vector3(10.15, WALL_H - 0.5, -8.0), wall_m)  # lintel over warehouse door
	# front facade: low base, glass, pillars, header
	var glass := _glass_mat()
	for side in [-1, 1]:
		_box(self, Vector3(8.0, 0.9, 0.3), Vector3(side * 6.2, 0.45, 8.15), wall_m)
		var gl := _box(self, Vector3(8.0, 2.5, 0.06), Vector3(side * 6.2, 2.15, 8.15), glass)
		gl.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	for x in [-10.1, -6.2, -2.2, 2.2, 6.2, 10.1]:
		_box(self, Vector3(0.22, 3.9, 0.35), Vector3(x, 1.95, 8.2), trim)
	_box(self, Vector3(20.6, 0.8, 0.5), Vector3(0, 3.95, 8.2), CharFactory.mat(Color("22223b"), 0.4, 0.3))
	_box(self, Vector3(4.6, 0.35, 0.4), Vector3(0, 3.25, 8.2), trim)
	var sign_l := Label3D.new()
	sign_l.text = "MEGA MART"
	sign_l.font_size = 200
	sign_l.pixel_size = 0.0075
	sign_l.modulate = Color("ffd166")
	sign_l.outline_size = 24
	sign_l.outline_modulate = Color("5a3a00")
	sign_l.position = Vector3(0, 3.95, 8.5)
	add_child(sign_l)
	# sliding doors
	door_l = _box(self, Vector3(1.95, 2.6, 0.06), Vector3(-1.0, 1.3, 8.22), glass)
	door_r = _box(self, Vector3(1.95, 2.6, 0.06), Vector3(1.0, 1.3, 8.22), glass)
	door_l.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	door_r.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	# hanging light bars (emissive) over aisles
	for z in [-7.5, -3.2, 0.2, 6.2]:
		for x in [-6.0, 0.0, 6.0]:
			var lm: StandardMaterial3D = CharFactory.emissive(Color("fff4d6"), 2.2).duplicate()
			lamp_mats.append(lm)
			_box(self, Vector3(2.4, 0.08, 0.25), Vector3(x, 3.45, z), lm).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	# exterior signage
	var board := _box(self, Vector3(7.0, 2.0, 0.3), Vector3(-5.5, 1.0, 10.3), CharFactory.mat(Color("22223b"), 0.5))
	var info := Label3D.new()
	info.text = "OPEN\nFresh food - Great prices"
	info.font_size = 70
	info.pixel_size = 0.01
	info.position = Vector3(-5.5, 1.1, 10.46)
	info.modulate = Color("7CFFB2")
	add_child(info)
	board.visible = false
	info.visible = false


func _shelf_defs() -> Array:
	var defs: Array = []
	for c in COLS:
		defs.append({"x": c, "z": -9.55, "rot": 0.0, "pick_z": -8.3, "tall": true})
	for c in COLS:
		defs.append({"x": c, "z": -5.45, "rot": PI, "pick_z": -6.95, "tall": false})
	for c in COLS:
		defs.append({"x": c, "z": -4.55, "rot": 0.0, "pick_z": -3.4, "tall": false})
	for c in COLS:
		defs.append({"x": c, "z": -1.8, "rot": PI, "pick_z": -2.8, "tall": false})
	for c in COLS:
		defs.append({"x": c, "z": -1.0, "rot": 0.0, "pick_z": 0.2, "tall": false})
	return defs


func _build_shelves() -> void:
	var defs: Array = _shelf_defs()
	for i in range(defs.size()):
		var d: Dictionary = defs[i]
		var s := Shelf.new()
		s.position = Vector3(d["x"], 0, d["z"])
		s.rotation.y = d["rot"]
		s.pick_world = Vector3(d["x"], 0, d["pick_z"])
		add_child(s)
		s.build(i, d["tall"])
		shelves.append(s)


func _build_checkouts() -> void:
	for i in range(3):
		var c := Checkout.new()
		c.position = Vector3(LANE_X[i], 0, LANE_Z)
		add_child(c)
		c.build(i)
		checkouts.append(c)


func _build_warehouse() -> void:
	var wall := CharFactory.mat(Color("adb5bd"), 0.8)
	_box(self, Vector3(7.2, 3.2, 0.3), Vector3(13.9, 1.6, -10.15), wall)
	_box(self, Vector3(7.2, 3.2, 0.3), Vector3(13.9, 1.6, -3.35), wall)
	_box(self, Vector3(0.3, 3.2, 7.0), Vector3(17.15, 1.6, -6.7), wall)
	_box(self, Vector3(0.3, 3.2, 1.0), Vector3(10.35, 1.6, -9.5), wall)
	_box(self, Vector3(0.3, 3.2, 3.5), Vector3(10.35, 1.6, -5.0), wall)
	_box(self, Vector3(0.3, 1.0, 2.0), Vector3(10.35, 2.7, -8.0), wall)
	var wl := Label3D.new()
	wl.text = "WAREHOUSE"
	wl.font_size = 110
	wl.pixel_size = 0.01
	wl.modulate = Color("ffb703")
	wl.outline_size = 14
	wl.position = Vector3(13.9, 3.0, -3.1)
	add_child(wl)
	# racks + crates
	for rz in [-9.2, -4.2]:
		_box(self, Vector3(6.0, 0.08, 0.7), Vector3(13.9, 0.2, rz), CharFactory.mat(Color("495057"), 0.5, 0.6))
	crates = MultiMeshInstance3D.new()
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = CharFactory.box(0.7, 0.5, 0.6)
	mm.instance_count = 60
	for i in range(60):
		var col: int = i % 10
		var row: int = (i / 10) % 3
		var side: int = i / 30
		var x: float = 11.2 + float(col) * 0.62
		var y: float = 0.28 + 0.46 * float(row)
		var z: float = -9.2 if side == 0 else -4.2
		mm.set_instance_transform(i, Transform3D(Basis().scaled(Vector3(0.85, 0.85, 0.85)), Vector3(x, y, z)))
	crates.multimesh = mm
	crates.material_override = CharFactory.mat(Color("c9a227"), 0.8)
	add_child(crates)


func _build_decor() -> void:
	for lvl in range(2, 6):
		var g := Node3D.new()
		g.visible = false
		add_child(g)
		decor[lvl] = g
	# level 2: pillars + planters
	var gold := CharFactory.mat(Color("d4a017"), 0.25, 0.9)
	var marble := CharFactory.mat(Color("f1efe9"), 0.2)
	for x in [-9.5, 9.5]:
		CharFactory.mi(decor[2], CharFactory.cyl(0.28, 0.3, 3.4, 16), marble, Vector3(x, 1.7, 7.3))
		CharFactory.mi(decor[2], CharFactory.cyl(0.32, 0.32, 0.12, 16), gold, Vector3(x, 0.6, 7.3))
	for x in [-3.6, 3.6]:
		CharFactory.mi(decor[2], CharFactory.cyl(0.35, 0.28, 0.7, 12), CharFactory.mat(Color("8d6e63"), 0.9), Vector3(x, 0.35, 7.4))
		CharFactory.mi(decor[2], CharFactory.sphere(0.5), CharFactory.mat(Color("2d6a4f"), 0.9), Vector3(x, 1.2, 7.4))
		CharFactory.mi(decor[2], CharFactory.sphere(0.35), CharFactory.mat(Color("40916c"), 0.9), Vector3(x + 0.2, 1.7, 7.4))
	# level 3: wall accent bands + pendant glow
	for z in [-7.5, -3.2]:
		_box(decor[3], Vector3(0.1, 0.25, 6.0), Vector3(-9.95, 2.4, z + 3.0), CharFactory.emissive(Color("ffd166"), 1.2))
		_box(decor[3], Vector3(0.1, 0.25, 6.0), Vector3(9.95, 2.4, z + 3.0), CharFactory.emissive(Color("ffd166"), 1.2))
	_box(decor[3], Vector3(19.6, 0.2, 0.1), Vector3(0, 2.9, -9.95), CharFactory.emissive(Color("4cc9f0"), 1.4))
	# level 4: chandelier + gold sign trim
	for k in range(8):
		var a: float = float(k) / 8.0 * TAU
		CharFactory.mi(decor[4], CharFactory.sphere(0.12), CharFactory.emissive(Color("fff1c1"), 3.0), Vector3(cos(a) * 0.9, 3.0, 5.0 + sin(a) * 0.9))
	CharFactory.mi(decor[4], CharFactory.cyl(0.1, 0.1, 0.7), gold, Vector3(0, 3.35, 5.0))
	_box(decor[4], Vector3(9.4, 0.12, 0.5), Vector3(0, 4.45, 8.2), gold)
	# level 5: red carpet + statues
	_box(decor[5], Vector3(2.2, 0.03, 7.0), Vector3(0, 0.03, 4.7), CharFactory.mat(Color("9d0208"), 0.9))
	for x in [-1.8, 1.8]:
		CharFactory.mi(decor[5], CharFactory.cyl(0.25, 0.3, 0.9), marble, Vector3(x, 0.45, 7.0))
		CharFactory.mi(decor[5], CharFactory.sphere(0.28), gold, Vector3(x, 1.2, 7.0))


func _build_outdoors() -> void:
	# street lamps
	for x in [-18.0, -9.0, 0.0, 9.0, 18.0]:
		CharFactory.mi(self, CharFactory.cyl(0.07, 0.09, 4.4), CharFactory.mat(Color("343a40"), 0.5, 0.6), Vector3(x, 2.2, 11.2))
		var lm: StandardMaterial3D = CharFactory.emissive(Color("fff3c4"), 0.2).duplicate()
		lamp_mats.append(lm)
		CharFactory.mi(self, CharFactory.sphere(0.25), lm, Vector3(x, 4.5, 11.2))
	# trees
	for p in [Vector2(-22, 11.6), Vector2(-14, 11.6), Vector2(14, 11.6), Vector2(22, 11.6), Vector2(-22, 8.5), Vector2(22, 8.5), Vector2(-12, -14), Vector2(0, -14), Vector2(12, -14), Vector2(-24, -4), Vector2(21, 2), Vector2(21, -1)]:
		_tree(Vector3(p.x, 0, p.y))
	# parked cars (west lot)
	var cols := [Color("c1121f"), Color("1d3557"), Color("f1faee"), Color("ffb703"), Color("2a9d8f"), Color("6d597a"), Color("495057"), Color("e76f51"), Color("457b9d"), Color("8ac926")]
	var idx := 0
	for cx in [-19.0, -14.0]:
		for r in range(5):
			var car := _make_car(cols[idx % cols.size()])
			car.position = Vector3(cx, 0, -7.0 + float(r) * 3.0)
			car.rotation.y = PI / 2.0 * (1.0 if cx < -16 else -1.0) * 0.0
			add_child(car)
			cars_lot.append(car)
			idx += 1
	# street traffic
	for i in range(4):
		var car := _make_car(cols[(i * 3) % cols.size()])
		car.rotation.y = PI / 2.0 if i % 2 == 0 else -PI / 2.0
		car.position = Vector3(-30.0 + float(i) * 15.0, 0, 13.4 if i % 2 == 0 else 16.0)
		add_child(car)
		traffic.append(car)


func _tree(p: Vector3) -> void:
	var t := Node3D.new()
	t.position = p
	add_child(t)
	CharFactory.mi(t, CharFactory.cyl(0.18, 0.25, 2.0), CharFactory.mat(Color("6f4e37"), 0.95), Vector3(0, 1.0, 0))
	var leaf := CharFactory.mat(Color("2d6a4f").lerp(Color("52b788"), randf()), 0.9)
	CharFactory.mi(t, CharFactory.sphere(1.3), leaf, Vector3(0, 2.8, 0))
	CharFactory.mi(t, CharFactory.sphere(0.95), leaf, Vector3(0.6, 3.6, 0.3))
	CharFactory.mi(t, CharFactory.sphere(0.8), leaf, Vector3(-0.5, 3.4, -0.4))


func _make_car(color: Color) -> Node3D:
	var car := Node3D.new()
	var body := CharFactory.mat(color, 0.25, 0.6)
	var glass := CharFactory.mat(Color("1b263b"), 0.1, 0.5)
	CharFactory.mi(car, CharFactory.box(1.9, 0.6, 4.2), body, Vector3(0, 0.55, 0))
	CharFactory.mi(car, CharFactory.box(1.7, 0.55, 2.2), glass, Vector3(0, 1.1, -0.1))
	CharFactory.mi(car, CharFactory.box(1.75, 0.08, 2.0), body, Vector3(0, 1.4, -0.1))
	for wx in [-0.95, 0.95]:
		for wz in [-1.3, 1.3]:
			var w := CharFactory.mi(car, CharFactory.cyl(0.36, 0.36, 0.25, 12), CharFactory.mat(Color("111111"), 0.8), Vector3(wx, 0.36, wz))
			w.rotation.z = PI / 2.0
	CharFactory.mi(car, CharFactory.box(0.4, 0.14, 0.05), CharFactory.emissive(Color("fff2cc"), 1.5), Vector3(-0.6, 0.6, 2.12))
	CharFactory.mi(car, CharFactory.box(0.4, 0.14, 0.05), CharFactory.emissive(Color("fff2cc"), 1.5), Vector3(0.6, 0.6, 2.12))
	return car


# ================================================================ navigation grid
func _build_nav() -> void:
	# store walls
	nav.set_rect(-10.5, -10.5, 10.5, -9.9, true)
	nav.set_rect(-10.5, -10.5, -9.7, 8.6, true)
	nav.set_rect(9.7, -10.5, 10.5, -9.0, true)
	nav.set_rect(9.7, -7.0, 10.5, 8.6, true)
	nav.set_rect(-10.5, 7.8, -2.2, 8.6, true)
	nav.set_rect(2.2, 7.8, 10.5, 8.6, true)
	# warehouse walls
	nav.set_rect(10.3, -10.5, 17.5, -9.9, true)
	nav.set_rect(10.3, -3.6, 17.5, -3.0, true)
	nav.set_rect(16.8, -10.5, 17.5, -3.0, true)
	nav.set_rect(10.3, -5.4, 10.8, -3.0, true)
	# shelf blocks (inflated 0.35)
	nav.set_rect(-7.7, -10.3, 7.7, -8.8, true)
	nav.set_rect(-7.7, -6.2, 7.7, -3.8, true)
	nav.set_rect(-7.7, -2.55, 7.7, -0.25, true)
	_refresh_nav_lanes()


func _refresh_nav_lanes() -> void:
	for i in range(3):
		var x: float = LANE_X[i]
		nav.set_rect(x - 1.65, 2.7, x + 1.65, 4.6, i < int(Game.upgrades["lanes"]))


# ================================================================ game sync
func _on_game_changed() -> void:
	refresh_all()


func _on_upgrade(_id: String) -> void:
	apply_upgrades()


func refresh_all() -> void:
	for s in shelves:
		(s as Shelf).refresh()
	_update_crates()
	sync_staff()


func _update_crates() -> void:
	if crates and crates.multimesh:
		var frac: float = float(Game.warehouse_used()) / float(maxi(Game.warehouse_capacity(), 1))
		crates.multimesh.visible_instance_count = clampi(int(ceil(frac * 60.0)), 0, 60) if Game.warehouse_used() > 0 else 0


func apply_upgrades() -> void:
	var lanes: int = int(Game.upgrades["lanes"])
	for i in range(checkouts.size()):
		(checkouts[i] as Checkout).visible = i < lanes
	_refresh_nav_lanes()
	var lvl: int = int(Game.upgrades["store_level"])
	for k in decor:
		(decor[k] as Node3D).visible = lvl >= int(k)
	if lvl >= 3:
		floor_mi.material_override = _tex_mat("floor_marble", 0.25, Color.WHITE, 0.15)
	else:
		floor_mi.material_override = _tex_mat("floor_tile", 0.25, Color.WHITE, 0.45)
	var park: int = int(Game.upgrades["parking"])
	var n_cars: int = mini(cars_lot.size(), 2 + park * 2)
	for i in range(cars_lot.size()):
		(cars_lot[i] as Node3D).visible = i < n_cars
	for s in shelves:
		(s as Shelf).refresh()


func find_shelf_for(pid: String) -> int:
	var best: int = -1
	var most: int = 0
	for i in range(Game.MAX_SHELVES):
		if Game.shelf_unlocked(i) and Game.shelf_product[i] == pid and int(Game.shelf_stock[i]) > most:
			most = int(Game.shelf_stock[i])
			best = i
	return best


# ================================================================ staff
func sync_staff() -> void:
	var live := {}
	for e in Game.employees:
		var id: int = int(e["id"])
		live[id] = true
		if not staff_nodes.has(id) or not is_instance_valid(staff_nodes[id]):
			var emp := Employee.new()
			add_child(emp)
			emp.setup(self, e)
			staff_nodes[id] = emp
	for id in staff_nodes.keys():
		if not live.has(id):
			var node: Employee = staff_nodes[id]
			if is_instance_valid(node):
				node.release()
				node.queue_free()
			staff_nodes.erase(id)


# ================================================================ customers / litter / fx
func _spawn_customer() -> void:
	_customer_seed += 1
	var from: Vector3
	var exit_p: Vector3
	var r: float = _rng.randf()
	if r < 0.45:
		from = Vector3(-12.2, 0, _rng.randf_range(-3.0, 5.0))
		exit_p = from
	elif r < 0.75:
		from = Vector3(-23.0, 0, 9.6)
		exit_p = from
	else:
		from = Vector3(23.0, 0, 9.6)
		exit_p = from
	var c := Customer.new()
	add_child(c)
	c.setup(self, _rng.randi(), from, exit_p)
	customers.append(c)


func reset_world() -> void:
	for c in customers:
		if is_instance_valid(c):
			c.queue_free()
	customers.clear()
	for id in staff_nodes.keys():
		var n: Employee = staff_nodes[id]
		if is_instance_valid(n):
			n.release()
			n.queue_free()
	staff_nodes.clear()
	for l in litter:
		if is_instance_valid(l):
			l.queue_free()
	litter.clear()
	litter_taken.clear()
	reserved.clear()
	for co in checkouts:
		var ch: Checkout = co
		ch.queue.clear()
		ch.cashier = null
		ch.scanning_active = false
		ch.items_left = 0
	_update_cleanliness()


func customer_left(c: Customer) -> void:
	customers.erase(c)


func spawn_text(pos: Vector3, text: String, color: Color) -> void:
	var l := Label3D.new()
	l.text = text
	l.font_size = 64
	l.pixel_size = 0.008
	l.modulate = color
	l.outline_size = 12
	l.outline_modulate = Color(0, 0, 0, 0.9)
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.position = pos
	add_child(l)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "position:y", pos.y + 1.4, 1.2)
	tw.tween_property(l, "modulate:a", 0.0, 1.2).set_delay(0.5)
	tw.chain().tween_callback(l.queue_free)


func drop_litter(pos: Vector3) -> void:
	if litter.size() >= 8:
		return
	var m := MeshInstance3D.new()
	m.mesh = CharFactory.box(0.22, 0.04, 0.18)
	m.material_override = CharFactory.mat(Color("e9d8a6") if _rng.randf() < 0.5 else Color("90be6d"), 0.9)
	m.position = Vector3(pos.x + _rng.randf_range(-0.3, 0.3), 0.03, pos.z + _rng.randf_range(-0.3, 0.3))
	m.rotation.y = _rng.randf() * TAU
	add_child(m)
	litter.append(m)
	_update_cleanliness()


func nearest_litter(from: Vector3) -> Node3D:
	var best: Node3D = null
	var bd: float = 1e9
	for l in litter:
		if litter_taken.has(l):
			continue
		var d: float = from.distance_to((l as Node3D).position)
		if d < bd:
			bd = d
			best = l
	return best


func remove_litter(l: Node3D) -> void:
	litter.erase(l)
	litter_taken.erase(l)
	if is_instance_valid(l):
		l.queue_free()
	_update_cleanliness()


func _update_cleanliness() -> void:
	Game.cleanliness = clampf(1.0 - float(litter.size()) / 8.0, 0.0, 1.0)


# ================================================================ interaction
func pick_at(cam: Camera3D, pos: Vector2) -> Dictionary:
	var best: Dictionary = {}
	var best_d: float = 90.0
	for s in shelves:
		var sh: Shelf = s
		if not sh.visible:
			continue
		var p: Vector3 = sh.tap_pos()
		if cam.is_position_behind(p):
			continue
		var d: float = cam.unproject_position(p).distance_to(pos)
		if d < best_d:
			best_d = d
			best = {"type": "shelf", "idx": sh.idx}
	for c in checkouts:
		var co: Checkout = c
		if not co.visible:
			continue
		var p: Vector3 = co.global_position + Vector3(0, 1.2, 0)
		if cam.is_position_behind(p):
			continue
		var d: float = cam.unproject_position(p).distance_to(pos)
		if d < best_d:
			best_d = d
			best = {"type": "checkout", "idx": co.lane}
	var wp := Vector3(13.9, 1.0, -6.7)
	if not cam.is_position_behind(wp):
		var dw: float = cam.unproject_position(wp).distance_to(pos)
		if dw < best_d + 20.0:
			best = {"type": "warehouse"}
	return best


# ================================================================ quality + daylight
func apply_quality() -> void:
	var q: int = clampi(int(Game.settings["quality"]), 0, 3)
	var vp: Viewport = get_viewport()
	if vp:
		vp.msaa_3d = [Viewport.MSAA_DISABLED, Viewport.MSAA_DISABLED, Viewport.MSAA_2X, Viewport.MSAA_4X][q]
		vp.scaling_3d_scale = [0.7, 0.85, 1.0, 1.0][q]
	Engine.max_fps = [30, 30, 45, 60][q]
	var nl: int = [0, 2, 6, 6][q]
	for i in range(omni_lights.size()):
		(omni_lights[i] as OmniLight3D).visible = i < nl
	_lights_on = nl
	_day_acc = 99.0
	sun.shadow_enabled = q >= 2
	sun.directional_shadow_mode = [DirectionalLight3D.SHADOW_ORTHOGONAL, DirectionalLight3D.SHADOW_ORTHOGONAL, DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS, DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS][q]
	RenderingServer.directional_shadow_atlas_set_size([1024, 2048, 4096, 4096][q], true)
	for i in range(traffic.size()):
		(traffic[i] as Node3D).visible = q >= 1 or i < 1


var _lights_on: int = 6
var _day_acc: float = 99.0


func _update_daylight() -> void:
	var p: float = clampf(Game.day_time / Game.DAY_LENGTH, 0.0, 1.0)
	var e: float = sin(p * PI)
	sun.rotation_degrees = Vector3(-(8.0 + 62.0 * e), lerpf(70.0, -70.0, p), 0)
	sun.light_energy = 0.08 + 1.05 * e
	sun.light_color = Color(1.0, 0.72, 0.5).lerp(Color(1.0, 0.96, 0.9), clampf(e * 1.6, 0.0, 1.0))
	var night: float = 1.0 - clampf(e * 2.2, 0.0, 1.0)
	sky_mat.sky_top_color = Color(0.02, 0.03, 0.09).lerp(Color(0.25, 0.5, 0.9), 1.0 - night)
	sky_mat.sky_horizon_color = Color(0.1, 0.1, 0.2).lerp(Color(0.72, 0.84, 0.95), 1.0 - night)
	sky_mat.ground_horizon_color = sky_mat.sky_horizon_color
	env.ambient_light_energy = 0.35 + 0.65 * (1.0 - night) + (0.35 if _lights_on == 0 else 0.0)
	var lamp: float = 0.6 + 0.8 * night
	for o in omni_lights:
		(o as OmniLight3D).light_energy = lamp * 0.8
	for m in lamp_mats:
		(m as StandardMaterial3D).emission_energy_multiplier = 0.4 + 2.8 * night


# ================================================================ loop
func _process(delta: float) -> void:
	_day_acc += delta
	if _day_acc >= 1.0:
		_day_acc = 0.0
		_update_daylight()
	# sliding doors
	var near := false
	for c in customers:
		if is_instance_valid(c) and (c as Node3D).position.distance_to(Vector3(0, 0, 8.2)) < 3.2:
			near = true
			break
	if not near:
		for id in staff_nodes:
			var st: Node3D = staff_nodes[id]
			if is_instance_valid(st) and st.position.distance_to(Vector3(0, 0, 8.2)) < 2.5:
				near = true
				break
	var target: float = 1.0 if near else 0.0
	if absf(target - door_open) > 0.001:
		var was: float = door_open
		door_open = move_toward(door_open, target, delta * 2.2)
		if was == 0.0 and door_open > 0.0:
			Sfx.play("door", 1.0, -8.0)
	door_l.position.x = -1.0 - 1.9 * door_open
	door_r.position.x = 1.0 + 1.9 * door_open
	door_l.position.z = 8.22 + 0.12 * door_open
	door_r.position.z = 8.22 + 0.12 * door_open
	# street traffic
	for i in range(traffic.size()):
		var car: Node3D = traffic[i]
		var dir: float = 1.0 if i % 2 == 0 else -1.0
		car.position.x += dir * delta * (5.5 + float(i))
		if car.position.x > 40.0:
			car.position.x = -40.0
		elif car.position.x < -40.0:
			car.position.x = 40.0
	# spawn customers
	if Game.running and Game.is_open():
		_spawn_timer -= delta
		if _spawn_timer <= 0.0:
			_spawn_timer = (4.5 / Game.spawn_rate_mult()) * _rng.randf_range(0.7, 1.3)
			if customers.size() < Game.max_customers_inside():
				_spawn_customer()
