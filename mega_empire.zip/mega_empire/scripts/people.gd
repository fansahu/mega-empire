class_name PersonModels
extends RefCounted
## Real rigged human models (GLB) with animations retargeted from one donor (Mixamo Soldier: Idle/Walk).
## Any extra *.glb in assets/models/people/ is picked up automatically:
##  - file with its own walk/idle animations  -> used as is ("native")
##  - humanoid with Mixamo-style bone names (mixamorig_Hips or Hips) and NO animations -> animations retargeted.

const DIR := "res://assets/models/people/"
const DONOR := "Soldier"
const ROLE_COL := {"cashier": Color("2ecc71"), "stock": Color("3498db"), "cleaner": Color("1abc9c"), "guard": Color("e74c3c"), "supervisor": Color("f1c40f")}
const ROLE_TXT := {"cashier": "CASHIER", "stock": "STOCK", "cleaner": "CLEANER", "guard": "GUARD", "supervisor": "MANAGER"}
const SHIRTS := [Color("2f5d8a"), Color("8a2f3d"), Color("3d7a4a"), Color("d9d4c7"), Color("5b4a8a"), Color("c28a2c"), Color("2b2f36"), Color("7a8a99")]
const PANTS := [Color("1f2933"), Color("3a3f4a"), Color("5a4632"), Color("2b3a55"), Color("6b6b6b")]
const SKINS := [Color(1, 1, 1), Color(0.9, 0.78, 0.68), Color(0.78, 0.62, 0.5), Color(0.6, 0.45, 0.36)]

static var _defs: Array = []
static var _scenes: Dictionary = {}
static var _donor_skel: Skeleton3D = null
static var _donor_anims: Dictionary = {}
static var _loaded: bool = false


static func available() -> bool:
	_init_defs()
	return not _defs.is_empty()


static func _list() -> Array:
	var out: Array = []
	var d := DirAccess.open(DIR)
	if d == null:
		return out
	for f in d.get_files():
		var fl: String = f
		var base := ""
		if fl.ends_with(".glb"):
			base = fl.get_basename()
		elif fl.ends_with(".glb.import"):
			base = fl.get_basename().get_basename()
		if base != "" and not out.has(base):
			out.append(base)
	out.sort()
	return out


static func _first(n: Node, cls: String) -> Node:
	var l: Array = n.find_children("*", cls, true, false)
	return l[0] if l.size() > 0 else null


static func _init_defs() -> void:
	if _loaded:
		return
	_loaded = true
	var files: Array = _list()
	if files.has(DONOR):
		var dn: Node = (load(DIR + DONOR + ".glb") as PackedScene).instantiate()
		var ap := _first(dn, "AnimationPlayer") as AnimationPlayer
		_donor_skel = _first(dn, "Skeleton3D") as Skeleton3D
		if ap != null:
			for an in ["Idle", "Walk"]:
				if ap.has_animation(an):
					_donor_anims[String(an).to_lower()] = ap.get_animation(an)
		_donor_scene_keep = dn
	for f in files:
		var fname: String = f
		var sc: PackedScene = load(DIR + fname + ".glb")
		if sc == null:
			continue
		_scenes[fname] = sc
		var probe: Node = sc.instantiate()
		var ap2 := _first(probe, "AnimationPlayer") as AnimationPlayer
		var has_walk := false
		if ap2 != null:
			for an in ap2.get_animation_list():
				if String(an).to_lower().contains("walk") or String(an).to_lower().contains("run"):
					has_walk = true
		var has_skel := _first(probe, "Skeleton3D") != null
		probe.free()
		var mode := ""
		if has_walk:
			mode = "native"
		elif has_skel and _donor_skel != null and fname != DONOR:
			mode = "retarget"
		if fname == DONOR:
			mode = "native"
		if mode == "":
			continue
		_defs.append({"name": fname, "mode": mode, "guard_only": fname == DONOR, "cache": {}})


static var _donor_scene_keep: Node = null


# ---------------------------------------------------------------- retargeting
static func _bone_map(src: Skeleton3D, dst: Skeleton3D) -> Dictionary:
	var m := {}
	for i in range(dst.get_bone_count()):
		var dn: String = dst.get_bone_name(i)
		var si: int = src.find_bone(dn)
		if si < 0:
			si = src.find_bone("mixamorig_" + dn)
		if si < 0 and dn.begins_with("mixamorig_"):
			si = src.find_bone(dn.substr(10))
		if si >= 0:
			m[i] = si
	return m


static func _globals_rest(sk: Skeleton3D) -> Array:
	var g: Array = []
	g.resize(sk.get_bone_count())
	for i in range(sk.get_bone_count()):
		g[i] = (sk.get_bone_global_rest(i) as Transform3D).basis.get_rotation_quaternion()
	return g


static func _bpos(sk: Skeleton3D, nm: String) -> Vector3:
	var i: int = sk.find_bone(nm)
	if i < 0:
		i = sk.find_bone("mixamorig_" + nm)
	if i < 0:
		i = sk.find_bone("mixamorig:" + nm)
	if i < 0:
		return Vector3.ZERO
	return (sk.get_bone_global_rest(i) as Transform3D).origin


static func _body_basis(sk: Skeleton3D) -> Basis:
	var up: Vector3 = (_bpos(sk, "Head") - _bpos(sk, "Hips")).normalized()
	var right: Vector3 = (_bpos(sk, "LeftUpLeg") - _bpos(sk, "RightUpLeg")).normalized()
	var fwd: Vector3 = right.cross(up).normalized()
	right = up.cross(fwd).normalized()
	return Basis(right, up, fwd)


static func _frame_between(src: Skeleton3D, dst: Skeleton3D) -> Quaternion:
	var bs: Basis = _body_basis(src)
	var bd: Basis = _body_basis(dst)
	return (bd * bs.inverse()).get_rotation_quaternion()


static func _retarget(src_anim: Animation, src: Skeleton3D, dst: Skeleton3D, skel_path: String) -> Animation:
	var out := Animation.new()
	out.length = src_anim.length
	out.loop_mode = Animation.LOOP_LINEAR
	var map: Dictionary = _bone_map(src, dst)
	var src_rot_track := {}
	var src_pos_track := {}
	for ti in range(src_anim.get_track_count()):
		var tp: String = String(src_anim.track_get_path(ti))
		var ci: int = tp.find(":")
		if ci < 0:
			continue
		var bi: int = src.find_bone(tp.substr(ci + 1))
		if bi < 0:
			continue
		if src_anim.track_get_type(ti) == Animation.TYPE_ROTATION_3D:
			src_rot_track[bi] = ti
		elif src_anim.track_get_type(ti) == Animation.TYPE_POSITION_3D:
			src_pos_track[bi] = ti
	var F: Quaternion = _frame_between(src, dst)
	var Fi: Quaternion = F.inverse()
	var sg_rest: Array = _globals_rest(src)
	var dg_rest: Array = _globals_rest(dst)
	var nd: int = dst.get_bone_count()
	var ns: int = src.get_bone_count()
	var dtracks: Array = []
	dtracks.resize(nd)
	for b in range(nd):
		var tr: int = out.add_track(Animation.TYPE_ROTATION_3D)
		out.track_set_path(tr, NodePath(skel_path + ":" + dst.get_bone_name(b)))
		dtracks[b] = tr
	var hips_d: int = -1
	for b in range(nd):
		if dst.get_bone_parent(b) < 0 and map.has(b):
			hips_d = b
			break
	var pos_tr := -1
	var hips_scale := 1.0
	var hips_rest_s := Vector3.ZERO
	var hips_rest_d := Vector3.ZERO
	if hips_d >= 0:
		pos_tr = out.add_track(Animation.TYPE_POSITION_3D)
		out.track_set_path(pos_tr, NodePath(skel_path + ":" + dst.get_bone_name(hips_d)))
		var hs: int = map[hips_d]
		hips_rest_s = (src.get_bone_global_rest(hs) as Transform3D).origin
		hips_rest_d = (dst.get_bone_global_rest(hips_d) as Transform3D).origin
		var hs_h: float = (F * hips_rest_s).y
		if absf(hs_h) > 0.0001:
			hips_scale = hips_rest_d.y / hs_h
	var step := 1.0 / 30.0
	var t := 0.0
	var n_steps: int = int(ceil(src_anim.length / step))
	for k in range(n_steps + 1):
		t = minf(float(k) * step, src_anim.length)
		var s_glob: Array = []
		s_glob.resize(ns)
		for b in range(ns):
			var q: Quaternion = src.get_bone_rest(b).basis.get_rotation_quaternion()
			if src_rot_track.has(b):
				q = src_anim.rotation_track_interpolate(src_rot_track[b], t)
			var p: int = src.get_bone_parent(b)
			s_glob[b] = (s_glob[p] as Quaternion) * q if p >= 0 else q
		var d_glob: Array = []
		d_glob.resize(nd)
		for b in range(nd):
			var p: int = dst.get_bone_parent(b)
			var gq: Quaternion
			if map.has(b):
				var sb: int = map[b]
				var delta: Quaternion = F * ((s_glob[sb] as Quaternion) * (sg_rest[sb] as Quaternion).inverse()) * Fi
				gq = delta * (dg_rest[b] as Quaternion)
			else:
				var rl: Quaternion = dst.get_bone_rest(b).basis.get_rotation_quaternion()
				gq = (d_glob[p] as Quaternion) * rl if p >= 0 else rl
			d_glob[b] = gq
			var lq: Quaternion = (d_glob[p] as Quaternion).inverse() * gq if p >= 0 else gq
			out.rotation_track_insert_key(dtracks[b], t, lq.normalized())
		if pos_tr >= 0:
			var hs2: int = map[hips_d]
			var sp: Vector3 = hips_rest_s
			if src_pos_track.has(hs2):
				sp = src_anim.position_track_interpolate(src_pos_track[hs2], t)
			var np: Vector3 = hips_rest_d + (F * (sp - hips_rest_s)) * hips_scale
			out.position_track_insert_key(pos_tr, t, np)
	return out


# ---------------------------------------------------------------- build
static func _pick_def(rng: RandomNumberGenerator, role: String) -> Dictionary:
	var pool: Array = []
	for d in _defs:
		if role == "guard" and d["guard_only"]:
			pool.append(d)
		elif role != "guard" and not d["guard_only"]:
			pool.append(d)
	if pool.is_empty():
		pool = _defs
	return pool[rng.randi() % pool.size()]


static func build(seed_value: int, role: String) -> Node3D:
	_init_defs()
	var rng := RandomNumberGenerator.new()
	rng.seed = (seed_value * 2654435761 + 12345) % 4294967296
	rng.randi()
	var def: Dictionary = _pick_def(rng, role)
	var root := Node3D.new()
	var inst: Node3D = (_scenes[def["name"]] as PackedScene).instantiate()
	var sc: float = rng.randf_range(0.97, 1.04)
	inst.scale = Vector3(sc, sc, sc)
	root.add_child(inst)
	var ap: AnimationPlayer = _first(inst, "AnimationPlayer") as AnimationPlayer
	var sk: Skeleton3D = _first(inst, "Skeleton3D") as Skeleton3D
	var names := {"idle": "", "walk": ""}
	if def["mode"] == "retarget":
		if ap == null:
			ap = AnimationPlayer.new()
			inst.add_child(ap)
			ap.root_node = NodePath("..")
			ap.add_animation_library("", AnimationLibrary.new())
		var lib: AnimationLibrary = ap.get_animation_library("")
		var cache: Dictionary = def["cache"]
		if cache.is_empty():
			var skp: String = String(inst.get_path_to(sk))
			for k in _donor_anims.keys():
				cache[k] = _retarget(_donor_anims[k], _donor_skel, sk, skp)
		for k in cache.keys():
			if not lib.has_animation("my_" + String(k)):
				lib.add_animation("my_" + String(k), cache[k])
		names["idle"] = "my_idle"
		names["walk"] = "my_walk"
	elif ap != null:
		for an in ap.get_animation_list():
			var low: String = String(an).to_lower()
			if low == "walk" or low == "walking" or (low.contains("walk") and not low.contains("back") and names["walk"] == ""):
				names["walk"] = an
			elif low == "idle" or (low.contains("idle") and names["idle"] == ""):
				names["idle"] = an
		if names["walk"] == "":
			for an in ap.get_animation_list():
				if String(an).to_lower().contains("run"):
					names["walk"] = an
	for k in ["walk", "idle"]:
		if names[k] != "" and ap != null:
			ap.get_animation(names[k]).loop_mode = Animation.LOOP_LINEAR
	_style(inst, rng, role)
	# hand holder for carried goods
	var hand: Node3D = Node3D.new()
	root.add_child(hand)
	hand.position = Vector3(0.28, 0.95, 0.25)
	if sk != null:
		var bi := -1
		for i in range(sk.get_bone_count()):
			var bn: String = sk.get_bone_name(i).to_lower()
			if bn.ends_with("righthand"):
				bi = i
				break
		if bi >= 0:
			var ba := BoneAttachment3D.new()
			ba.bone_name = sk.get_bone_name(bi)
			sk.add_child(ba)
			hand = Node3D.new()
			ba.add_child(hand)
			hand.scale = Vector3.ONE / sc
	if ROLE_TXT.has(role):
		var lb := Label3D.new()
		lb.text = ROLE_TXT[role]
		lb.font_size = 40
		lb.pixel_size = 0.006
		lb.modulate = ROLE_COL[role]
		lb.outline_size = 10
		lb.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		lb.no_depth_test = true
		lb.position = Vector3(0, 2.05, 0)
		root.add_child(lb)
	root.set_meta("rig", {"model": true, "anim": ap, "names": names, "hand_r": hand, "cur": ""})
	root.set_meta("role", role)
	return root


static func _tinted(m: MeshInstance3D, s: int, col: Color) -> void:
	var base: Material = m.get_active_material(s)
	if base is StandardMaterial3D:
		var c: StandardMaterial3D = (base as StandardMaterial3D).duplicate()
		c.albedo_color = c.albedo_color * col
		c.roughness = 0.85
		c.metallic = 0.0
		c.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
		m.set_surface_override_material(s, c)


static func _style(inst: Node3D, rng: RandomNumberGenerator, role: String) -> void:
	var skin: Color = SKINS[rng.randi() % SKINS.size()]
	var shirt: Color = SHIRTS[rng.randi() % SHIRTS.size()]
	var pants: Color = PANTS[rng.randi() % PANTS.size()]
	if ROLE_COL.has(role):
		shirt = (ROLE_COL[role] as Color).darkened(0.1)
		pants = Color("1f2933")
	var generic: Color = Color.from_hsv(rng.randf(), rng.randf_range(0.0, 0.18), rng.randf_range(0.9, 1.0))
	for mi in inst.find_children("*", "MeshInstance3D", true, false):
		var m := mi as MeshInstance3D
		var mn: String = String(m.name).to_lower()
		if mn.contains("eye") or mn.contains("teeth"):
			continue
		var col: Color = generic
		if mn.contains("wolf3d"):
			if mn.contains("outfit_top"):
				col = shirt
			elif mn.contains("outfit_bottom"):
				col = pants
			elif mn.contains("footwear"):
				col = Color(0.35, 0.3, 0.28)
			elif mn.contains("headwear"):
				if rng.randf() < 0.7 or ROLE_COL.has(role):
					m.visible = false
				col = shirt
			elif mn.contains("beard"):
				if rng.randf() < 0.5:
					m.visible = false
				col = Color(0.55, 0.5, 0.45)
			else:
				col = skin
		elif ROLE_COL.has(role) and role != "guard":
			col = Color(1, 1, 1).lerp(ROLE_COL[role], 0.3)
		for s in range(m.mesh.get_surface_count()):
			_tinted(m, s, col)


static func animate(rig: Dictionary, walk: float, pose: String) -> void:
	var ap: AnimationPlayer = rig["anim"]
	if ap == null or not is_instance_valid(ap):
		return
	var names: Dictionary = rig["names"]
	var want: String = "walk" if walk > 0.5 else "idle"
	if rig["cur"] == want:
		return
	rig["cur"] = want
	var n: String = names[want]
	if n == "":
		n = names["walk"]
		if n == "":
			return
		ap.play(n, 0.25)
		ap.speed_scale = 0.0
		return
	ap.play(n, 0.25)
	ap.speed_scale = 1.0
