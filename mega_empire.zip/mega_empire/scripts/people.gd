class_name PersonModels
extends RefCounted
## Real rigged human models (GLB) with animations retargeted from one donor (Mixamo Soldier: Idle/Walk).
## Any extra *.glb in assets/models/people/ is picked up automatically:
##  - file with its own walk/idle animations  -> used as is ("native")
##  - humanoid with Mixamo-style bone names (mixamorig_Hips or Hips) and NO animations -> animations retargeted.

const DIR := "res://assets/models/people/"
const DONOR := "Soldier"
const ROLE_COL := {"cashier": Color("2ecc71"), "stock": Color("3498db"), "cleaner": Color("1abc9c"), "guard": Color("e74c3c"), "supervisor": Color("f1c40f")}
const ROLE_TXT := {"cashier": "CASHIER", "stock": "STOCK", "cleaner": "CLEANER", "guard": "GUARD", "supervisor": "MANAGER"}
const _OLD_SHIRTS := [Color("3b7dd8"), Color("d64550"), Color("2fa86a"), Color("f2efe6"), Color("8a63d2"), Color("f0a830"), Color("e86aa6"), Color("30b8c8"), Color("f5f5f5"), Color("ff7a45")]
const PANTS := [Color("232a36"), Color("3a4a6a"), Color("7a5a3a"), Color("55627a"), Color("2b2b2b"), Color("c9b896")]
const SKINS := [Color(1, 1, 1), Color(0.9, 0.78, 0.68), Color(0.78, 0.62, 0.5), Color(0.6, 0.45, 0.36)]

static var _defs: Array = []
static var _scenes: Dictionary = {}
static var _donor_skel: Skeleton3D = null
static var _donor_anims: Dictionary = {}
static var _loaded: bool = false
static var force: String = ""


static func available() -> bool:
	_init_defs()
	return not _defs.is_empty()


static func _list() -> Array:
	var out: Array = []
	var d := DirAccess.open(DIR)
	if d == null:
		return out
	for f in d.get_files():
		var fl: String = f
		var base := ""
		if fl.ends_with(".glb"):
			base = fl.get_basename()
		elif fl.ends_with(".glb.import"):
			base = fl.get_basename().get_basename()
		if base != "" and not out.has(base):
			out.append(base)
	out.sort()
	return out


static func _first(n: Node, cls: String) -> Node:
	var l: Array = n.find_children("*", cls, true, false)
	return l[0] if l.size() > 0 else null


static func _init_defs() -> void:
	if _loaded:
		return
	_loaded = true
	var files: Array = _list()
	if files.has(DONOR):
		var dn: Node = (load(DIR + DONOR + ".glb") as PackedScene).instantiate()
		var ap := _first(dn, "AnimationPlayer") as AnimationPlayer
		_donor_skel = _first(dn, "Skeleton3D") as Skeleton3D
		if ap != null:
			for an in ["Idle", "Walk"]:
				if ap.has_animation(an):
					_donor_anims[String(an).to_lower()] = ap.get_animation(an)
		_donor_scene_keep = dn
	for f in files:
		var fname: String = f
		var sc: PackedScene = load(DIR + fname + ".glb")
		if sc == null:
			continue
		_scenes[fname] = sc
		var probe: Node = sc.instantiate()
		var ap2 := _first(probe, "AnimationPlayer") as AnimationPlayer
		var has_walk := false
		if ap2 != null:
			for an in ap2.get_animation_list():
				if String(an).to_lower().contains("walk") or String(an).to_lower().contains("run"):
					has_walk = true
		var has_skel := _first(probe, "Skeleton3D") != null
		probe.free()
		var mode := ""
		if has_walk:
			mode = "native"
		elif has_skel and _donor_skel != null and fname != DONOR:
			mode = "retarget"
		if fname == DONOR:
			continue
		if mode == "":
			continue
		_defs.append({"name": fname, "mode": mode, "guard_only": fname == DONOR, "cache": {}})


static var _donor_scene_keep: Node = null


# ---------------------------------------------------------------- retargeting
static func _bone_map(src: Skeleton3D, dst: Skeleton3D) -> Dictionary:
	var m := {}
	for i in range(dst.get_bone_count()):
		var dn: String = dst.get_bone_name(i)
		var si: int = src.find_bone(dn)
		if si < 0:
			si = src.find_bone("mixamorig_" + dn)
		if si < 0 and dn.begins_with("mixamorig_"):
			si = src.find_bone(dn.substr(10))
		if si >= 0:
			m[i] = si
	return m


static func _globals_rest(sk: Skeleton3D) -> Array:
	var g: Array = []
	g.resize(sk.get_bone_count())
	for i in range(sk.get_bone_count()):
		g[i] = (sk.get_bone_global_rest(i) as Transform3D).basis.get_rotation_quaternion()
	return g


static func _short(n: String) -> String:
	if n.begins_with("mixamorig_"):
		return n.substr(10)
	if n.begins_with("mixamorig:"):
		return n.substr(10)
	return n


static func _bpos(sk: Skeleton3D, nm: String) -> Vector3:
	var i: int = sk.find_bone(nm)
	if i < 0:
		i = sk.find_bone("mixamorig_" + nm)
	if i < 0:
		i = sk.find_bone("mixamorig:" + nm)
	if i < 0:
		return Vector3.ZERO
	return (sk.get_bone_global_rest(i) as Transform3D).origin


static func _body_basis(sk: Skeleton3D) -> Basis:
	var up: Vector3 = (_bpos(sk, "Head") - _bpos(sk, "Hips")).normalized()
	var right: Vector3 = (_bpos(sk, "LeftUpLeg") - _bpos(sk, "RightUpLeg")).normalized()
	var fwd: Vector3 = right.cross(up).normalized()
	right = up.cross(fwd).normalized()
	return Basis(right, up, fwd)


static func _frame_between(src: Skeleton3D, dst: Skeleton3D) -> Quaternion:
	var bs: Basis = _body_basis(src)
	var bd: Basis = _body_basis(dst)
	return (bd * bs.inverse()).get_rotation_quaternion()


static func _retarget(src_anim: Animation, src: Skeleton3D, dst: Skeleton3D, skel_path: String) -> Animation:
	var out := Animation.new()
	out.length = src_anim.length
	out.loop_mode = Animation.LOOP_LINEAR
	var map: Dictionary = _bone_map(src, dst)
	var src_rot_track := {}
	var src_pos_track := {}
	for ti in range(src_anim.get_track_count()):
		var tp: String = String(src_anim.track_get_path(ti))
		var ci: int = tp.find(":")
		if ci < 0:
			continue
		var bi: int = src.find_bone(tp.substr(ci + 1))
		if bi < 0:
			continue
		if src_anim.track_get_type(ti) == Animation.TYPE_ROTATION_3D:
			src_rot_track[bi] = ti
		elif src_anim.track_get_type(ti) == Animation.TYPE_POSITION_3D:
			src_pos_track[bi] = ti
	var F: Quaternion = _frame_between(src, dst)
	var Fi: Quaternion = F.inverse()
	var sg_rest: Array = _globals_rest(src)
	var dg_rest: Array = _globals_rest(dst)
	var nd: int = dst.get_bone_count()
	var ns: int = src.get_bone_count()
	var dtracks: Array = []
	dtracks.resize(nd)
	for b in range(nd):
		var tr: int = out.add_track(Animation.TYPE_ROTATION_3D)
		out.track_set_path(tr, NodePath(skel_path + ":" + dst.get_bone_name(b)))
		dtracks[b] = tr
	var hips_d: int = -1
	for b in range(nd):
		if dst.get_bone_parent(b) < 0 and map.has(b):
			hips_d = b
			break
	var pos_tr := -1
	var hips_scale := 1.0
	var hips_rest_s := Vector3.ZERO
	var hips_rest_d := Vector3.ZERO
	if hips_d >= 0:
		pos_tr = out.add_track(Animation.TYPE_POSITION_3D)
		out.track_set_path(pos_tr, NodePath(skel_path + ":" + dst.get_bone_name(hips_d)))
		var hs: int = map[hips_d]
		hips_rest_s = (src.get_bone_global_rest(hs) as Transform3D).origin
		hips_rest_d = (dst.get_bone_global_rest(hips_d) as Transform3D).origin
		var hs_h: float = (F * hips_rest_s).y
		if absf(hs_h) > 0.0001:
			hips_scale = hips_rest_d.y / hs_h
	var arm_child := {}
	for side in ["Left", "Right"]:
		arm_child[side + "Arm"] = Vector2i(dst.find_bone(side + "ForeArm") if dst.find_bone(side + "ForeArm") >= 0 else dst.find_bone("mixamorig_" + side + "ForeArm"), 0)
		arm_child[side + "ForeArm"] = Vector2i(dst.find_bone(side + "Hand") if dst.find_bone(side + "Hand") >= 0 else dst.find_bone("mixamorig_" + side + "Hand"), 0)
	var step := 1.0 / 30.0
	var t := 0.0
	var n_steps: int = int(ceil(src_anim.length / step))
	for k in range(n_steps + 1):
		t = minf(float(k) * step, src_anim.length)
		var s_glob: Array = []
		s_glob.resize(ns)
		for b in range(ns):
			var q: Quaternion = src.get_bone_rest(b).basis.get_rotation_quaternion()
			if src_rot_track.has(b):
				q = src_anim.rotation_track_interpolate(src_rot_track[b], t)
			var p: int = src.get_bone_parent(b)
			s_glob[b] = (s_glob[p] as Quaternion) * q if p >= 0 else q
		# forward kinematics of source joint positions (for direction based arm retargeting)
		var s_pos: Array = []
		s_pos.resize(ns)
		for b in range(ns):
			var pb: int = src.get_bone_parent(b)
			var lo: Vector3 = src.get_bone_rest(b).origin
			s_pos[b] = (s_pos[pb] as Vector3) + (s_glob[pb] as Quaternion) * lo if pb >= 0 else lo
		var d_glob: Array = []
		d_glob.resize(nd)
		for b in range(nd):
			var p: int = dst.get_bone_parent(b)
			var gq: Quaternion
			var short: String = _short(dst.get_bone_name(b))
			if arm_child.has(short) and map.has(b) and arm_child[short].x >= 0 and map.has(arm_child[short].x):
				var cd: int = arm_child[short].x
				var sb2: int = map[b]
				var sc2: int = map[cd]
				var tdir: Vector3 = F * ((s_pos[sc2] as Vector3) - (s_pos[sb2] as Vector3))
				var rdir: Vector3 = (dst.get_bone_global_rest(cd) as Transform3D).origin - (dst.get_bone_global_rest(b) as Transform3D).origin
				if tdir.length() > 0.0001 and rdir.length() > 0.0001:
					gq = Quaternion(rdir.normalized(), tdir.normalized()) * (dg_rest[b] as Quaternion)
				else:
					gq = (d_glob[p] as Quaternion) * dst.get_bone_rest(b).basis.get_rotation_quaternion()
			elif short.contains("Hand") and short != "LeftHand" and short != "RightHand" or short == "LeftHand" or short == "RightHand":
				var rl2: Quaternion = dst.get_bone_rest(b).basis.get_rotation_quaternion()
				gq = (d_glob[p] as Quaternion) * rl2 if p >= 0 else rl2
			elif map.has(b):
				var sb: int = map[b]
				var delta: Quaternion = F * ((s_glob[sb] as Quaternion) * (sg_rest[sb] as Quaternion).inverse()) * Fi
				gq = delta * (dg_rest[b] as Quaternion)
			else:
				var rl: Quaternion = dst.get_bone_rest(b).basis.get_rotation_quaternion()
				gq = (d_glob[p] as Quaternion) * rl if p >= 0 else rl
			d_glob[b] = gq
			var lq: Quaternion = (d_glob[p] as Quaternion).inverse() * gq if p >= 0 else gq
			out.rotation_track_insert_key(dtracks[b], t, lq.normalized())
		if pos_tr >= 0:
			var hs2: int = map[hips_d]
			var sp: Vector3 = hips_rest_s
			if src_pos_track.has(hs2):
				sp = src_anim.position_track_interpolate(src_pos_track[hs2], t)
			var np: Vector3 = hips_rest_d + (F * (sp - hips_rest_s)) * hips_scale
			out.position_track_insert_key(pos_tr, t, np)
	return out


# ---------------------------------------------------------------- build
static func _def_named(n: String) -> Dictionary:
	for d in _defs:
		if d["name"] == n:
			return d
	return {}


static func _pick_def(rng: RandomNumberGenerator, role: String) -> Dictionary:
	var pool: Array = []
	for d in _defs:
		if not d["guard_only"]:
			pool.append(d)
	if pool.is_empty():
		pool = _defs
	return pool[rng.randi() % pool.size()]




static func _xf_to(n: Node3D, root: Node3D) -> Transform3D:
	var t := Transform3D.IDENTITY
	var c: Node = n
	while c != null and c != root:
		if c is Node3D:
			t = (c as Node3D).transform * t
		c = c.get_parent()
	return t


static func _height(root: Node3D, inst: Node3D) -> float:
	var top := 0.0
	for mi in inst.find_children("*", "MeshInstance3D", true, false):
		var m := mi as MeshInstance3D
		if m.mesh == null or String(m.name).to_lower().contains("headwear"):
			continue
		var bb: AABB = _xf_to(m, root) * m.mesh.get_aabb()
		top = maxf(top, bb.end.y)
	return top if top > 0.5 else 1.75


static func build(seed_value: int, role: String, look: Dictionary = {}) -> Node3D:
	_init_defs()
	var rng := RandomNumberGenerator.new()
	rng.seed = (seed_value * 2654435761 + 12345) % 4294967296
	rng.randi()
	if look.is_empty():
		look = Looks.random_look(seed_value, role)
	var def: Dictionary = _def_named("Michelle" if String(look["base"]) == "woman" else "RPM")
	if def.is_empty():
		def = _pick_def(rng, role)
	var root := Node3D.new()
	var inst: Node3D = (_scenes[def["name"]] as PackedScene).instantiate()
	var sc: float = rng.randf_range(0.98, 1.03)
	inst.scale = Vector3(sc, sc, sc)
	root.add_child(inst)
	var ap: AnimationPlayer = _first(inst, "AnimationPlayer") as AnimationPlayer
	var sk: Skeleton3D = _first(inst, "Skeleton3D") as Skeleton3D
	var names := {"idle": "", "walk": ""}
	if def["mode"] == "retarget":
		if ap == null:
			ap = AnimationPlayer.new()
			inst.add_child(ap)
			ap.root_node = NodePath("..")
			ap.add_animation_library("", AnimationLibrary.new())
		var lib: AnimationLibrary = ap.get_animation_library("")
		var cache: Dictionary = def["cache"]
		if cache.is_empty():
			var skp: String = String(inst.get_path_to(sk))
			for k in _donor_anims.keys():
				cache[k] = _retarget(_donor_anims[k], _donor_skel, sk, skp)
		for k in cache.keys():
			if not lib.has_animation("my_" + String(k)):
				lib.add_animation("my_" + String(k), cache[k])
		names["idle"] = "my_idle"
		names["walk"] = "my_walk"
	elif ap != null:
		for an in ap.get_animation_list():
			var low: String = String(an).to_lower()
			if low == "walk" or low == "walking" or (low.contains("walk") and not low.contains("back") and names["walk"] == ""):
				names["walk"] = an
			elif low == "idle" or (low.contains("idle") and names["idle"] == ""):
				names["idle"] = an
		if names["walk"] == "":
			for an in ap.get_animation_list():
				if String(an).to_lower().contains("run"):
					names["walk"] = an
	for k in ["walk", "idle"]:
		if names[k] != "" and ap != null:
			ap.get_animation(names[k]).loop_mode = Animation.LOOP_LINEAR
	var H: float = _height(root, inst)
	_dress(inst, root, look, role, H)
	var acc := Node3D.new()
	root.add_child(acc)
	var head_i := -1
	var head_rest := Transform3D(Basis.IDENTITY, Vector3(0, H * 0.87, 0))
	if sk != null:
		for i in range(sk.get_bone_count()):
			if _short(sk.get_bone_name(i)).to_lower() == "head":
				head_i = i
				break
		if head_i >= 0:
			head_rest = _xf_to(sk, root) * sk.get_bone_global_rest(head_i)
	acc.position = head_rest.origin
	_accessories(acc, look, H, String(look["base"]) == "man")
	# hand holder for carried goods
	var hand: Node3D = Node3D.new()
	root.add_child(hand)
	hand.position = Vector3(0.28, 0.95, 0.25)
	if sk != null:
		var bi := -1
		for i in range(sk.get_bone_count()):
			var bn: String = sk.get_bone_name(i).to_lower()
			if bn.ends_with("righthand"):
				bi = i
				break
		if bi >= 0:
			var ba := BoneAttachment3D.new()
			ba.bone_name = sk.get_bone_name(bi)
			sk.add_child(ba)
			hand = Node3D.new()
			ba.add_child(hand)
			hand.scale = Vector3.ONE / sc
	if ROLE_TXT.has(role):
		var lb := Label3D.new()
		lb.text = ROLE_TXT[role]
		lb.font_size = 40
		lb.pixel_size = 0.006
		lb.modulate = ROLE_COL[role]
		lb.outline_size = 10
		lb.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		lb.no_depth_test = true
		lb.position = Vector3(0, H + 0.3, 0)
		root.add_child(lb)
	root.set_meta("rig", {"model": true, "anim": ap, "names": names, "hand_r": hand, "cur": "", "acc": acc, "sk": sk, "head_i": head_i, "root": root, "rest": head_rest, "t": 0.0})
	root.set_meta("role", role)
	return root


static func _flat(m: MeshInstance3D, col: Color, rough: float = 0.75) -> void:
	for s in range(m.mesh.get_surface_count()):
		var base: Material = m.get_active_material(s)
		var c: StandardMaterial3D = (base as StandardMaterial3D).duplicate() if base is StandardMaterial3D else StandardMaterial3D.new()
		c.albedo_texture = null
		c.albedo_color = col
		c.roughness = rough
		c.metallic = 0.0
		c.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
		m.set_surface_override_material(s, c)


const RPM_SKIN_REF := Color(0.68, 0.48, 0.45)


static func _skin_tint(m: MeshInstance3D, skin: Color) -> void:
	var sl: Color = skin.srgb_to_linear()
	var rl: Color = RPM_SKIN_REF.srgb_to_linear()
	var t := Color(minf(sl.r / rl.r, 1.0), minf(sl.g / rl.g, 1.0), minf(sl.b / rl.b, 1.0)).linear_to_srgb()
	for s in range(m.mesh.get_surface_count()):
		var base: Material = m.get_active_material(s)
		if base is StandardMaterial3D:
			var c: StandardMaterial3D = (base as StandardMaterial3D).duplicate()
			c.albedo_color = t
			c.roughness = 0.7
			c.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
			m.set_surface_override_material(s, c)


static func _part_color(cat: String, look: Dictionary, role: String) -> Color:
	var idx: int = int(look[cat])
	if idx == 0:
		if cat == "pant":
			return Color("1f2933")
		if ROLE_COL.has(role):
			return (ROLE_COL[role] as Color).darkened(0.1)
		return Color("f4f4f4")
	return Looks.color(cat, idx)


static func _dress(inst: Node3D, root: Node3D, look: Dictionary, role: String, H: float) -> void:
	var skin: Color = Looks.color("skin", int(look["skin"]))
	for mi in inst.find_children("*", "MeshInstance3D", true, false):
		var m := mi as MeshInstance3D
		var mn: String = String(m.name).to_lower()
		if mn.contains("eye") or mn.contains("teeth"):
			continue
		if mn.contains("wolf3d"):
			if mn.contains("outfit_top"):
				_flat(m, _part_color("top", look, role))
			elif mn.contains("outfit_bottom"):
				_flat(m, _part_color("pant", look, role))
			elif mn.contains("footwear"):
				_flat(m, Looks.color("shoe", int(look["shoe"])), 0.55)
			elif mn.contains("headwear"):
				m.visible = false
			elif mn.contains("beard"):
				m.visible = int(look["beard"]) == 1
				_flat(m, Looks.color("hair", int(look["hair"])).lerp(Color.BLACK, 0.2))
			elif mn.contains("head"):
				_skin_tint(m, skin)
			else:
				_flat(m, skin, 0.7)


static func _mat(col: Color, rough: float = 0.6, metal: float = 0.0, glow: float = 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = rough
	m.metallic = metal
	if glow > 0.0:
		m.emission_enabled = true
		m.emission = col
		m.emission_energy_multiplier = glow
	return m


static func _part(parent: Node3D, mesh: Mesh, mat: Material, pos: Vector3, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	parent.add_child(mi)
	return mi


## Hats / glasses / short hair, positioned around the head-bone origin; sizes relative to body height H.
static func _accessories(acc: Node3D, look: Dictionary, H: float, man: bool) -> void:
	var hw: float = 0.05 * H
	var C := Vector3(0, 0.014 * H, 0.012 * H)
	var hat: int = int(look["hat"])
	if man:
		var hm := SphereMesh.new()
		hm.radius = hw * 0.98
		hm.height = hw * 1.96
		var hr := _part(acc, hm, _mat(Looks.color("hair", int(look["hair"])), 0.8), C + Vector3(0, hw * 0.3 + 0.05 * H, -hw * 0.2))
		hr.scale = Vector3(0.96, 0.84, 1.08)
	if hat > 0:
		var col: Color = Looks.color("hat", hat)
		var nm: String = Looks.item_name("hat", hat)
		var top: Vector3 = C + Vector3(0, hw * 0.55 + 0.05 * H, -hw * 0.1)
		if nm.contains("Cap"):
			var dome := SphereMesh.new()
			dome.radius = hw * 1.12
			dome.height = hw * 1.8
			dome.is_hemisphere = true
			_part(acc, dome, _mat(col, 0.7), top)
			var br := BoxMesh.new()
			br.size = Vector3(hw * 1.7, hw * 0.1, hw * 1.2)
			_part(acc, br, _mat(col, 0.7), top + Vector3(0, hw * 0.05, hw * 1.25))
		elif nm.contains("Beanie"):
			var dome2 := SphereMesh.new()
			dome2.radius = hw * 1.1
			dome2.height = hw * 2.0
			dome2.is_hemisphere = true
			_part(acc, dome2, _mat(col, 0.95), top + Vector3(0, -hw * 0.05, 0))
			var band := CylinderMesh.new()
			band.top_radius = hw * 1.12
			band.bottom_radius = hw * 1.12
			band.height = hw * 0.3
			_part(acc, band, _mat(col.darkened(0.2), 0.95), top + Vector3(0, hw * 0.05, 0))
		elif nm.contains("Fedora"):
			var cr := CylinderMesh.new()
			cr.top_radius = hw * 0.95
			cr.bottom_radius = hw * 1.05
			cr.height = hw * 0.9
			_part(acc, cr, _mat(col, 0.8), top + Vector3(0, hw * 0.4, 0))
			var bm := CylinderMesh.new()
			bm.top_radius = hw * 1.9
			bm.bottom_radius = hw * 1.9
			bm.height = hw * 0.08
			_part(acc, bm, _mat(col, 0.8), top + Vector3(0, hw * 0.0, 0))
			var bd := CylinderMesh.new()
			bd.top_radius = hw * 1.06
			bd.bottom_radius = hw * 1.08
			bd.height = hw * 0.22
			_part(acc, bd, _mat(Color("2a2a2a"), 0.6), top + Vector3(0, hw * 0.12, 0))
		else:
			var cw := CylinderMesh.new()
			cw.top_radius = hw * 1.25
			cw.bottom_radius = hw * 1.0
			cw.height = hw * 0.8
			_part(acc, cw, _mat(col, 0.25, 0.9), top + Vector3(0, hw * 0.35, 0))
			for k in range(5):
				var a: float = float(k) / 5.0 * TAU
				var sp := CylinderMesh.new()
				sp.top_radius = 0.0
				sp.bottom_radius = hw * 0.2
				sp.height = hw * 0.6
				_part(acc, sp, _mat(col, 0.25, 0.9), top + Vector3(cos(a) * hw * 1.1, hw * 1.0, sin(a) * hw * 1.1))
	var gl: int = int(look["glass"])
	if gl > 0:
		var nm2: String = Looks.item_name("glass", gl)
		var gcol: Color = Looks.color("glass", gl)
		var eye_y: float = C.y + hw * 0.12 + 0.03 * H
		var fz: float = hw * 1.0
		var lens_col: Color = Color("0b0b0d")
		var frame_col: Color = Color("0b0b0d")
		var alpha: float = 1.0
		var glow: float = 0.0
		if nm2.contains("Aviator"):
			frame_col = gcol
			lens_col = Color("2a2418")
		elif nm2.contains("Clear"):
			frame_col = gcol
			lens_col = Color(0.8, 0.9, 1.0)
			alpha = 0.25
		elif nm2.contains("Visor"):
			frame_col = Color("111111")
			lens_col = gcol
			glow = 1.4
		var lm: StandardMaterial3D = _mat(lens_col, 0.15, 0.2, glow)
		if alpha < 1.0:
			lm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			lm.albedo_color.a = alpha
		var fm: StandardMaterial3D = _mat(frame_col, 0.3, 0.6)
		if nm2.contains("Visor"):
			var vb := BoxMesh.new()
			vb.size = Vector3(hw * 2.0, hw * 0.55, hw * 0.12)
			_part(acc, vb, lm, Vector3(0, eye_y, fz))
		else:
			for sx in [-1.0, 1.0]:
				var lb := BoxMesh.new()
				lb.size = Vector3(hw * 0.78, hw * 0.52, hw * 0.1)
				_part(acc, lb, lm, Vector3(sx * hw * 0.5, eye_y, fz))
				var tb := BoxMesh.new()
				tb.size = Vector3(hw * 0.07, hw * 0.07, hw * 1.0)
				_part(acc, tb, fm, Vector3(sx * hw * 0.98, eye_y + hw * 0.1, fz - hw * 0.5))
			var bb := BoxMesh.new()
			bb.size = Vector3(hw * 0.25, hw * 0.07, hw * 0.1)
			_part(acc, bb, fm, Vector3(0, eye_y + hw * 0.1, fz))


static func animate(rig: Dictionary, walk: float, pose: String) -> void:
	var sk = rig.get("sk")
	var hi: int = int(rig.get("head_i", -1))
	if sk != null and is_instance_valid(sk) and hi >= 0:
		var acc: Node3D = rig["acc"]
		var root: Node3D = rig["root"]
		if is_instance_valid(acc) and is_instance_valid(root):
			var cur: Transform3D = _xf_to(sk, root) * (sk as Skeleton3D).get_bone_global_pose(hi)
			var d: Transform3D = cur * (rig["rest"] as Transform3D).affine_inverse()
			d.basis = d.basis.orthonormalized()
			acc.transform = d * Transform3D(Basis.IDENTITY, (rig["rest"] as Transform3D).origin)
	var ap: AnimationPlayer = rig["anim"]
	if ap == null or not is_instance_valid(ap):
		return
	var names: Dictionary = rig["names"]
	var want: String = "walk" if walk > 0.5 else "idle"
	if rig["cur"] == want:
		return
	rig["cur"] = want
	var n: String = names[want]
	if n == "":
		n = names["walk"]
		if n == "":
			return
		ap.play(n, 0.25)
		ap.speed_scale = 0.0
		return
	ap.play(n, 0.25)
	ap.speed_scale = 1.0
