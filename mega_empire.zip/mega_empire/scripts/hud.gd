class_name Hud
extends CanvasLayer
## All UI: top bar, side buttons, management panels (shop, staff, upgrades, missions, stats, settings), toasts.

signal camera_cycle
signal pause_toggled(paused: bool)
signal speed_changed
signal quit_to_menu
signal buy_manual_scan(lane: int)

const C_BG := Color(0.07, 0.09, 0.15, 0.96)
const C_CARD := Color(0.12, 0.15, 0.24, 1.0)
const C_ACCENT := Color("2ec4b6")
const C_GOLD := Color("ffc857")
const C_RED := Color("e63946")
const C_BLUE := Color("3a86ff")
const C_MUTED := Color(0.62, 0.68, 0.8)

var root: Control
var money_label: Label
var day_label: Label
var time_bar: ProgressBar
var info_label: Label
var stars: Control
var speed_btn: Button
var panel: PanelContainer
var panel_title: Label
var scroll: ScrollContainer
var body: VBoxContainer
var toast_box: VBoxContainer
var panel_kind: String = ""
var panel_arg: int = -1
var _touching: bool = false
var _refresh_t: float = 0.0
var _theme: Theme
var _shown_money: float = 0.0
var _side: VBoxContainer
var _top: HBoxContainer
var customers_inside: int = 0
var paused: bool = false


# ============================================================ small UI helpers
class StarRating:
	extends Control
	var value: float = 4.0

	func _init() -> void:
		custom_minimum_size = Vector2(150, 30)

	func _draw() -> void:
		for i in range(5):
			var c := Vector2(15.0 + float(i) * 29.0, 15.0)
			var fill: float = clampf(value - float(i), 0.0, 1.0)
			var col: Color = Color(0.3, 0.33, 0.42).lerp(Color("ffc857"), fill)
			var pts := PackedVector2Array()
			for k in range(10):
				var r: float = 13.0 if k % 2 == 0 else 5.8
				var a: float = -PI / 2.0 + float(k) * PI / 5.0
				pts.append(c + Vector2(cos(a), sin(a)) * r)
			draw_colored_polygon(pts, col)


class BarChart:
	extends Control
	var values: Array = []

	func _init() -> void:
		custom_minimum_size = Vector2(0, 220)

	func _draw() -> void:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.08, 0.1, 0.17), true)
		if values.is_empty():
			draw_string(ThemeDB.fallback_font, Vector2(16, size.y / 2.0), "Play a full day to see profit history", HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color(0.6, 0.65, 0.75))
			return
		var mx: float = 1.0
		var mn: float = 0.0
		for v in values:
			mx = maxf(mx, float(v))
			mn = minf(mn, float(v))
		var rng: float = maxf(mx - mn, 1.0)
		var zero_y: float = size.y - 28.0 - (0.0 - mn) / rng * (size.y - 56.0)
		var bw: float = (size.x - 20.0) / float(maxi(values.size(), 1))
		for i in range(values.size()):
			var v: float = float(values[i])
			var h: float = absf(v) / rng * (size.y - 56.0)
			var x: float = 10.0 + float(i) * bw
			var col: Color = Color("2ec4b6") if v >= 0.0 else Color("e63946")
			if v >= 0.0:
				draw_rect(Rect2(x + 3.0, zero_y - h, bw - 6.0, maxf(h, 2.0)), col, true)
			else:
				draw_rect(Rect2(x + 3.0, zero_y, bw - 6.0, maxf(h, 2.0)), col, true)
		draw_line(Vector2(6, zero_y), Vector2(size.x - 6, zero_y), Color(0.5, 0.55, 0.65), 1.0)


func _style(color: Color, radius: int = 14, border: Color = Color(0, 0, 0, 0), bw: int = 0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = color
	s.set_corner_radius_all(radius)
	s.border_color = border
	s.set_border_width_all(bw)
	s.content_margin_left = 14
	s.content_margin_right = 14
	s.content_margin_top = 8
	s.content_margin_bottom = 8
	return s


func _btn(text: String, cb: Callable, color: Color = C_BLUE, min_h: float = 56.0, font: int = 22) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, min_h)
	b.add_theme_font_size_override("font_size", font)
	b.add_theme_stylebox_override("normal", _style(color))
	b.add_theme_stylebox_override("hover", _style(color.lightened(0.1)))
	b.add_theme_stylebox_override("pressed", _style(color.darkened(0.2)))
	b.add_theme_stylebox_override("disabled", _style(Color(0.2, 0.22, 0.3)))
	b.add_theme_color_override("font_disabled_color", Color(0.5, 0.54, 0.62))
	b.pressed.connect(func() -> void:
		Sfx.play("click")
		cb.call())
	return b


func _lbl(text: String, size: int = 22, color: Color = Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


func _icon_btn(icon_name: String, cb: Callable, size: float = 76.0) -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(size, size)
	b.icon = Art.tex(icon_name)
	b.expand_icon = true
	b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	b.add_theme_constant_override("icon_max_width", int(size * 0.62))
	b.add_theme_stylebox_override("normal", _style(Color(0.08, 0.1, 0.18, 0.82), 18, Color(1, 1, 1, 0.18), 2))
	b.add_theme_stylebox_override("hover", _style(Color(0.14, 0.17, 0.28, 0.9), 18, Color(1, 1, 1, 0.3), 2))
	b.add_theme_stylebox_override("pressed", _style(Color(0.05, 0.07, 0.12, 0.95), 18, C_ACCENT, 2))
	b.pressed.connect(func() -> void:
		Sfx.play("click")
		cb.call())
	return b


func _card(inner: Control, color: Color = C_CARD) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", _style(color, 16))
	p.add_child(inner)
	return p


# ============================================================ build
func _ready() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	_theme = Theme.new()
	_theme.default_font_size = 22
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = _theme
	add_child(root)
	_build_top()
	_build_side()
	_build_panel()
	toast_box = VBoxContainer.new()
	toast_box.set_anchors_preset(Control.PRESET_CENTER_TOP)
	toast_box.position = Vector2(-320, 110)
	toast_box.custom_minimum_size = Vector2(640, 0)
	toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(toast_box)
	Game.toast.connect(show_toast)
	Game.money_changed.connect(func(_v: float) -> void: pass)
	Game.day_ended.connect(_on_day_ended)
	Game.changed.connect(func() -> void: _refresh_t = minf(_refresh_t, 1.2))
	visible = false


func _build_top() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_TOP_WIDE)
	margin.add_theme_constant_override("margin_left", 16)
	margin.add_theme_constant_override("margin_right", 16)
	margin.add_theme_constant_override("margin_top", 10)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(margin)
	_top = HBoxContainer.new()
	_top.add_theme_constant_override("separation", 12)
	_top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_child(_top)
	# money
	var mrow := HBoxContainer.new()
	mrow.add_theme_constant_override("separation", 8)
	var coin := TextureRect.new()
	coin.texture = Art.tex("ui_coin")
	coin.custom_minimum_size = Vector2(40, 40)
	coin.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	coin.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	mrow.add_child(coin)
	money_label = _lbl("$0", 32, C_GOLD)
	mrow.add_child(money_label)
	_top.add_child(_card(mrow, Color(0.05, 0.07, 0.13, 0.85)))
	# day box
	var dv := VBoxContainer.new()
	dv.custom_minimum_size = Vector2(230, 0)
	day_label = _lbl("Day 1  08:00", 22)
	dv.add_child(day_label)
	time_bar = ProgressBar.new()
	time_bar.show_percentage = false
	time_bar.custom_minimum_size = Vector2(0, 14)
	time_bar.max_value = 1.0
	dv.add_child(time_bar)
	_top.add_child(_card(dv, Color(0.05, 0.07, 0.13, 0.85)))
	# rating + customers
	var rv := VBoxContainer.new()
	stars = StarRating.new()
	rv.add_child(stars)
	info_label = _lbl("Customers 0/0", 20, C_MUTED)
	rv.add_child(info_label)
	_top.add_child(_card(rv, Color(0.05, 0.07, 0.13, 0.85)))
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_top.add_child(spacer)
	speed_btn = _btn("x1", _on_speed, Color(0.1, 0.13, 0.22, 0.9), 64, 24)
	speed_btn.custom_minimum_size = Vector2(80, 64)
	_top.add_child(speed_btn)
	_top.add_child(_icon_btn("ui_pause", _on_pause_btn, 64))


func _build_side() -> void:
	_side = VBoxContainer.new()
	_side.set_anchors_preset(Control.PRESET_CENTER_RIGHT)
	_side.position = Vector2(-96, -250)
	_side.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	_side.add_theme_constant_override("separation", 10)
	_side.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(_side)
	_side.add_child(_icon_btn("ui_shop", func() -> void: open_panel("shop")))
	_side.add_child(_icon_btn("ui_staff", func() -> void: open_panel("staff")))
	_side.add_child(_icon_btn("ui_upgrade", func() -> void: open_panel("upgrades")))
	_side.add_child(_icon_btn("ui_missions", func() -> void: open_panel("missions")))
	_side.add_child(_icon_btn("ui_stats", func() -> void: open_panel("stats")))
	_side.add_child(_icon_btn("ui_camera", func() -> void: camera_cycle.emit()))


func _build_panel() -> void:
	panel = PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_FULL_RECT)
	panel.anchor_left = 0.08
	panel.anchor_right = 0.92
	panel.anchor_top = 0.1
	panel.anchor_bottom = 0.97
	panel.offset_left = 0
	panel.offset_right = 0
	panel.offset_top = 0
	panel.offset_bottom = 0
	panel.add_theme_stylebox_override("panel", _style(C_BG, 22, Color(1, 1, 1, 0.14), 2))
	panel.visible = false
	root.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	panel.add_child(v)
	var head := HBoxContainer.new()
	panel_title = _lbl("", 30, C_GOLD)
	panel_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(panel_title)
	head.add_child(_icon_btn("ui_close", close_panel, 60))
	v.add_child(head)
	scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(scroll)
	body = VBoxContainer.new()
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 10)
	scroll.add_child(body)


# ============================================================ per-frame
func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		_touching = (event as InputEventScreenTouch).pressed
	elif event is InputEventMouseButton:
		_touching = (event as InputEventMouseButton).pressed


func _process(delta: float) -> void:
	if not visible:
		return
	_shown_money = lerpf(_shown_money, Game.money, clampf(delta * 8.0, 0.0, 1.0))
	if absf(_shown_money - Game.money) < 0.5:
		_shown_money = Game.money
	money_label.text = _money(_shown_money)
	money_label.add_theme_color_override("font_color", C_GOLD if Game.money >= 0.0 else C_RED)
	var p: float = Game.day_time / Game.DAY_LENGTH
	time_bar.value = p
	var mins: int = int(8.0 * 60.0 + p * 12.0 * 60.0)
	day_label.text = "Day %d   %02d:%02d%s" % [Game.day, (mins / 60) % 24, mins % 60, "" if Game.is_open() else "  CLOSING"]
	(stars as StarRating).value = Game.rating
	stars.queue_redraw()
	info_label.text = "Customers %d/%d   Rating %.1f" % [customers_inside, Game.max_customers_inside(), Game.rating]
	speed_btn.text = "x%d" % int(Game.settings.get("speed", 1))
	if panel.visible:
		_refresh_t += delta
		if _refresh_t > 1.5 and not _touching and panel_kind not in ["settings", "pause"]:
			_refresh_t = 0.0
			_rebuild()


func _money(v: float) -> String:
	var neg: bool = v < 0.0
	var a: float = absf(v)
	var s: String
	if a >= 1000000.0:
		s = "%.2fM" % (a / 1000000.0)
	elif a >= 10000.0:
		s = "%.1fK" % (a / 1000.0)
	else:
		s = _commas(int(a))
	return ("-$" if neg else "$") + s


func _commas(n: int) -> String:
	var s: String = str(n)
	var out := ""
	var cnt := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		cnt += 1
		if cnt % 3 == 0 and i > 0:
			out = "," + out
	return out


func show_toast(msg: String) -> void:
	var l := _lbl(msg, 24)
	l.add_theme_stylebox_override("normal", _style(Color(0.05, 0.07, 0.13, 0.92), 14, C_ACCENT, 2))
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.custom_minimum_size = Vector2(600, 0)
	toast_box.add_child(l)
	var tw := create_tween()
	tw.tween_interval(2.6)
	tw.tween_property(l, "modulate:a", 0.0, 0.5)
	tw.tween_callback(l.queue_free)
	while toast_box.get_child_count() > 3:
		toast_box.get_child(0).queue_free()
		break


func _on_speed() -> void:
	var s: int = int(Game.settings.get("speed", 1))
	s = 1 if s >= 3 else s + 1
	Game.set_setting("speed", s)
	speed_changed.emit()


func _on_pause_btn() -> void:
	open_panel("pause")
	pause_toggled.emit(true)


# ============================================================ panels
func open_panel(kind: String, arg: int = -1) -> void:
	panel_kind = kind
	panel_arg = arg
	scroll.scroll_vertical = 0
	panel.visible = true
	_refresh_t = 0.0
	_rebuild()


func close_panel() -> void:
	if panel_kind == "pause":
		pause_toggled.emit(false)
	panel.visible = false
	panel_kind = ""


func is_panel_open() -> bool:
	return panel.visible


func _clear_body() -> void:
	for c in body.get_children():
		body.remove_child(c)
		c.queue_free()


func _rebuild() -> void:
	if not panel.visible:
		return
	var keep: int = scroll.scroll_vertical
	_clear_body()
	match panel_kind:
		"shop":
			_build_shop()
		"staff":
			_build_staff()
		"upgrades":
			_build_upgrades()
		"missions":
			_build_missions()
		"stats":
			_build_stats()
		"settings":
			_build_settings(false)
		"pause":
			_build_settings(true)
		"shelf":
			_build_shelf(panel_arg)
		"checkout":
			_build_checkout(panel_arg)
		"warehouse":
			_build_warehouse()
	scroll.set_deferred("scroll_vertical", keep)


func _row(children: Array, color: Color = C_CARD) -> PanelContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 12)
	for c in children:
		h.add_child(c)
	return _card(h, color)


func _spacer_h() -> Control:
	var s := Control.new()
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return s


func _icon_rect(tex_name: String, size: float = 56.0) -> TextureRect:
	var t := TextureRect.new()
	t.texture = Art.tex(tex_name)
	t.custom_minimum_size = Vector2(size, size)
	t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	return t


func _info_box(title: String, sub: String, sub_color: Color = C_MUTED) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_child(_lbl(title, 24))
	var s := _lbl(sub, 18, sub_color)
	s.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(s)
	return v


func _shelf_total(pid: String) -> int:
	var n := 0
	for i in range(Game.MAX_SHELVES):
		if Game.shelf_unlocked(i) and Game.shelf_product[i] == pid:
			n += int(Game.shelf_stock[i])
	return n


# ---------------------------------------------------------------- shop
func _build_shop() -> void:
	panel_title.text = "Products & Stock"
	body.add_child(_lbl("Warehouse: %d / %d    Shelf capacity: %d each" % [Game.warehouse_used(), Game.warehouse_capacity(), Game.shelf_capacity()], 22, C_MUTED))
	body.add_child(_lbl("Order stock into the warehouse. Staff (or you, by tapping a shelf) move it onto shelves.", 18, C_MUTED))
	for p in Data.PRODUCTS:
		var pid: String = p["id"]
		var mult: float = float(Game.price_mult[pid])
		var margin: float = (Game.sell_price(pid) - float(p["buy"])) / maxf(Game.sell_price(pid), 0.01) * 100.0
		var info := _info_box("%s  (%s)" % [p["name"], p["cat"]], "Cost $%.2f   Price $%.2f (x%.2f)   Margin %d%%\nWarehouse %d   On shelves %d" % [float(p["buy"]), Game.sell_price(pid), mult, int(margin), int(Game.warehouse.get(pid, 0)), _shelf_total(pid)])
		var pm := HBoxContainer.new()
		pm.add_child(_btn("-", func() -> void:
			Game.set_price_mult(pid, float(Game.price_mult[pid]) - 0.05)
			_rebuild(), C_RED, 56, 26))
		pm.add_child(_btn("+", func() -> void:
			Game.set_price_mult(pid, float(Game.price_mult[pid]) + 0.05)
			_rebuild(), C_ACCENT, 56, 26))
		var ob := VBoxContainer.new()
		ob.add_child(_btn("Order 10  $%.0f" % (float(p["buy"]) * 10.0), func() -> void:
			Game.order_stock(pid, 10)
			_rebuild(), C_BLUE, 52, 20))
		ob.add_child(_btn("Order 50  $%.0f" % (float(p["buy"]) * 50.0), func() -> void:
			Game.order_stock(pid, 50)
			_rebuild(), Color("5a54d6"), 52, 20))
		body.add_child(_row([_icon_rect("prod_" + pid, 64), info, pm, ob]))


# ---------------------------------------------------------------- shelf popup
func _build_shelf(idx: int) -> void:
	var pid: String = Game.shelf_product[idx]
	panel_title.text = "Shelf #%d" % (idx + 1)
	if pid != "":
		var p: Dictionary = Data.product_by_id(pid)
		var stock: int = int(Game.shelf_stock[idx])
		var cap: int = Game.shelf_capacity()
		body.add_child(_row([_icon_rect("prod_" + pid, 72), _info_box(p["name"], "On shelf %d / %d\nWarehouse %d\nPrice $%.2f (x%.2f)" % [stock, cap, int(Game.warehouse.get(pid, 0)), Game.sell_price(pid), float(Game.price_mult[pid])])]))
		var br := HBoxContainer.new()
		br.add_theme_constant_override("separation", 10)
		var b1 := _btn("Restock +10", func() -> void:
			Game.move_to_shelf(idx, 10)
			Sfx.play("pick")
			_rebuild(), C_BLUE)
		b1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var b2 := _btn("Fill shelf", func() -> void:
			Game.move_to_shelf(idx, 9999)
			Sfx.play("pick")
			_rebuild(), C_ACCENT)
		b2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		br.add_child(b1)
		br.add_child(b2)
		body.add_child(br)
		var pr := HBoxContainer.new()
		pr.add_theme_constant_override("separation", 10)
		var pm := _btn("Price -5%", func() -> void:
			Game.set_price_mult(pid, float(Game.price_mult[pid]) - 0.05)
			_rebuild(), C_RED)
		pm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var pp := _btn("Price +5%", func() -> void:
			Game.set_price_mult(pid, float(Game.price_mult[pid]) + 0.05)
			_rebuild(), C_ACCENT)
		pp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		pr.add_child(pm)
		pr.add_child(pp)
		body.add_child(pr)
	else:
		body.add_child(_lbl("This shelf is empty. Pick a product to sell here:", 22, C_MUTED))
	body.add_child(_lbl("Change product (stock goes back to the warehouse):", 20, C_GOLD))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for p in Data.PRODUCTS:
		var q: String = p["id"]
		var b := _btn("%s  (wh %d)" % [p["name"], int(Game.warehouse.get(q, 0))], func() -> void:
			Game.assign_shelf(idx, q)
			_rebuild(), Color("2b3350") if q != pid else Color("1f6f66"), 54, 20)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		grid.add_child(b)
	body.add_child(grid)


# ---------------------------------------------------------------- checkout popup
func _build_checkout(lane: int) -> void:
	panel_title.text = "Checkout Lane %d" % (lane + 1)
	body.add_child(_lbl("Cashiers scan items automatically. You can tap the counter in the 3D view (or the button below) to scan faster!", 20, C_MUTED))
	var hired: int = Game.employee_count("cashier")
	body.add_child(_lbl("Cashiers hired: %d / %d" % [hired, Game.max_hire("cashier")], 24))
	body.add_child(_btn("Hire cashier  $%d" % int(Data.EMP_TYPES["cashier"]["hire"]), func() -> void:
		Game.hire("cashier")
		_rebuild(), C_ACCENT))
	body.add_child(_btn("SCAN ITEM (manual)", func() -> void:
		buy_manual_scan.emit(lane), C_GOLD, 80, 28))


# ---------------------------------------------------------------- warehouse popup
func _build_warehouse() -> void:
	panel_title.text = "Warehouse"
	body.add_child(_lbl("Storage: %d / %d units" % [Game.warehouse_used(), Game.warehouse_capacity()], 26))
	body.add_child(_btn("Order products", func() -> void: open_panel("shop"), C_BLUE))
	body.add_child(_btn("Upgrade warehouse size", func() -> void: open_panel("upgrades"), Color("5a54d6")))
	for p in Data.PRODUCTS:
		var n: int = int(Game.warehouse.get(p["id"], 0))
		if n > 0:
			body.add_child(_row([_icon_rect("prod_" + p["id"], 48), _lbl("%s" % p["name"], 22), _spacer_h(), _lbl("x%d" % n, 24, C_GOLD)]))


# ---------------------------------------------------------------- staff
func _build_staff() -> void:
	panel_title.text = "Employees"
	body.add_child(_lbl("Daily salaries: $%d   (paid at the end of each day)" % int(Game.salaries_per_day()), 22, C_MUTED))
	for tkey in Data.EMP_ORDER:
		var def: Dictionary = Data.EMP_TYPES[tkey]
		var count: int = Game.employee_count(tkey)
		var mx: int = Game.max_hire(tkey)
		var hire_b := _btn("Hire $%d" % int(def["hire"]), func() -> void:
			Game.hire(tkey)
			_rebuild(), C_ACCENT, 60, 22)
		hire_b.disabled = count >= mx or Game.money < float(def["hire"])
		body.add_child(_row([_info_box("%s  (%d/%d)" % [def["name"], count, mx], "%s  Salary $%d/day" % [def["desc"], int(def["salary"])]), hire_b], Color("1a2038")))
		for e in Game.emp_of_type(tkey):
			var id: int = int(e["id"])
			var lvl: int = int(e["level"])
			var tb := _btn("Train $%d" % int(Game.train_cost(e)) if lvl < 5 else "MAX", func() -> void:
				Game.train(id)
				_rebuild(), C_BLUE, 52, 20)
			tb.disabled = lvl >= 5
			var fb := _btn("Fire", func() -> void:
				Game.fire(id)
				_rebuild(), C_RED, 52, 20)
			body.add_child(_row([_info_box("%s   Lv %d" % [e["name"], lvl], "Salary $%d/day   Tasks done: %d" % [int(Game.emp_salary(e)), int(e["tasks"])], Color("9fb3ff")), tb, fb]))


# ---------------------------------------------------------------- upgrades
func _build_upgrades() -> void:
	panel_title.text = "Upgrades & Expansion"
	body.add_child(_lbl("Rent $%d   Maintenance $%d   Ads $%d  per day" % [int(Game.rent_per_day()), int(Game.maintenance_per_day()), int(Game.ads_per_day())], 20, C_MUTED))
	for u in Data.UPGRADES:
		var id: String = u["id"]
		var lvl: int = int(Game.upgrades[id])
		var maxed: bool = Game.upgrade_maxed(id)
		var sub: String = String(u["desc"])
		match id:
			"shelves":
				sub += "\nOwned: %d / %d" % [lvl, Game.MAX_SHELVES]
			"warehouse":
				sub += "\nCapacity now: %d" % Game.warehouse_capacity()
			"shelf_cap":
				sub += "\nShelf capacity now: %d" % Game.shelf_capacity()
			"ads":
				sub += "\nLevel %d  (cost/day $%d)" % [lvl, int(Game.ads_per_day())]
			_:
				sub += "\nLevel %d / %d" % [lvl, Game.upgrade_max(id)]
		var cost: float = Game.upgrade_cost(id)
		var b := _btn("MAX" if maxed else "$%s" % _commas(int(cost)), func() -> void:
			Game.buy_upgrade(id)
			_rebuild(), C_ACCENT if not maxed else Color("444b66"), 64, 24)
		b.disabled = maxed or Game.money < cost
		b.custom_minimum_size = Vector2(150, 64)
		body.add_child(_row([_info_box(String(u["name"]), sub), b]))


# ---------------------------------------------------------------- missions
func _build_missions() -> void:
	panel_title.text = "Missions"
	for m in Game.missions():
		var done: bool = Game.done_missions.has(m["id"])
		var cur: int = mini(int(m["cur"]), int(m["goal"]))
		var bar := ProgressBar.new()
		bar.max_value = float(m["goal"])
		bar.value = float(cur)
		bar.show_percentage = false
		bar.custom_minimum_size = Vector2(0, 14)
		var v := VBoxContainer.new()
		v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		v.add_child(_lbl(String(m["text"]), 22, Color("7CFFB2") if done else Color.WHITE))
		v.add_child(bar)
		v.add_child(_lbl("%d / %d" % [cur, int(m["goal"])], 18, C_MUTED))
		var r := _lbl("DONE" if done else "+$%d" % int(m["reward"]), 26, C_GOLD if not done else Color("7CFFB2"))
		body.add_child(_row([v, r]))


# ---------------------------------------------------------------- stats
func _build_stats() -> void:
	panel_title.text = "Business Statistics"
	var exp_today: float = Game.rent_per_day() + Game.salaries_per_day() + Game.maintenance_per_day() + Game.ads_per_day()
	var lines: Array = [
		["Today revenue", "$%.2f" % float(Game.today["revenue"])],
		["Today cost of goods", "$%.2f" % float(Game.today["cogs"])],
		["Daily fixed expenses", "$%.2f" % exp_today],
		["Customers today", "%d" % int(Game.today["customers"])],
		["Items sold today", "%d" % int(Game.today["items"])],
		["Lost sales today", "%d" % int(Game.today["lost"])],
		["Theft today", "$%.2f" % float(Game.today["theft"])],
		["Total revenue", "$%s" % _commas(int(Game.total_revenue))],
		["Total customers", "%d" % Game.total_customers],
		["Total items sold", "%d" % int(Game.stats["items_sold"])],
		["Rating", "%.2f / 5" % Game.rating],
		["Cleanliness", "%d%%" % int(Game.cleanliness * 100.0)],
		["Avg. net / second", "$%.2f" % Game.avg_net_per_sec],
		["Shelf stock", "%d units" % Game.total_shelf_stock()],
	]
	for l in lines:
		body.add_child(_row([_lbl(l[0], 22, C_MUTED), _spacer_h(), _lbl(l[1], 24)]))
	body.add_child(_lbl("Profit per day (last %d days)" % Game.history.size(), 22, C_GOLD))
	var chart := BarChart.new()
	var vals: Array = []
	for h in Game.history:
		vals.append(float(h["profit"]))
	chart.values = vals
	body.add_child(chart)


# ---------------------------------------------------------------- settings / pause
func _build_settings(is_pause: bool) -> void:
	panel_title.text = "Paused" if is_pause else "Settings"
	if is_pause:
		body.add_child(_btn("Resume", close_panel, C_ACCENT, 70, 28))
		body.add_child(_btn("Save game", func() -> void:
			Game.save_game()
			show_toast("Game saved"), C_BLUE))
	body.add_child(_lbl("Graphics quality", 24, C_GOLD))
	var qh := HBoxContainer.new()
	qh.add_theme_constant_override("separation", 8)
	var names: Array = ["Low", "Medium", "High", "Ultra"]
	for i in range(4):
		var cur: bool = int(Game.settings["quality"]) == i
		var b := _btn(names[i], func() -> void:
			Game.set_setting("quality", i)
			_rebuild(), C_ACCENT if cur else Color("2b3350"), 60, 22)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		qh.add_child(b)
	body.add_child(qh)
	body.add_child(_lbl("Low = best battery/performance for older phones. Ultra = shadows + anti-aliasing.", 18, C_MUTED))
	for key in ["music", "sfx", "ambient"]:
		var title: String = {"music": "Music volume", "sfx": "Effects volume", "ambient": "Ambient sounds"}[key]
		body.add_child(_lbl(title, 22))
		var sl := HSlider.new()
		sl.min_value = 0.0
		sl.max_value = 1.0
		sl.step = 0.05
		sl.value = float(Game.settings[key])
		sl.custom_minimum_size = Vector2(0, 44)
		sl.value_changed.connect(func(v: float) -> void: Game.set_setting(key, v))
		body.add_child(sl)
	if is_pause:
		body.add_child(_btn("Quit to main menu", func() -> void:
			close_panel()
			quit_to_menu.emit(), C_RED, 64, 24))


# ============================================================ day report
func _on_day_ended(rep: Dictionary) -> void:
	panel_kind = "report"
	panel_title.text = "Day %d Report" % int(rep["day"])
	panel.visible = true
	_clear_body()
	var rows: Array = [
		["Revenue", "$%.2f" % float(rep["revenue"]), Color("7CFFB2")],
		["Cost of goods sold", "-$%.2f" % float(rep["cogs"]), C_RED],
		["Rent", "-$%.2f" % float(rep["rent"]), C_RED],
		["Salaries", "-$%.2f" % float(rep["salaries"]), C_RED],
		["Maintenance", "-$%.2f" % float(rep["maintenance"]), C_RED],
		["Advertising", "-$%.2f" % float(rep["ads"]), C_RED],
		["Theft losses (not paid)", "$%.2f" % float(rep["theft"]), C_MUTED],
		["Customers served", "%d" % int(rep["customers"]), Color.WHITE],
		["Lost sales", "%d" % int(rep["lost"]), Color.WHITE],
		["Rating", "%.2f" % float(rep["rating"]), C_GOLD],
	]
	for r in rows:
		body.add_child(_row([_lbl(r[0], 22, C_MUTED), _spacer_h(), _lbl(r[1], 24, r[2])]))
	var profit: float = float(rep["profit"])
	body.add_child(_row([_lbl("PROFIT", 30, C_GOLD), _spacer_h(), _lbl(("+" if profit >= 0 else "-") + "$%.2f" % absf(profit), 32, Color("7CFFB2") if profit >= 0 else C_RED)], Color("1a2038")))
	body.add_child(_btn("Continue", close_panel, C_ACCENT, 70, 28))
	Sfx.play("upgrade")
