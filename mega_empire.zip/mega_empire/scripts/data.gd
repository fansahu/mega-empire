class_name Data
extends RefCounted
## Static game data: products, categories, employee types, upgrades, missions.

static var PRODUCTS: Array = [
	{"id": "milk", "name": "Fresh Milk", "cat": "Dairy", "buy": 2.75, "sell": 4.75, "demand": 0.95, "quality": 4, "shape": "bottle", "color": Color("f2f6ff")},
	{"id": "eggs", "name": "Farm Eggs", "cat": "Dairy", "buy": 4.00, "sell": 6.75, "demand": 0.80, "quality": 4, "shape": "box", "color": Color("f3e3c3")},
	{"id": "bread", "name": "Soft Bread", "cat": "Bakery", "buy": 2.25, "sell": 4.25, "demand": 1.00, "quality": 3, "shape": "loaf", "color": Color("c98c4a")},
	{"id": "apple", "name": "Red Apples", "cat": "Produce", "buy": 2.50, "sell": 4.50, "demand": 0.90, "quality": 4, "shape": "round", "color": Color("d62828")},
	{"id": "banana", "name": "Bananas", "cat": "Produce", "buy": 2.00, "sell": 3.75, "demand": 0.90, "quality": 3, "shape": "loaf", "color": Color("f4d03f")},
	{"id": "tomato", "name": "Tomatoes", "cat": "Produce", "buy": 2.25, "sell": 4.00, "demand": 0.85, "quality": 3, "shape": "round", "color": Color("e2492f")},
	{"id": "chicken", "name": "Chicken", "cat": "Meat", "buy": 8.00, "sell": 13.75, "demand": 0.70, "quality": 4, "shape": "box", "color": Color("f0a9a0")},
	{"id": "rice", "name": "Basmati Rice", "cat": "Grocery", "buy": 6.00, "sell": 10.50, "demand": 0.75, "quality": 4, "shape": "bag", "color": Color("efe6cf")},
	{"id": "cola", "name": "Cola Cans", "cat": "Drinks", "buy": 1.75, "sell": 3.50, "demand": 1.10, "quality": 3, "shape": "can", "color": Color("c1121f")},
	{"id": "juice", "name": "Orange Juice", "cat": "Drinks", "buy": 3.75, "sell": 7.00, "demand": 0.80, "quality": 4, "shape": "bottle", "color": Color("ff9f1c")},
	{"id": "chips", "name": "Potato Chips", "cat": "Snacks", "buy": 2.25, "sell": 4.75, "demand": 1.00, "quality": 3, "shape": "bag", "color": Color("ffd23f")},
	{"id": "shampoo", "name": "Shampoo", "cat": "Care", "buy": 7.00, "sell": 13.00, "demand": 0.55, "quality": 4, "shape": "bottle", "color": Color("9b5de5")},
	{"id": "soap", "name": "Soap Bars", "cat": "Care", "buy": 2.00, "sell": 4.00, "demand": 0.70, "quality": 3, "shape": "box", "color": Color("2ec4b6")},
	{"id": "cereal", "name": "Breakfast Cereal", "cat": "Grocery", "buy": 5.00, "sell": 9.00, "demand": 0.80, "quality": 4, "shape": "box", "color": Color("f77f00")},
	{"id": "water", "name": "Mineral Water", "cat": "Drinks", "buy": 1.00, "sell": 2.25, "demand": 1.20, "quality": 3, "shape": "bottle", "color": Color("8ecae6")},
	{"id": "choc", "name": "Chocolate", "cat": "Snacks", "buy": 2.25, "sell": 5.00, "demand": 0.90, "quality": 4, "shape": "box", "color": Color("6f4518")},
]

static var CAT_COLORS: Dictionary = {
	"Dairy": Color("4ea8de"), "Bakery": Color("d4a373"), "Produce": Color("52b788"),
	"Meat": Color("e5383b"), "Grocery": Color("f4a261"), "Drinks": Color("e63946"),
	"Snacks": Color("ffbe0b"), "Care": Color("9b5de5"),
}

static var CATEGORIES: Array = ["Dairy", "Bakery", "Produce", "Meat", "Grocery", "Drinks", "Snacks", "Care"]

## Employee types: hire cost, daily salary at level 1, max count rule is in Game.
static var EMP_TYPES: Dictionary = {
	"cashier": {"name": "Cashier", "hire": 150.0, "salary": 30.0, "desc": "Scans items automatically at a checkout lane."},
	"stock": {"name": "Stock Manager", "hire": 220.0, "salary": 38.0, "desc": "Moves goods from the warehouse to empty shelves."},
	"cleaner": {"name": "Cleaner", "hire": 120.0, "salary": 24.0, "desc": "Cleans litter so customers stay happy."},
	"guard": {"name": "Security Guard", "hire": 200.0, "salary": 36.0, "desc": "Greatly reduces shoplifting."},
	"supervisor": {"name": "Supervisor", "hire": 600.0, "salary": 70.0, "desc": "Boosts speed of all your staff by 10% per level."},
}

static var EMP_ORDER: Array = ["cashier", "stock", "cleaner", "guard", "supervisor"]

static var FIRST_NAMES: Array = ["Aarav", "Maya", "Liam", "Sofia", "Noah", "Zara", "Ethan", "Priya", "Lucas", "Amira", "Omar", "Chloe", "Ravi", "Emma", "Diego", "Hana", "Kofi", "Lena", "Yusuf", "Mia"]

## Upgrades: id -> definition. cost is computed in Game.upgrade_cost.
static var UPGRADES: Array = [
	{"id": "shelves", "name": "New Shelf Unit", "desc": "Unlock another shelf face in the store."},
	{"id": "shelf_cap", "name": "Bigger Shelves", "desc": "+50% stock capacity on every shelf.", "max": 5},
	{"id": "lanes", "name": "Checkout Lanes", "desc": "Build another checkout counter.", "max": 3},
	{"id": "parking", "name": "Parking Lot", "desc": "More parking: more customers at once.", "max": 4},
	{"id": "warehouse", "name": "Warehouse Size", "desc": "+120 storage capacity.", "max": 5},
	{"id": "store_level", "name": "Store Interior", "desc": "Marble floors, decor, richer customers.", "max": 5},
	{"id": "ads", "name": "Advertising", "desc": "Daily ad budget attracts more shoppers.", "max": 3},
]

static var STORE_LEVEL_COST: Array = [0, 2500, 9000, 28000, 80000]
static var ADS_COST: Array = [0, 300, 900, 2500]
static var ADS_DAILY: Array = [0, 25, 70, 160]
static var ADS_MULT: Array = [1.0, 1.18, 1.4, 1.75]

static func product_by_id(id: String) -> Dictionary:
	for p in PRODUCTS:
		if p["id"] == id:
			return p
	return {}
