class_name Art
extends RefCounted
## Loads optional art by name. Real art replaces placeholders by using the same file names (see ASSET_SPEC.md).

static var _cache: Dictionary = {}


static func tex(name: String) -> Texture2D:
	if _cache.has(name):
		return _cache[name]
	var res: Texture2D = null
	for folder in ["art", "icons"]:
		var path := "res://assets/%s/%s.png" % [folder, name]
		if ResourceLoader.exists(path):
			res = load(path)
			break
	_cache[name] = res
	return res
