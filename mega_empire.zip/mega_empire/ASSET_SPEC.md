# ASSET SPEC — ChatGPT se banwane ke liye

Rule: **file ka naam bilkul same** rakho (small letters). Same naam = purani placeholder replace. Folder: `assets/art/` ya `assets/icons/`. Format PNG.
Style line (har prompt me jodo): *"stylized semi-realistic 3D-render look, clean soft lighting, vibrant colors, mobile game quality, no text, no watermark"*

## A. Zaroori (sabse pehle)
| File | Size | Background | Prompt idea |
|---|---|---|---|
| assets/icon.png | 512×512 | opaque, square | App icon: gold coin + small supermarket building, bright gradient |
| assets/art/logo.png | 1024×512 | TRANSPARENT | Logo text "MEGA EMPIRE TYCOON" gold 3D letters, shopping cart |
| assets/art/menu_bg.png | 1920×1080 (16:9) | opaque | Modern supermarket exterior at golden-hour, wide shot, left side empty space |

## B. Seamless textures (tile hone chahiye) — 1024×1024, square, top-down flat, NO perspective, NO shadow/objects
- floor_tile.png — clean light-grey/white supermarket floor tiles
- floor_marble.png — white-grey polished marble
- wall.png — soft cream painted wall with subtle texture
- road.png — dark asphalt (no lane lines)
- grass.png — short green lawn
Prompt: *"seamless tileable texture, top-down, flat, 1024x1024, <material>"* (ChatGPT ko bolo: edges match hone chahiye).

## C. Products — assets/art/prod_<id>.png
256×256, TRANSPARENT background, single product, front view, centred, thoda margin.
IDs + item: milk (1L carton), eggs (egg box), bread (loaf), apple (red), banana (bunch), tomato, chicken (packed raw), rice (bag), cola (can), juice (carton), chips (bag), shampoo (bottle), soap (bar box), cereal (box), water (bottle), choc (chocolate bar).
Real size reference (3D me): bottle 0.08×0.26 m, can 0.07×0.12 m, box 0.2×0.25×0.06 m, bag 0.18×0.26 m, loaf 0.25×0.12 m, round fruit 0.08 m.

## D. UI icons — assets/icons/ui_<name>.png
128×128, TRANSPARENT, **solid WHITE glyph only** (game khud colour karta hai), thick rounded line, no outline/shadow.
Names: ui_shop (cart), ui_staff (people), ui_upgrade (up-arrow), ui_missions (flag/checklist), ui_stats (bar chart), ui_camera (camera), ui_settings (gear), ui_pause (two bars), ui_speed (fast-forward), ui_coin (coin — ye colour wala ho sakta hai), ui_close (X).

## E. Audio (optional) — audio/*.wav
click, beep, cash, upgrade, door, pick, cart, step (short <1s, 44.1kHz, mono/stereo WAV); music (loop 60–120s), ambient (loop 30–60s, store hum). Free CC0: freesound.org / kenney.nl (WAV me convert).

## F. 3D scale (Godot = 1 unit = 1 meter) — agle phase me real models ke liye
Store 20×18 m, wall height 4 m · shelf 2.7 m wide × 2.0 m tall × 0.7 m deep (back-wall shelf 2.3 m tall) · checkout counter 2.6×1.0×1.2 m · door 2.4 m wide × 2.6 m tall · person 1.70 m (kid 1.2 m) · cart 1.0×1.0×0.6 m · crate 0.5×0.3×0.4 m · car 4.2×1.5×1.8 m · street lamp 5 m.
Models: format **.glb** (glTF), ≤5k triangles each, textures ≤1024 px, origin = floor-centre, forward = −Z. Free CC0 packs: kenney.nl, quaternius.com, poly.pizza.

## Kaise bhejna
Files ek-ek ya zip me chat me bhejo. Main project me daal ke naya zip dunga. Ya khud GitHub repo me same folder/naam se upload karo (Add file → Upload).
