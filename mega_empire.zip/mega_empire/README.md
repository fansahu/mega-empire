# Mega Empire Tycoon 3D (Godot 4.3)
**Build (phone only):** GitHub repo me poora project upload (ya zip upload) → Actions → "Build Android APK (Godot)" → Run → artifact `MegaEmpire-APK` / Releases → `latest`. APK install karo.
**Status:** Code headless-simulation me test hua (customers, queue, cashier, economy, 3 din). APK build GitHub par abhi verify nahi — fail ho to log bhejo.
**Done:** store 3D, customer AI, 16 products, shelves/warehouse/ordering, 5 staff types, economy (rent/salary/ads/COGS), idle+offline, 10 missions, save, day-night, touch camera, UI, audio.
**Baaki:** 20 business types, prestige/achievements, delivery staff, AdMob (core test ke baad), real art/audio/models.
