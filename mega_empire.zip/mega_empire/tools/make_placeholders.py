#!/usr/bin/env python3
"""Generates PLACEHOLDER art so the game builds and runs before real art exists.
Real art (from ChatGPT etc.) must be saved with the SAME file names and sizes - see ASSET_SPEC.md.
Existing files are NOT overwritten unless --force is passed."""
import os
import sys

import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
ART = os.path.join(ROOT, "assets", "art")
ICO = os.path.join(ROOT, "assets", "icons")
os.makedirs(ART, exist_ok=True)
os.makedirs(ICO, exist_ok=True)
FORCE = "--force" in sys.argv


def font(size):
    for p in ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"):
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


def save(img, path):
    if os.path.exists(path) and not FORCE:
        return
    img.save(path)


def seamless_noise(size, scale_list, seed):
    rng = np.random.default_rng(seed)
    y, x = np.mgrid[0:size, 0:size] / size
    out = np.zeros((size, size))
    for s in scale_list:
        px, py = rng.uniform(0, 6.28, 2)
        out += np.sin(2 * np.pi * s * x + px) * np.sin(2 * np.pi * s * y + py) / s
    out = (out - out.min()) / (out.max() - out.min())
    return out


def tex_from(base, noise, strength, size=1024):
    arr = np.zeros((size, size, 3))
    for i in range(3):
        arr[..., i] = base[i] * (1 - strength + strength * 2 * noise)
    return Image.fromarray(np.clip(arr, 0, 255).astype("uint8"))


# ---------------- seamless textures (1024)
n1 = seamless_noise(1024, [3, 7, 13, 29], 1)
save(tex_from((150, 160, 170), n1, 0.12), os.path.join(ART, "floor_tile.png"))
img = tex_from((226, 222, 214), n1, 0.10)
d = ImageDraw.Draw(img)
for i in range(0, 1024, 256):
    d.line([(i, 0), (i, 1023)], fill=(170, 168, 160), width=3)
    d.line([(0, i), (1023, i)], fill=(170, 168, 160), width=3)
save(img, os.path.join(ART, "floor_marble.png"))
save(tex_from((236, 232, 224), seamless_noise(1024, [5, 11], 2), 0.05), os.path.join(ART, "wall.png"))
save(tex_from((62, 64, 70), seamless_noise(1024, [9, 21, 45], 3), 0.18), os.path.join(ART, "road.png"))
save(tex_from((74, 130, 60), seamless_noise(1024, [7, 19, 41], 4), 0.2), os.path.join(ART, "grass.png"))

# ---------------- product icons (256, transparent)
sys.path.insert(0, os.path.join(ROOT, "tools"))
PRODUCTS = [
    ("milk", "Milk", "f2f6ff"), ("eggs", "Eggs", "f3e3c3"), ("bread", "Bread", "c98c4a"), ("apple", "Apple", "d62828"),
    ("banana", "Banana", "f4d03f"), ("tomato", "Tomato", "e2492f"), ("chicken", "Chicken", "f0a9a0"), ("rice", "Rice", "efe6cf"),
    ("cola", "Cola", "c1121f"), ("juice", "Juice", "ff9f1c"), ("chips", "Chips", "ffd23f"), ("shampoo", "Shampoo", "9b5de5"),
    ("soap", "Soap", "2ec4b6"), ("cereal", "Cereal", "f77f00"), ("water", "Water", "8ecae6"), ("choc", "Choco", "6f4518"),
]
for pid, label, hexc in PRODUCTS:
    S = 1024
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c = tuple(int(hexc[i : i + 2], 16) for i in (0, 2, 4))
    d.rounded_rectangle([160, 120, 864, 904], radius=120, fill=c + (255,), outline=(255, 255, 255, 255), width=24)
    d.rounded_rectangle([160, 120, 864, 330], radius=120, fill=(255, 255, 255, 70))
    f = font(150 if len(label) < 7 else 120)
    w = d.textlength(label, font=f)
    lum = 0.3 * c[0] + 0.59 * c[1] + 0.11 * c[2]
    d.text(((S - w) / 2, 480), label, font=f, fill=(20, 20, 20, 255) if lum > 140 else (255, 255, 255, 255))
    save(im.resize((256, 256), Image.LANCZOS), os.path.join(ART, f"prod_{pid}.png"))

# ---------------- ui icons (128, white glyph on transparent)
def icon(name, draw_fn):
    S = 512
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    draw_fn(d, S)
    save(im.resize((128, 128), Image.LANCZOS), os.path.join(ICO, f"ui_{name}.png"))


W = (255, 255, 255, 255)


def cart(d, S):
    d.line([(60, 100), (140, 100), (200, 340), (410, 340)], fill=W, width=34, joint="curve")
    d.polygon([(150, 140), (450, 140), (410, 290), (190, 290)], fill=W)
    d.ellipse([200, 380, 270, 450], fill=W)
    d.ellipse([350, 380, 420, 450], fill=W)


def staff(d, S):
    d.ellipse([170, 60, 340, 230], fill=W)
    d.pieslice([90, 250, 420, 640], 180, 360, fill=W)


def upgrade(d, S):
    d.polygon([(256, 50), (450, 270), (340, 270), (340, 460), (172, 460), (172, 270), (62, 270)], fill=W)


def missions(d, S):
    d.rounded_rectangle([90, 60, 420, 460], radius=40, outline=W, width=30)
    for i, y in enumerate((160, 250, 340)):
        d.ellipse([140, y - 14, 170, y + 16], fill=W)
        d.line([(200, y), (370, y)], fill=W, width=24)


def statsf(d, S):
    for i, h in enumerate((140, 250, 200, 360)):
        x = 90 + i * 85
        d.rounded_rectangle([x, 440 - h, x + 60, 440], radius=12, fill=W)


def camera(d, S):
    d.rounded_rectangle([60, 140, 450, 420], radius=50, fill=W)
    d.rectangle([160, 100, 300, 160], fill=W)
    d.ellipse([170, 200, 340, 370], fill=(0, 0, 0, 0))
    d.ellipse([200, 230, 310, 340], fill=W)


def gear(d, S):
    import math

    cx = cy = 256
    for k in range(8):
        a = math.radians(k * 45)
        x, y = cx + 190 * math.cos(a), cy + 190 * math.sin(a)
        d.ellipse([x - 40, y - 40, x + 40, y + 40], fill=W)
    d.ellipse([86, 86, 426, 426], fill=W)
    d.ellipse([186, 186, 326, 326], fill=(0, 0, 0, 0))


def pause(d, S):
    d.rounded_rectangle([150, 100, 220, 410], radius=20, fill=W)
    d.rounded_rectangle([290, 100, 360, 410], radius=20, fill=W)


def speed(d, S):
    d.polygon([(90, 100), (90, 410), (260, 255)], fill=W)
    d.polygon([(250, 100), (250, 410), (420, 255)], fill=W)


def coin(d, S):
    d.ellipse([60, 60, 450, 450], fill=(255, 200, 60, 255), outline=(200, 130, 20, 255), width=24)
    d.text((190, 120), "$", font=font(260), fill=(160, 100, 10, 255))


def close(d, S):
    d.line([(110, 110), (400, 400)], fill=W, width=50)
    d.line([(400, 110), (110, 400)], fill=W, width=50)


for n, fn in (("shop", cart), ("staff", staff), ("upgrade", upgrade), ("missions", missions), ("stats", statsf), ("camera", camera), ("settings", gear), ("pause", pause), ("speed", speed), ("coin", coin), ("close", close)):
    icon(n, fn)

# ---------------- logo / menu background / app icon
logo = Image.new("RGBA", (1024, 512), (0, 0, 0, 0))
d = ImageDraw.Draw(logo)
d.text((512, 190), "MEGA EMPIRE", font=font(130), fill=(255, 214, 90, 255), anchor="mm", stroke_width=6, stroke_fill=(90, 50, 0, 255))
d.text((512, 330), "TYCOON 3D", font=font(130), fill=(255, 255, 255, 255), anchor="mm", stroke_width=6, stroke_fill=(20, 40, 90, 255))
save(logo, os.path.join(ART, "logo.png"))

bg = Image.new("RGB", (1920, 1080))
px = np.zeros((1080, 1920, 3), dtype="uint8")
yy = np.linspace(0, 1, 1080)[:, None]
px[..., 0] = (18 + 30 * yy).astype("uint8")
px[..., 1] = (28 + 50 * yy).astype("uint8")
px[..., 2] = (60 + 70 * yy).astype("uint8")
save(Image.fromarray(px), os.path.join(ART, "menu_bg.png"))

ic = Image.new("RGBA", (1024, 1024), (24, 34, 62, 255))
d = ImageDraw.Draw(ic)
d.rounded_rectangle([60, 60, 964, 964], radius=200, fill=(30, 60, 120, 255))
d.text((512, 420), "ME", font=font(420), fill=(255, 214, 90, 255), anchor="mm", stroke_width=10, stroke_fill=(90, 50, 0, 255))
d.text((512, 760), "TYCOON", font=font(190), fill=(255, 255, 255, 255), anchor="mm")
save(ic.resize((512, 512), Image.LANCZOS), os.path.join(ROOT, "assets", "icon.png"))
print("placeholders ok")
