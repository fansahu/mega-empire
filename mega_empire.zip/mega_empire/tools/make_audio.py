#!/usr/bin/env python3
"""Synthesizes the placeholder sound effects, ambient loop and music loop into ./audio (WAV, 22.05 kHz, 16-bit mono).
Replace any file with your own sound (same name) to upgrade it."""
import os
import wave

import numpy as np

SR = 22050
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "audio")
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(7)


def save(name, x):
    x = np.clip(x, -1, 1)
    data = (x * 32767 * 0.9).astype("<i2")
    with wave.open(os.path.join(OUT, name + ".wav"), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())


def t(sec):
    return np.arange(int(SR * sec)) / SR


def env(n, a=0.005, r=0.1):
    e = np.ones(n)
    na, nr = int(SR * a), int(SR * r)
    if na > 0:
        e[:na] = np.linspace(0, 1, na)
    if nr > 0:
        e[-nr:] *= np.linspace(1, 0, nr)
    return e


def tone(f, sec, kind="sine", decay=6.0):
    tt = t(sec)
    ph = 2 * np.pi * f * tt
    if kind == "sine":
        w = np.sin(ph)
    elif kind == "tri":
        w = 2 / np.pi * np.arcsin(np.sin(ph))
    else:
        w = np.sign(np.sin(ph)) * 0.5
    return w * np.exp(-decay * tt) * env(len(tt), 0.003, 0.02)


def lowpass(x, k):
    k = max(1, int(k))
    return np.convolve(x, np.ones(k) / k, mode="same")


# --- sfx
save("click", tone(1400, 0.06, "sine", 40) * 0.8)
save("beep", tone(1900, 0.09, "sq", 18) * 0.6)
cash = np.concatenate([tone(1318, 0.12, "sine", 14), tone(1760, 0.45, "sine", 5)])
cash[: int(SR * 0.05)] += lowpass(rng.normal(0, 0.4, int(SR * 0.05)), 3)
save("cash", cash * 0.8)
notes = [523.25, 659.25, 783.99, 1046.5]
up = np.concatenate([tone(f, 0.16, "tri", 7) for f in notes[:-1]] + [tone(notes[-1], 0.5, "tri", 4)])
save("upgrade", up * 0.8)
save("door", np.concatenate([tone(880, 0.2, "sine", 8), tone(660, 0.45, "sine", 5)]) * 0.6)
pk = lowpass(rng.normal(0, 1, int(SR * 0.16)), 12) * env(int(SR * 0.16), 0.02, 0.1)
save("pick", pk * 1.4)
n = int(SR * 0.4)
cart = lowpass(rng.normal(0, 1, n), 4) * (0.5 + 0.5 * np.sin(2 * np.pi * 38 * t(0.4))) * env(n, 0.02, 0.15)
save("cart", cart * 0.5)
save("step", tone(110, 0.08, "sine", 45) * 0.9)

# --- ambient (10 s seamless murmur)
L = int(SR * 10)
base = lowpass(rng.normal(0, 1, L), 40) * 2.2
mod = 0.65 + 0.35 * np.sin(2 * np.pi * 0.2 * t(10)) * np.sin(2 * np.pi * 0.13 * t(10) + 1)
amb = base * mod
hum = np.sin(2 * np.pi * 60 * t(10)) * 0.04
amb = amb + hum
fade = int(SR * 0.5)
amb[:fade] = amb[:fade] * np.linspace(0, 1, fade) + amb[-fade:] * np.linspace(1, 0, fade)
amb = amb[:-fade]
save("ambient", amb * 0.5)

# --- music (about 19 s loop, 100 bpm, Am - F - C - G)
beat = 60 / 100
chords = [
    [220.0, 261.63, 329.63],
    [174.61, 220.0, 261.63],
    [261.63, 329.63, 392.0],
    [196.0, 246.94, 293.66],
]
bars = []
for rep in range(2):
    for ch in chords:
        sec = beat * 4
        n = int(SR * sec)
        tt = np.arange(n) / SR
        pad = sum(np.sin(2 * np.pi * f * tt) + 0.4 * np.sin(2 * np.pi * f * 2 * tt) for f in ch) / len(ch)
        pad *= env(n, 0.25, 0.25) * 0.28
        arp = np.zeros(n)
        seq = ch + [ch[1] * 2, ch[2] * 2, ch[1] * 2, ch[0] * 2, ch[1]]
        for i, f in enumerate(seq[:8]):
            st = int(SR * i * beat / 2)
            nn = int(SR * beat / 2)
            seg = tone(f * 2 if rep else f * 2, beat / 2, "tri", 5)[:nn]
            arp[st : st + len(seg)] += seg[: n - st] * 0.2
        bass = np.sin(2 * np.pi * (ch[0] / 2) * tt) * env(n, 0.02, 0.3) * 0.25
        bars.append(pad + arp + bass)
music = np.concatenate(bars)
save("music", music * 0.8)
print("audio ok:", sorted(os.listdir(OUT)))
