#!/usr/bin/env python3
"""Premium-ish synthesized audio v2 (FM bells, filtered noise, reverb, lo-fi music). Writes ./audio/*.wav (32 kHz, 16 bit, mono).
Replace any file with a real recording of the same name to upgrade."""
import os, wave
import numpy as np

SR = 32000
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "audio")
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(11)


def save(name, x, peak=0.85):
    m = np.max(np.abs(x)) + 1e-9
    x = x / m * peak
    with wave.open(os.path.join(OUT, name + ".wav"), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((x * 32767).astype("<i2").tobytes())


def T(sec): return np.arange(int(SR * sec)) / SR


def lp(x, fc):
    X = np.fft.rfft(x); f = np.fft.rfftfreq(len(x), 1 / SR)
    return np.fft.irfft(X / (1 + (f / fc) ** 4), len(x))


def hp(x, fc):
    X = np.fft.rfft(x); f = np.fft.rfftfreq(len(x), 1 / SR)
    return np.fft.irfft(X * (1 - 1 / (1 + (f / fc) ** 4)), len(x))


def bp(x, lo, hi): return hp(lp(x, hi), lo)


def ir(sec, decay=4.0, bright=3500):
    n = int(SR * sec); t = np.arange(n) / SR
    r = rng.standard_normal(n) * np.exp(-decay * t)
    r = lp(r, bright)
    r[0] = 0
    return r / np.sqrt(np.sum(r ** 2))


def reverb(x, wet=0.25, sec=1.4, decay=3.5, circular=False):
    r = ir(sec, decay)
    n = len(x) + (0 if circular else len(r))
    X = np.fft.rfft(x, n); R = np.fft.rfft(r, n)
    y = np.fft.irfft(X * R, n)
    out = np.zeros(n); out[:len(x)] += x * (1 - wet); out += y * wet * 1.6
    return out


def adsr(n, a=0.003, d=0.1, s=0.5, r=0.1):
    e = np.ones(n); na, nd, nr = int(SR * a), int(SR * d), int(SR * r)
    e[:na] = np.linspace(0, 1, max(na, 1))
    e[na:na + nd] = np.linspace(1, s, max(nd, 1))[:max(0, min(nd, n - na))]
    e[na + nd:] = s
    if nr > 0: e[-nr:] *= np.linspace(1, 0, nr)
    return e


def bell(f, sec, amp=1.0, ratios=(1, 2.76, 5.4, 8.93), amps=(1, .5, .25, .12), decay=5.0):
    t = T(sec); y = np.zeros_like(t)
    for r_, a_ in zip(ratios, amps):
        y += a_ * np.sin(2 * np.pi * f * r_ * t) * np.exp(-decay * (1 + 0.35 * r_) * t)
    return y * amp


def rhodes(f, sec, amp=1.0):
    t = T(sec)
    mod = np.sin(2 * np.pi * f * 14 * t) * 0.6 * np.exp(-14 * t)
    y = np.sin(2 * np.pi * f * t + mod * 2.2) * np.exp(-1.6 * t)
    y += 0.35 * np.sin(2 * np.pi * f * 2 * t + mod) * np.exp(-3.0 * t)
    y += 0.12 * np.sin(2 * np.pi * f * 4 * t) * np.exp(-6 * t)
    return y * amp * adsr(len(t), 0.004, 0.2, 0.7, 0.25)


def place(buf, x, at):
    i = int(at * SR)
    n = min(len(x), len(buf) - i)
    if n > 0: buf[i:i + n] += x[:n]


# ---------------------------------------------------------------- SFX
def click():
    t = T(0.09)
    y = np.sin(2 * np.pi * 1250 * t) * np.exp(-90 * t) * 0.8
    y += lp(rng.standard_normal(len(t)), 5000) * np.exp(-400 * t) * 0.6
    return reverb(y, 0.12, 0.3, 8)


def beep():
    t = T(0.16)
    y = (np.sin(2 * np.pi * 1760 * t) + 0.5 * np.sin(2 * np.pi * 2637 * t)) * adsr(len(t), 0.002, 0.02, 0.8, 0.04)
    return reverb(y, 0.12, 0.35, 8)


def cash():
    out = np.zeros(int(SR * 1.6))
    k = lp(rng.standard_normal(int(SR * 0.05)), 3500) * np.exp(-T(0.05) * 90)
    place(out, k * 0.7, 0.0)
    place(out, bell(1568, 1.2, 0.8, decay=4.5), 0.03)
    place(out, bell(2093, 1.2, 0.7, decay=4.2), 0.11)
    place(out, bell(3136, 0.8, 0.25, decay=7), 0.17)
    coins = np.zeros(int(SR * 0.5))
    for i in range(7):
        place(coins, bell(rng.uniform(3500, 6200), 0.2, 0.18, ratios=(1, 2.3), amps=(1, .4), decay=18), 0.02 + i * 0.045 + rng.uniform(0, 0.02))
    place(out, coins, 0.2)
    return reverb(out, 0.22, 0.9, 4.5)


def upgrade():
    out = np.zeros(int(SR * 2.2))
    for i, f in enumerate([523.25, 659.25, 783.99, 1046.5, 1318.5]):
        place(out, bell(f, 1.2, 0.6, ratios=(1, 2, 3.01, 4.2), amps=(1, .4, .2, .1), decay=3.2), i * 0.085)
        place(out, rhodes(f / 2, 0.8, 0.25), i * 0.085)
    sp = hp(rng.standard_normal(int(SR * 1.0)), 6000) * np.exp(-T(1.0) * 3.0) * 0.06
    place(out, sp, 0.3)
    return reverb(out, 0.3, 1.5, 3.0)


def door():
    out = np.zeros(int(SR * 1.6))
    place(out, bell(880, 1.2, 0.6, ratios=(1, 2.01, 3.0), amps=(1, .3, .12), decay=3.4), 0.0)
    place(out, bell(659.25, 1.2, 0.6, ratios=(1, 2.01, 3.0), amps=(1, .3, .12), decay=3.4), 0.22)
    w = bp(rng.standard_normal(int(SR * 0.5)), 200, 1800) * np.hanning(int(SR * 0.5)) * 0.25
    place(out, w, 0.0)
    return reverb(out, 0.25, 1.0, 4.0)


def pick():
    t = T(0.18)
    y = bp(rng.standard_normal(len(t)), 700, 4500) * (np.exp(-30 * t) + 0.5 * np.exp(-60 * np.abs(t - 0.07)))
    y += np.sin(2 * np.pi * 320 * t) * np.exp(-50 * t) * 0.4
    return reverb(y, 0.12, 0.35, 8)


def cart():
    t = T(0.9)
    y = lp(rng.standard_normal(len(t)), 900) * 0.5
    rat = (np.sin(2 * np.pi * 14 * t) > 0.6) * bp(rng.standard_normal(len(t)), 1200, 5000) * 0.35
    y = (y + rat) * np.hanning(len(t)) ** 0.5
    return reverb(y, 0.15, 0.5, 6)


def step():
    t = T(0.13)
    y = lp(rng.standard_normal(len(t)), 700) * np.exp(-45 * t) + np.sin(2 * np.pi * 95 * t) * np.exp(-40 * t) * 0.8
    return reverb(y, 0.08, 0.25, 9)


# ---------------------------------------------------------------- loops
def ambient():
    sec = 24.0; n = int(SR * sec); t = T(sec)
    hum = np.sin(2 * np.pi * 60 * t) * 0.05 + np.sin(2 * np.pi * 120 * t) * 0.025
    air = lp(rng.standard_normal(n), 600) * 0.35 + lp(rng.standard_normal(n), 3000) * 0.05
    mur = np.zeros(n)
    for _ in range(26):  # distant murmurs / shoppers
        d = rng.uniform(0.5, 1.6); st = rng.uniform(0, sec - d)
        f = rng.uniform(140, 320); k = int(d * SR); tt = np.arange(k) / SR
        v = (np.sin(2 * np.pi * f * tt * (1 + 0.15 * np.sin(2 * np.pi * rng.uniform(3, 6) * tt))) +
             0.5 * np.sin(2 * np.pi * 2 * f * tt) + 0.3 * np.sin(2 * np.pi * 3 * f * tt)) * np.hanning(k)
        mur[int(st * SR):int(st * SR) + k] += lp(v, 1400) * 0.05
    scan = np.zeros(n)
    for _ in range(7):
        st = rng.uniform(0, sec - 0.3)
        b = np.sin(2 * np.pi * 1760 * T(0.09)) * adsr(int(SR * 0.09), .003, .02, .6, .03) * 0.03
        scan[int(st * SR):int(st * SR) + len(b)] += b
    y = hum + air + mur + scan
    y = reverb(y, 0.35, 1.2, 3.0, circular=True)
    y = np.roll(y, 0)
    return y


def music():
    bpm = 80; beat = 60 / bpm; bars = 16; sec = bars * beat * 4
    n = int(SR * sec); buf = np.zeros(n); drums = np.zeros(n); bass = np.zeros(n)
    hz = lambda m: 440 * 2 ** ((m - 69) / 12)
    prog = [[60, 64, 67, 71], [57, 60, 64, 67], [53, 57, 60, 64], [55, 59, 62, 65]]  # Cmaj7 Am7 Fmaj7 G7
    roots = [36, 33, 29, 31]
    for bar in range(bars):
        ch = prog[(bar // 2) % 4]; rt = roots[(bar // 2) % 4]
        t0 = bar * beat * 4
        for j, m in enumerate(ch):  # soft rolled chord, comping on 1 and 2.5
            for off, vel in ((0.0, 1.0), (2.5 * beat, 0.7)):
                place(buf, rhodes(hz(m), 1.6, 0.16 * vel), t0 + off + j * 0.018)
        melody = [ch[3] + 12, ch[2] + 12, ch[1] + 12, ch[2] + 12]
        if bar % 4 in (1, 3):
            for k, off in enumerate((1.0, 1.5, 3.0)):
                place(buf, bell(hz(melody[(k + bar) % 4]), 0.9, 0.12, ratios=(1, 2, 3.0), amps=(1, .3, .1), decay=5), t0 + off * beat)
        for off, ln in ((0, 1.5), (2, 1.0), (3, 0.9)):
            tt = T(ln * beat)
            f = hz(rt + (0 if off != 3 else 7))
            place(bass, (np.sin(2 * np.pi * f * tt) + 0.3 * np.sin(2 * np.pi * 2 * f * tt)) * adsr(len(tt), 0.01, 0.1, 0.7, 0.08) * 0.34, t0 + off * beat)
        for b in range(4):  # drums
            tb = t0 + b * beat
            if b in (0, 2):
                kt = T(0.28); kf = 120 * np.exp(-12 * kt) + 42
                place(drums, np.sin(2 * np.pi * np.cumsum(kf) / SR) * np.exp(-9 * kt) * 0.7, tb)
            if b in (1, 3):
                st = T(0.22)
                place(drums, (bp(rng.standard_normal(len(st)), 900, 5500) * np.exp(-18 * st) * 0.38 + np.sin(2 * np.pi * 190 * st) * np.exp(-25 * st) * 0.25), tb)
            for h in (0, 0.5):
                sw = 0.06 * beat if h else 0
                ht = T(0.05)
                place(drums, hp(rng.standard_normal(len(ht)), 7000) * np.exp(-70 * ht) * (0.16 if h else 0.1), tb + h * beat + sw)
    side = np.ones(n)  # gentle sidechain pump from kicks
    for bar in range(bars):
        for b in (0, 2):
            i = int((bar * 4 + b) * beat * SR); L = int(0.25 * SR)
            side[i:i + L] *= np.linspace(0.55, 1, min(L, n - i))
    mix = lp(buf, 4200) * side + bass * side + drums
    mix += lp(rng.standard_normal(n), 2500) * 0.004  # tape hiss
    mix = reverb(mix, 0.22, 1.6, 3.0, circular=True)[:n]
    mix = np.tanh(mix * 1.2)
    fade = int(0.01 * SR); mix[:fade] *= np.linspace(0, 1, fade); mix[-fade:] *= np.linspace(1, 0, fade)
    return mix


if __name__ == "__main__":
    for nm, fn in [("click", click), ("beep", beep), ("cash", cash), ("upgrade", upgrade), ("door", door), ("pick", pick), ("cart", cart), ("step", step)]:
        save(nm, fn(), 0.8)
    save("ambient", ambient(), 0.6)
    save("music", music(), 0.75)
    print("done")
