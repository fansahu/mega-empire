extends Node
func _ready() -> void:
	PersonModels.available()
	Game.new_game()
	Game.money = 5000
	Game.hire("cashier"); Game.hire("guard")
	var hud := Hud.new(); add_child(hud); hud.visible = true
	get_window().size = Vector2i(1280, 720)
	await get_tree().create_timer(0.5).timeout
	hud.open_panel("staff")
	await get_tree().create_timer(0.5).timeout
	get_viewport().get_texture().get_image().save_png("/tmp/claude-0/-home-claude/b2ae0239-1cf2-5be8-88fe-d5dac3cfca6c/scratchpad/ui1.png")
	var id: int = int(Game.employees[0]["id"])
	Game.employees[0]["look"] = Looks.from_preset(Looks.preset_by_id("m3"))
	Game.employees[0]["type"] = "cashier"
	hud.open_panel("studio", id)
	await get_tree().create_timer(1.5).timeout
	get_viewport().get_texture().get_image().save_png("/tmp/claude-0/-home-claude/b2ae0239-1cf2-5be8-88fe-d5dac3cfca6c/scratchpad/ui2.png")
	Game.set_look_item(id, "hat", 6)
	hud.studio_cat = "hat"; hud._rebuild()
	await get_tree().create_timer(1.0).timeout
	get_viewport().get_texture().get_image().save_png("/tmp/claude-0/-home-claude/b2ae0239-1cf2-5be8-88fe-d5dac3cfca6c/scratchpad/ui3.png")
	get_tree().quit()
