extends SceneTree
func _init() -> void:
	for f in ["HVGirl","RPM","Michelle"]:
		var n: Node = (load("res://assets/models/people/%s.glb" % f) as PackedScene).instantiate()
		print("== ", f)
		for ap in n.find_children("*", "AnimationPlayer", true, false):
			print(" anims ", (ap as AnimationPlayer).get_animation_list())
		for sk in n.find_children("*", "Skeleton3D", true, false):
			var s := sk as Skeleton3D
			print(" SK ", n.get_path_to(s), " bones ", s.get_bone_count(), " b0=", s.get_bone_name(0), " b1=", s.get_bone_name(1), " rhand=", s.find_bone("mixamorig_RightHand"), s.find_bone("RightHand"), " scale ", s.get_parent().scale if s.get_parent() is Node3D else "")
		for mi in n.find_children("*", "MeshInstance3D", true, false):
			print(" mesh ", mi.name, " aabb ", (mi as MeshInstance3D).get_aabb().size, " ", (mi as MeshInstance3D).mesh.get_surface_count())
		n.free()
	quit()
