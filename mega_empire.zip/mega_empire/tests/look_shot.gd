extends Node3D
var rigs: Array = []
func _process(_d: float) -> void:
	for r in rigs: PersonModels.animate(r, 0.0, "")
func _ready() -> void:
	PersonModels.available()
	var env := WorldEnvironment.new(); var e := Environment.new()
	e.background_mode = Environment.BG_COLOR; e.background_color = Color(0.5,0.55,0.6)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR; e.ambient_light_color = Color(0.9,0.9,0.9); e.ambient_light_energy = 0.7
	env.environment = e; add_child(env)
	var l := DirectionalLight3D.new(); l.rotation_degrees = Vector3(-40, -30, 0); add_child(l)
	var ids := ["m1","m3","m6","m8","w1","w4","w5","s_cashier","s_guard"]
	var i := 0
	for pid in ids:
		var p: Dictionary = Looks.preset_by_id(pid)
		var look: Dictionary = Looks.from_preset(p, pid.begins_with("s_"))
		if i == 2: look["hat"] = 1
		if i == 3: look["hat"] = 6; look["glass"] = 2
		if i == 4: look["hat"] = 4
		if i == 7: look["hat"] = 3
		var role: String = {"s_cashier":"cashier","s_guard":"guard"}.get(pid, "customer")
		var c := PersonModels.build(1000 + i, role, look)
		add_child(c); c.position = Vector3((i - 4) * 1.0, 0, 0)
		rigs.append(c.get_meta("rig"))
		i += 1
	var cam := Camera3D.new(); add_child(cam)
	cam.fov = 40
	cam.position = Vector3(0, 1.0, 7.5); cam.look_at(Vector3(0, 0.9, 0))
	await get_tree().create_timer(1.0).timeout
	for k in range(4): await get_tree().process_frame
	get_viewport().get_texture().get_image().save_png("/tmp/claude-0/-home-claude/b2ae0239-1cf2-5be8-88fe-d5dac3cfca6c/scratchpad/look1.png")
	cam.position = Vector3(0, 1.55, 3.0); cam.look_at(Vector3(-1.0, 1.5, 0))
	for k in range(3): await get_tree().process_frame
	get_viewport().get_texture().get_image().save_png("/tmp/claude-0/-home-claude/b2ae0239-1cf2-5be8-88fe-d5dac3cfca6c/scratchpad/look2.png")
	get_tree().quit()
