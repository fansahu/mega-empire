extends Node3D
## Headless simulation test: runs the real store + AI for a few game days and prints real stats.
## godot --headless --path . res://tests/SimTest.tscn

var store: Store
var t := 0.0
var days_target := 3


func _ready() -> void:
	Game.new_game()
	store = Store.new()
	add_child(store)
	store.build()
	Game.running = true
	Game.money = 5000.0
	for p in Data.PRODUCTS:
		Game.order_stock(p["id"], 20)
	for i in range(6):
		Game.move_to_shelf(i, 99)
	Game.hire("cashier")
	Game.hire("stock")
	Game.hire("cleaner")
	store.refresh_all()
	Engine.time_scale = 6.0
	Game.day_ended.connect(func(rep: Dictionary) -> void:
		print("DAY %d: revenue=%.2f cogs=%.2f profit=%.2f customers=%d lost=%d rating=%.2f money=%.2f" % [rep["day"], rep["revenue"], rep["cogs"], rep["profit"], rep["customers"], rep["lost"], rep["rating"], rep["money"]]))


func _process(delta: float) -> void:
	t += delta
	if int(t) % 5 == 0 and int(t) != int(t - delta):
		print("t=%d day=%d inside=%d cust_total=%d money=%.1f shelfstock=%d wh=%d lit=%d" % [t, Game.day, store.customers.size(), Game.total_customers, Game.money, Game.total_shelf_stock(), Game.warehouse_used(), store.litter.size()])
	if int(t) % 10 == 0 and int(t) != int(t - delta):
		var names := ["TO_DOOR","SHOP","PICK","TO_QUEUE","QUEUE","PAYING","LEAVING","DONE"]
		var parts: Array = []
		for c in store.customers:
			var cu: Customer = c
			parts.append("%s@(%.1f,%.1f) basket=%d wish=%d path=%d" % [names[cu.state], cu.position.x, cu.position.z, cu.basket.size(), cu.wish.size(), cu.path.size()])
		print("  customers: ", " | ".join(parts))
		for co in store.checkouts:
			var ch: Checkout = co
			if ch.visible:
				print("  lane%d q=%d scanning=%s left=%d cashier=%s" % [ch.lane, ch.queue.size(), ch.scanning_active, ch.items_left, ch.cashier != null])
	if Game.day > days_target:
		print("RESULT customers=%d revenue=%.2f items=%d rating=%.2f" % [Game.total_customers, Game.total_revenue, int(Game.stats["items_sold"]), Game.rating])
		get_tree().quit(0 if Game.total_customers > 5 else 1)
	if t > 600.0:
		print("TIMEOUT")
		get_tree().quit(2)
