extends Node3D
var store: Store
var rig: CamRig
var t := 0.0
var shots := [[14.0, "overview"], [24.0, "street"], [34.0, "shelves"]]
func _ready() -> void:
	Game.new_game()
	store = Store.new()
	add_child(store)
	store.build()
	Game.running = true
	Game.money = 5000.0
	for p in Data.PRODUCTS:
		Game.order_stock(p["id"], 20)
	for i in range(8):
		Game.move_to_shelf(i, 99)
	Game.hire("cashier")
	Game.hire("stock")
	Game.hire("guard")
	store.refresh_all()
	store.sync_staff()
	rig = CamRig.new()
	add_child(rig)
	rig.cam.current = true
	rig.focus("overview", 0.01)
	Engine.time_scale = 4.0
func _process(delta: float) -> void:
	t += delta / Engine.time_scale
	if shots.size() > 0 and t * Engine.time_scale >= shots[0][0] * 1.0:
		var s: Array = shots.pop_front()
		print("SHOT ", s[1], " cust=", store.customers.size())
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png("/tmp/shot_%s.png" % s[1])
		if shots.size() > 0:
			rig.focus(shots[0][1], 0.01)
		else:
			get_tree().quit()
